package com.btplayer.video.ui.screens.player

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import com.btplayer.video.ui.icons.BTPlayerIcons
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.SeekCapability
import com.btplayer.video.domain.model.SeekState
import com.btplayer.video.domain.model.SeekSubmissionResult
import com.btplayer.video.domain.model.VideoItem
import com.btplayer.video.player.controller.PlayerController
import com.btplayer.video.ui.theme.CyanAccent
import com.btplayer.video.ui.theme.OrangeAccent
import com.btplayer.video.ui.theme.TextPrimary
import com.btplayer.video.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Full-screen Video Player Screen for BT Video Player 2.0.
 *
 * Includes dedicated, non-conflicting video output surfaces for both [EngineType.MEDIA3]
 * (`PlayerView`) and [EngineType.VLC] (`SurfaceView` + `SurfaceHolder.Callback`),
 * handling surface creation, destruction, landscape playback, fullscreen, and Picture-in-Picture
 * without black screens or audio-only playback.
 */
@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    playerController: PlayerController,
    isInPipMode: Boolean,
    onBackClick: () -> Unit,
    onEnterPip: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    // The video player is landscape-only. Back exits the player instead of
    // switching to a portrait player layout.
    val previousRequestedOrientation = remember(activity) { activity?.requestedOrientation }
    DisposableEffect(activity) {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose {
            previousRequestedOrientation?.let { activity?.requestedOrientation = it }
        }
    }

    BackHandler(enabled = !isInPipMode) {
        activity?.requestedOrientation = previousRequestedOrientation
            ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        onBackClick()
    }
    val coroutineScope = rememberCoroutineScope()

    val isPlaying by playerController.isPlaying.collectAsState()
    val displayedPositionMs by playerController.displayedPositionMs.collectAsState()
    val effectiveDurationMs by playerController.effectiveDurationMs.collectAsState()
    val seekState by playerController.seekState.collectAsState()
    val seekCapability by playerController.seekCapability.collectAsState()
    val playbackSpeed by playerController.playbackSpeed.collectAsState()
    val resizeMode by playerController.resizeMode.collectAsState()
    val currentVideo by playerController.currentVideo.collectAsState()
    val activeEngineType by playerController.activeEngineType.collectAsState()
    val availableSubtitles by playerController.subtitleTracks.collectAsState()
    val availableAudioTracks by playerController.audioTracks.collectAsState()

    var areControlsVisible by remember { mutableStateOf(true) }
    var isControlsLocked by remember { mutableStateOf(false) }

    // Dialog states
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var showAspectDialog by remember { mutableStateOf(false) }

    // Gesture HUD states
    var volumeLevel by remember { mutableStateOf<Int?>(null) }
    var brightnessLevel by remember { mutableStateOf<Float?>(null) }
    var swipeSeekDeltaMs by remember { mutableStateOf<Long?>(null) }
    var doubleTapFeedback by remember { mutableStateOf<String?>(null) }
    var unseekableNotice by remember { mutableStateOf<String?>(null) }
    var isTouching by remember { mutableStateOf(false) }

    // Internal drag gesture tracking
    var dragMode by remember { mutableStateOf("none") }
    var dragStartOffset by remember { mutableStateOf(Offset.Zero) }
    var totalDragX by remember { mutableFloatStateOf(0f) }
    var totalDragY by remember { mutableFloatStateOf(0f) }
    var hasGestured by remember { mutableStateOf(false) }

    val isScrubbing = seekState is SeekState.Scrubbing
    val isMediaSeekable = seekCapability != SeekCapability.UNSEEKABLE

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }

    val subtitleFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            playerController.loadExternalSubtitle(uri)
        }
    }

    // Periodic 250ms timeline polling routed through PlayerController -> SeekController
    LaunchedEffect(Unit) {
        while (true) {
            playerController.pollTimelineSnapshot()
            delay(250L)
        }
    }

    // Auto-hide controls after 3.5s when playing and not touching/scrubbing
    LaunchedEffect(areControlsVisible, isPlaying, isTouching, isScrubbing) {
        if (areControlsVisible && isPlaying && !isControlsLocked && !isTouching && !isScrubbing) {
            delay(3500L)
            areControlsVisible = false
        }
    }

    fun showUnseekableBanner(reason: String) {
        unseekableNotice = reason
        coroutineScope.launch {
            delay(1800L)
            if (unseekableNotice == reason) {
                unseekableNotice = null
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { size ->
                if (size.width > 0 && size.height > 0) {
                    playerController.onSurfaceSizeChanged(size.width, size.height)
                }
            }

    ) {
        // Active Engine Video Surface Handoff:
        // When MEDIA3 is active, attach PlayerView and detach when switching to VLC.
        // When VLC is active, attach dedicated SurfaceView with SurfaceHolder.Callback.
        if (activeEngineType == EngineType.MEDIA3) {
            var media3PlayerViewRef by remember { mutableStateOf<PlayerView?>(null) }

            DisposableEffect(activeEngineType) {
                onDispose {
                    media3PlayerViewRef?.player = null
                    playerController.onSurfaceDestroyed(EngineType.MEDIA3)
                }
            }

            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = playerController.media3ExoPlayer
                        useController = false
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        this.resizeMode = playerController.resizeMode.value.media3ResizeMode
                        media3PlayerViewRef = this
                        playerController.onMedia3SurfaceAttached(width, height)
                    }
                },
                update = { playerView ->
                    if (playerView.player !== playerController.media3ExoPlayer) {
                        playerView.player = playerController.media3ExoPlayer
                    }
                    playerView.resizeMode = resizeMode.media3ResizeMode
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Dedicated LibVLC SurfaceView with full SurfaceHolder creation/resize/destruction lifecycle
            DisposableEffect(activeEngineType) {
                onDispose {
                    playerController.onSurfaceDestroyed(EngineType.VLC)
                }
            }

            AndroidView(
                factory = { ctx ->
                    FrameLayout(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        val surfaceView = SurfaceView(ctx).apply {
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                Gravity.CENTER
                            )
                            holder.addCallback(object : SurfaceHolder.Callback {
                                override fun surfaceCreated(holder: SurfaceHolder) {
                                    playerController.onVlcSurfaceCreated(this@apply, width, height)
                                }

                                override fun surfaceChanged(
                                    holder: SurfaceHolder,
                                    format: Int,
                                    width: Int,
                                    height: Int
                                ) {
                                    playerController.onSurfaceSizeChanged(width, height)
                                }

                                override fun surfaceDestroyed(holder: SurfaceHolder) {
                                    playerController.onSurfaceDestroyed(EngineType.VLC)
                                }
                            })
                        }
                        addView(surfaceView)
                    }
                },
                update = { container ->
                    if (container.width > 0 && container.height > 0) {
                        playerController.onSurfaceSizeChanged(container.width, container.height)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Video-only gesture layer; controls are rendered on top and receive taps first.
        if (!isInPipMode) {
            Box(modifier = Modifier.fillMaxSize()
            .pointerInput(isControlsLocked) {
                detectTapGestures(
                    onTap = {
                        if (isControlsLocked) {
                            areControlsVisible = true
                        } else if (!hasGestured) {
                            areControlsVisible = !areControlsVisible
                        }
                        hasGestured = false
                    },
                    onDoubleTap = { offset ->
                        if (!isControlsLocked && !hasGestured) {
                            val screenWidth = size.width
                            if (offset.x < screenWidth * 0.38f) {
                                when (val result = playerController.seekBackward10s()) {
                                    is SeekSubmissionResult.Accepted -> {
                                        val seconds = (result.accumulatedDeltaMs / 1000L)
                                        val label = if (seconds < 0L) "${seconds}s" else "-10s"
                                        doubleTapFeedback = label
                                        coroutineScope.launch {
                                            delay(800L)
                                            if (doubleTapFeedback == label) doubleTapFeedback = null
                                        }
                                    }
                                    is SeekSubmissionResult.RejectedUnseekable -> {
                                        showUnseekableBanner("Media is not seekable")
                                    }
                                    else -> {}
                                }
                            } else if (offset.x > screenWidth * 0.62f) {
                                when (val result = playerController.seekForward10s()) {
                                    is SeekSubmissionResult.Accepted -> {
                                        val seconds = (result.accumulatedDeltaMs / 1000L)
                                        val label = if (seconds > 0L) "+${seconds}s" else "+10s"
                                        doubleTapFeedback = label
                                        coroutineScope.launch {
                                            delay(800L)
                                            if (doubleTapFeedback == label) doubleTapFeedback = null
                                        }
                                    }
                                    is SeekSubmissionResult.RejectedUnseekable -> {
                                        showUnseekableBanner("Media is not seekable")
                                    }
                                    else -> {}
                                }
                            } else {
                                playerController.togglePlayPause()
                            }
                        }
                        hasGestured = false
                    }
                )
            }
            .pointerInput(isControlsLocked) {
                if (!isControlsLocked) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            isTouching = true
                            hasGestured = false
                            dragStartOffset = offset
                            dragMode = "none"
                            totalDragX = 0f
                            totalDragY = 0f
                        },
                        onDragEnd = {
                            isTouching = false
                            if (dragMode == "seek" && swipeSeekDeltaMs != null) {
                                playerController.commitInteractiveScrub()
                            }
                            dragMode = "none"
                            coroutineScope.launch {
                                delay(700L)
                                swipeSeekDeltaMs = null
                                volumeLevel = null
                                brightnessLevel = null
                            }
                        },
                        onDragCancel = {
                            isTouching = false
                            if (dragMode == "seek") {
                                playerController.cancelInteractiveScrub()
                            }
                            dragMode = "none"
                            swipeSeekDeltaMs = null
                            volumeLevel = null
                            brightnessLevel = null
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            totalDragX += dragAmount.x
                            totalDragY -= dragAmount.y

                            val screenWidth = size.width.toFloat().coerceAtLeast(1f)
                            val absX = abs(totalDragX)
                            val absY = abs(totalDragY)

                            if (dragMode == "none") {
                                if (hypot(totalDragX, totalDragY) > 12f) {
                                    hasGestured = true
                                    val isLeft = dragStartOffset.x < screenWidth * 0.38f
                                    val isRight = dragStartOffset.x > screenWidth * 0.62f

                                    dragMode = when {
                                        absX > absY || (!isLeft && !isRight) -> "seek"
                                        isLeft -> "brightness"
                                        else -> "volume"
                                    }
                                } else {
                                    return@detectDragGestures
                                }
                            }

                            hasGestured = true

                            when (dragMode) {
                                "brightness" -> {
                                    activity?.window?.let { window ->
                                        val lp = window.attributes
                                        val base = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                        val updated = (base + (dragAmount.y * -0.005f)).coerceIn(0.01f, 1.0f)
                                        lp.screenBrightness = updated
                                        window.attributes = lp
                                        brightnessLevel = updated
                                    }
                                }
                                "volume" -> {
                                    val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                    val step = if (dragAmount.y < 0f) 1 else -1
                                    val newVol = (currentVol + step).coerceIn(0, maxVolume)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                    volumeLevel = newVol
                                }
                                "seek" -> {
                                    when (val res = playerController.onHorizontalSwipeScrub(
                                        totalDragPx = totalDragX,
                                        zoneWidthPx = screenWidth * 0.65f
                                    )) {
                                        is SeekSubmissionResult.PreviewUpdated -> {
                                            swipeSeekDeltaMs = res.deltaMs
                                        }
                                        is SeekSubmissionResult.RejectedUnseekable -> {
                                            showUnseekableBanner("Media is not seekable")
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    )
                }
            }
            )
        }

        // Floating Gesture HUDs (Brightness, Volume, Center Seek Preview, Double-Tap)
        PlayerGestureHudOverlay(
            brightnessLevel = brightnessLevel,
            volumeLevel = volumeLevel,
            maxVolume = maxVolume,
            swipeSeekDeltaMs = swipeSeekDeltaMs,
            displayedPositionMs = displayedPositionMs,
            effectiveDurationMs = effectiveDurationMs,
            doubleTapFeedback = doubleTapFeedback,
            unseekableWarning = unseekableNotice
        )

        // Overlay Controls (Hidden in Picture-in-Picture mode)
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = areControlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Transparent)
                ) {
                    if (isControlsLocked) {
                        IconButton(
                            onClick = { isControlsLocked = false },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(24.dp)
                                .clip(CircleShape)
                                .background(Color(0x80000000))
                                .size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Unlock Controls",
                                tint = CyanAccent
                            )
                        }
                    } else {
                        // Top Floating Toolbar
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                .background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent)))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .statusBarsPadding(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = {
                                activity?.requestedOrientation = previousRequestedOrientation
                                    ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                onBackClick()
                            }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = currentVideo?.displayName ?: "Playing Video",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${currentVideo?.resolutionLabel ?: "HD"} • ${playbackSpeed}x • ${activeEngineType.name}",
                                    color = CyanAccent,
                                    fontSize = 11.sp
                                )
                            }

                            IconButton(onClick = { showAudioDialog = true }) {
                                Icon(
                                    imageVector = BTPlayerIcons.GraphicEq,
                                    contentDescription = "Audio Language",
                                    tint = if (availableAudioTracks.size > 1) CyanAccent else TextPrimary
                                )
                            }

                            IconButton(onClick = { showSubtitleDialog = true }) {
                                Icon(
                                    imageVector = BTPlayerIcons.Subtitles,
                                    contentDescription = "Subtitles",
                                    tint = TextPrimary
                                )
                            }

                            IconButton(onClick = { showSpeedDialog = true }) {
                                Icon(
                                    imageVector = BTPlayerIcons.Speed,
                                    contentDescription = "Speed",
                                    tint = TextPrimary
                                )
                            }

                            IconButton(onClick = { showAspectDialog = true }) {
                                Icon(
                                    imageVector = BTPlayerIcons.AspectRatio,
                                    contentDescription = "Aspect Ratio",
                                    tint = TextPrimary
                                )
                            }

                            IconButton(onClick = { isControlsLocked = true }) {
                                Icon(
                                    imageVector = BTPlayerIcons.LockOpen,
                                    contentDescription = "Lock Screen",
                                    tint = TextPrimary
                                )
                            }
                        }

                        // Bottom Floating Toolbar & Controls
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x66000000))))
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .navigationBarsPadding()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = VideoItem.formatTimestampMs(displayedPositionMs),
                                    color = CyanAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (effectiveDurationMs > 0L) {
                                        VideoItem.formatTimestampMs(effectiveDurationMs)
                                    } else {
                                        "--:--"
                                    },
                                    color = if (isMediaSeekable) TextSecondary else OrangeAccent,
                                    fontSize = 12.sp
                                )
                            }

                            // Seek Bar connected directly to SeekController via PlayerController
                            Slider(
                                value = if (effectiveDurationMs > 0L) {
                                    (displayedPositionMs.toFloat() / effectiveDurationMs.toFloat()).coerceIn(0f, 1f)
                                } else {
                                    0f
                                },
                                enabled = isMediaSeekable && effectiveDurationMs > 0L,
                                onValueChange = { fraction ->
                                    isTouching = true
                                    val res = playerController.onSeekBarScrub(fraction)
                                    if (res is SeekSubmissionResult.RejectedUnseekable) {
                                        showUnseekableBanner("Media is not seekable")
                                    }
                                },
                                onValueChangeFinished = {
                                    playerController.commitInteractiveScrub()
                                    isTouching = false
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = CyanAccent,
                                    activeTrackColor = CyanAccent,
                                    inactiveTrackColor = Color(0x66FFFFFF)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Transport Row: Aspect Ratio, Previous / Play-Pause / Next, Screen Rotation
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { playerController.cycleResizeMode() },
                                    colors = ButtonDefaults.textButtonColors(contentColor = TextPrimary)
                                ) {
                                    Text(
                                        text = resizeMode.shortTag,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanAccent
                                    )
                                }

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = { playerController.playPrevious() },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = BTPlayerIcons.SkipPrevious,
                                            contentDescription = "Previous Video",
                                            tint = TextPrimary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(CyanAccent)
                                            .clickable { playerController.togglePlayPause() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isPlaying) BTPlayerIcons.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlaying) "Pause" else "Play",
                                            tint = Color.Black,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = { playerController.playNext() },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = BTPlayerIcons.SkipNext,
                                            contentDescription = "Next Video",
                                            tint = TextPrimary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    if (showAudioDialog) {
        AudioTrackSelectorDialog(
            audioTracks = availableAudioTracks,
            onSelectTrack = { track -> playerController.selectAudioTrack(track) },
            onDismiss = { showAudioDialog = false }
        )
    }

    if (showSubtitleDialog) {
        SubtitleSelectorDialog(
            subtitleTracks = availableSubtitles,
            onSelectSubtitle = { track -> playerController.selectSubtitleTrack(track) },
            onLoadExternalSubtitle = { subtitleFilePicker.launch("*/*") },
            onDismiss = { showSubtitleDialog = false }
        )
    }

    if (showSpeedDialog) {
        PlaybackSpeedDialog(
            currentSpeed = playbackSpeed,
            onSelectSpeed = { speed -> playerController.setPlaybackSpeed(speed) },
            onDismiss = { showSpeedDialog = false }
        )
    }

    if (showAspectDialog) {
        AspectRatioSelectorDialog(
            currentMode = resizeMode,
            onSelectMode = { mode -> playerController.setResizeMode(mode) },
            onDismiss = { showAspectDialog = false }
        )
    }
}
