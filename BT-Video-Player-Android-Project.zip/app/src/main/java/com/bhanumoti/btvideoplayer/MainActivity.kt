package com.bhanumoti.btvideoplayer

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToLong

class MainActivity : AppCompatActivity() {
    private val blue = Color.rgb(8, 120, 249)
    private val navy = Color.rgb(21, 35, 59)
    private val muted = Color.rgb(99, 115, 138)
    private val prefs by lazy { getSharedPreferences("bt_player", MODE_PRIVATE) }
    private val videos = mutableListOf<VideoEntry>()
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var currentIndex = -1
    private var locked = false
    private var controlsVisible = true
    private var seekStartX = 0f
    private var seekStartY = 0f
    private var startPosition = 0L
    private var gestureMode = ""
    private var startBrightness = 0.5f
    private var startVolume = 0
    private var lastTouchTime = 0L
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var tab = "Videos"
    private lateinit var root: LinearLayout
    private lateinit var listArea: LinearLayout
    private lateinit var status: TextView
    private lateinit var seekOverlay: TextView
    private lateinit var searchInput: EditText
    private var isPlayerScreen = false
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = displayName(uri)
            if (videos.none { it.uri == uri }) videos.add(VideoEntry(name, uri.toString()))
        }
        saveVideos()
        renderHome()
    }

    data class VideoEntry(val name: String, val uri: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        loadVideos()
        renderHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 14f, color: Int = navy): TextView =
        TextView(this).apply { text = value; textSize = size; setTextColor(color) }

    private fun button(value: String, action: () -> Unit): Button =
        Button(this).apply { text = value; setOnClickListener { action() } }

    private fun renderHome() {
        isPlayerScreen = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "BT"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(blue); setPadding(dp(14))
        }
        val branding = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        branding.addView(text("BT Video Player", 22f))
        branding.addView(text("Developed by Bhanumoti Tamuli", 12f, blue))
        header.addView(logo)
        header.addView(branding, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        header.addView(button("⚙") { showSettings() })
        root.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; }
        listOf("Videos", "Folders", "Recent", "Favorites", "Playlists").forEach { name ->
            val b = TextView(this).apply {
                text = name; textSize = 11f; gravity = Gravity.CENTER; setPadding(dp(7))
                setTextColor(if (tab == name) Color.WHITE else blue)
                setBackgroundColor(if (tab == name) blue else Color.rgb(237,245,255))
                setOnClickListener { tab = name; renderHome() }
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(dp(2), dp(12), dp(2), dp(8)) })
        }
        root.addView(tabs)
        searchInput = EditText(this).apply {
            hint = "Search videos..."
            singleLine = true
            setTextColor(navy)
            setOnEditorActionListener { _, _, _ -> renderList(); true }
        }
        root.addView(searchInput, LinearLayout.LayoutParams(-1, dp(50)))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("＋ Add Videos") { picker.launch(arrayOf("video/*")) }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(button("▶ Play Last") {
            val uri = prefs.getString("last_uri", null)
            val name = prefs.getString("last_name", "Last video") ?: "Last video"
            if (uri != null) playVideo(VideoEntry(name, uri)) else toast("Choose a video first")
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)
        status = text("", 12f, muted).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)
        val scroll = ScrollView(this)
        listArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listArea)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderList()
    }

    private fun renderList() {
        if (!::listArea.isInitialized) return
        listArea.removeAllViews()
        val query = if (::searchInput.isInitialized) searchInput.text.toString().trim() else ""
        val favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        val history = prefs.getStringSet("history", emptySet()) ?: emptySet()
        val filtered = videos.filter { v ->
            v.name.contains(query, true) && when (tab) {
                "Favorites" -> v.uri in favorites
                "Recent" -> v.uri in history
                "Folders" -> true
                else -> true
            }
        }
        status.text = "${filtered.size} video(s) • Offline library"
        if (filtered.isEmpty()) {
            listArea.addView(text("Your video library will appear here.\n\nTap “Add Videos” to select local videos.", 16f, muted).apply {
                gravity = Gravity.CENTER; setPadding(dp(20))
            }, LinearLayout.LayoutParams(-1, dp(220)))
        }
        filtered.forEach { v ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8))
                setBackgroundColor(Color.rgb(248,251,255))
            }
            val icon = TextView(this).apply {
                text = "▶"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(blue)
                setBackgroundColor(Color.rgb(229,240,255)); setPadding(dp(16))
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(text(v.name, 14f))
            details.addView(text("Local video", 11f, muted))
            card.addView(icon)
            card.addView(details, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            card.addView(button(if (v.uri in favorites) "★" else "☆") { toggleFavorite(v) })
            card.setOnClickListener { playVideo(v) }
            listArea.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) })
        }
    }

    private fun playVideo(entry: VideoEntry) {
        currentIndex = videos.indexOfFirst { it.uri == entry.uri }.coerceAtLeast(0)
        isPlayerScreen = true
        locked = false
        controlsVisible = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        val uri = Uri.parse(entry.uri)
        prefs.edit().putString("last_uri", entry.uri).putString("last_name", entry.name).apply()
        addHistory(entry.uri)
        val container = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = true
            controllerShowTimeoutMs = 3500
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView?.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = true
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    toast("Cannot play this file or codec on this device.")
                }
            })
        }
        container.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        seekOverlay = TextView(this).apply {
            textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt()); visibility = View.GONE
        }
        container.addView(seekOverlay, FrameLayout.LayoutParams(-2, dp(70), Gravity.CENTER))
        val topBar = TextView(this).apply {
            text = "‹   ${entry.name}"
            textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(14))
            setBackgroundColor(0x66000000)
            setOnClickListener { releasePlayer(); renderHome() }
        }
        container.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(0x66000000)
        }
        bottomBar.addView(button("−10s") { seekBy(-10_000) })
        bottomBar.addView(button("⏮") { playPrevious() })
        bottomBar.addView(button("▶/Ⅱ") { player?.let { if (it.isPlaying) it.pause() else it.play() } })
        bottomBar.addView(button("⏭") { playNext() })
        bottomBar.addView(button("+10s") { seekBy(10_000) })
        bottomBar.addView(button("Tracks") { showTracks() })
        bottomBar.addView(button("Speed") { showSpeed() })
        bottomBar.addView(button("Fit") { cycleResizeMode() })
        bottomBar.addView(button("🔒") { locked = !locked; toast(if (locked) "Controls locked" else "Controls unlocked") })
        bottomBar.addView(button("PiP") { enterPip() })
        container.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM))
        container.setOnTouchListener { _, event -> handleGesture(event) }
        setContentView(container)
    }

    private fun handleGesture(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                seekStartX = e.x; seekStartY = e.y
                startPosition = player?.currentPosition ?: 0L
                startBrightness = window.attributes.screenBrightness.takeIf { it >= 0 } ?: 0.5f
                startVolume = audioVolume()
                val now = System.currentTimeMillis()
                if (now - lastTouchTime < 300 && abs(e.x - lastTouchX) < dp(55) && abs(e.y - lastTouchY) < dp(55)) {
                    val delta = if (e.x < resources.displayMetrics.widthPixels / 2f) -10_000L else 10_000L
                    seekBy(delta)
                    seekOverlay.text = if (delta < 0) "−10 seconds" else "+10 seconds"
                    seekOverlay.visibility = View.VISIBLE
                    lastTouchTime = 0
                    return true
                }
                lastTouchTime = now; lastTouchX = e.x; lastTouchY = e.y
                gestureMode = ""
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - seekStartX
                val dy = e.y - seekStartY
                if (gestureMode.isEmpty()) {
                    gestureMode = when {
                        abs(dx) > dp(12) && abs(dx) > abs(dy) -> "seek"
                        abs(dy) > dp(12) && abs(dy) > abs(dx) ->
                            if (seekStartX < resources.displayMetrics.widthPixels / 2f) "brightness" else "volume"
                        else -> ""
                    }
                }
                when (gestureMode) {
                    "seek" -> {
                        val width = resources.displayMetrics.widthPixels.toFloat().coerceAtLeast(1f)
                        // Smooth MX-style mapping: a full screen-width drag seeks 120 seconds.
                        val seconds = (dx / width * 120.0).roundToLong()
                        val target = (startPosition + seconds * 1000L).coerceIn(0L, player?.duration?.takeIf { it > 0 } ?: Long.MAX_VALUE)
                        player?.seekTo(target)
                        seekOverlay.text = "${if (seconds >= 0) "+" else ""}${seconds}s\n${formatTime(target)}"
                        seekOverlay.visibility = View.VISIBLE
                    }
                    "brightness" -> {
                        val value = (startBrightness - dy / (resources.displayMetrics.heightPixels.toFloat().coerceAtLeast(1f))).coerceIn(0.05f, 1f)
                        val attrs = window.attributes; attrs.screenBrightness = value; window.attributes = attrs
                        seekOverlay.text = "Brightness ${(value * 100).toInt()}%"; seekOverlay.visibility = View.VISIBLE
                    }
                    "volume" -> {
                        val max = audioMaxVolume().coerceAtLeast(1)
                        val value = (startVolume - dy / dp(180).toFloat() * max).toInt().coerceIn(0, max)
                        setAudioVolume(value)
                        seekOverlay.text = "Volume ${(value * 100 / max)}%"; seekOverlay.visibility = View.VISIBLE
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                seekOverlay.visibility = View.GONE
                return true
            }
        }
        return false
    }

    private fun seekBy(delta: Long) {
        val p = player ?: return
        val duration = p.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
        p.seekTo((p.currentPosition + delta).coerceIn(0L, duration))
    }
    private fun formatTime(ms: Long): String {
        val total = (ms.coerceAtLeast(0) / 1000)
        return "%02d:%02d".format(total / 60, total % 60)
    }
    private fun playNext() {
        if (videos.isEmpty()) return
        currentIndex = (currentIndex + 1) % videos.size
        playVideo(videos[currentIndex])
    }
    private fun playPrevious() {
        if (videos.isEmpty()) return
        currentIndex = if (currentIndex <= 0) videos.lastIndex else currentIndex - 1
        playVideo(videos[currentIndex])
    }
    private fun cycleResizeMode() {
        val view = playerView ?: return
        view.resizeMode = when (view.resizeMode) {
            androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
    }
    private fun showTracks() {
        val p = player ?: return
        val tracks = p.currentTracks.groups
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        options.add("Audio: Auto")
        actions.add { p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false).build() }
        options.add("Subtitles: Off")
        actions.add { p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }
        tracks.forEach { group ->
            if (group.type == C.TRACK_TYPE_AUDIO || group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val type = if (group.type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                    options.add("$type: ${format.label ?: format.language ?: "Track ${i+1}"}")
                    actions.add {
                        val builder = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(group.type, false)
                        builder.setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, i))
                        p.trackSelectionParameters = builder.build()
                    }
                }
            }
        }
        AlertDialogBuilder(this).showList("Audio & Subtitles", options.toTypedArray()) { which -> actions[which]() }
    }
    private fun showSpeed() {
        val speeds = arrayOf("0.5×", "0.75×", "1.0×", "1.25×", "1.5×", "1.75×", "2.0×")
        AlertDialogBuilder(this).showList("Playback speed", speeds) { i ->
            val speed = listOf(.5f,.75f,1f,1.25f,1.5f,1.75f,2f)[i]
            player?.setPlaybackSpeed(speed)
        }
    }
    private fun showSettings() {
        val options = arrayOf("Language: English", "Language: অসমীয়া", "Language: हिन्दी", "Clear playback history")
        AlertDialogBuilder(this).showList("Settings", options) { i ->
            when (i) {
                0 -> prefs.edit().putString("language", "en").apply()
                1 -> prefs.edit().putString("language", "as").apply()
                2 -> prefs.edit().putString("language", "hi").apply()
                3 -> { prefs.edit().remove("history").apply(); toast("History cleared") }
            }
            toast(options[i])
        }
    }
    private fun toggleFavorite(v: VideoEntry) {
        val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        if (!set.add(v.uri)) set.remove(v.uri)
        prefs.edit().putStringSet("favorites", set).apply()
        renderList()
    }
    private fun addHistory(uri: String) {
        val set = (prefs.getStringSet("history", emptySet()) ?: emptySet()).toMutableSet()
        set.add(uri)
        prefs.edit().putStringSet("history", set).apply()
    }
    private fun saveVideos() {
        val arr = JSONArray()
        videos.forEach { arr.put(JSONObject().put("name", it.name).put("uri", it.uri)) }
        prefs.edit().putString("videos", arr.toString()).apply()
    }
    private fun loadVideos() {
        try {
            val arr = JSONArray(prefs.getString("videos", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                videos.add(VideoEntry(o.getString("name"), o.getString("uri")))
            }
        } catch (_: Exception) {}
    }
    private fun displayName(uri: Uri): String = try {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else uri.lastPathSegment ?: "Video"
        } ?: (uri.lastPathSegment ?: "Video")
    } catch (_: Exception) { uri.lastPathSegment ?: "Video" }
    private fun audioVolume(): Int {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        return am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
    }
    private fun audioMaxVolume(): Int {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        return am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
    }
    private fun setAudioVolume(value: Int) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, value, 0)
    }
    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) }
            catch (_: Exception) { toast("PiP is not available") }
        } else toast("PiP needs Android 8 or newer")
    }
    private fun releasePlayer() {
        player?.release(); player = null; playerView = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (isPlayerScreen) { releasePlayer(); renderHome() } else super.onBackPressed()
    }
    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }

    private class AlertDialogBuilder(private val activity: Activity) {
        fun showList(title: String, items: Array<String>, action: (Int) -> Unit) {
            android.app.AlertDialog.Builder(activity).setTitle(title).setItems(items) { _, which -> action(which) }.show()
        }
    }
}
