package com.bhanumoti.btvideoplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private val videos = mutableListOf<Pair<String, Uri>>()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "Video"
            if (videos.none { it.second == uri }) videos.add(name to uri)
        }
        showHome()
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun showHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(8)); setBackgroundColor(0xFFFFFFFF.toInt()) }
        val logo = TextView(this).apply { text = "BT"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(-1); setBackgroundColor(0xFF0878F9.toInt()); setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val brand = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        brand.addView(logo)
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        texts.addView(TextView(this).apply { text = "BT Video Player"; textSize = 22f; setTextColor(0xFF15233B.toInt()) })
        texts.addView(TextView(this).apply { text = "Developed by Bhanumoti Tamuli"; textSize = 12f; setTextColor(0xFF0878E8.toInt()) })
        brand.addView(texts); root.addView(brand)
        root.addView(Button(this).apply { text = "＋ Add Videos"; setOnClickListener { picker.launch(arrayOf("video/*")) } }, LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(16) })
        status = TextView(this).apply { text = if (videos.isEmpty()) "Choose videos stored on your phone." else "${videos.size} video(s) selected"; textSize = 14f; setTextColor(0xFF63738A.toInt()); setPadding(0,dp(10),0,dp(10)) }; root.addView(status)
        val scroll = android.widget.ScrollView(this); val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (videos.isEmpty()) list.addView(TextView(this).apply { text = "Your video library will appear here.\n\nTap Add Videos to select local videos."; textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFF63738A.toInt()); setPadding(dp(20),dp(24),dp(20),dp(24)) }, LinearLayout.LayoutParams(-1,dp(220)))
        videos.forEach { (name, uri) -> list.addView(Button(this).apply { text = "▶  $name"; gravity = Gravity.START or Gravity.CENTER_VERTICAL; setOnClickListener { playVideo(uri, name) } }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin = dp(8) }) }
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun playVideo(uri: Uri, name: String) {
        val screen = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF000000.toInt()) }
        screen.addView(TextView(this).apply { text = "‹   $name"; textSize = 16f; setTextColor(-1); setPadding(dp(14),dp(12),dp(14),dp(12)); setOnClickListener { player?.release(); player = null; showHome() } })
        val pv = PlayerView(this).apply { useController = true }; screen.addView(pv, LinearLayout.LayoutParams(-1,0,1f))
        screen.addView(TextView(this).apply { text = "BT Video Player • Bhanumoti Tamuli"; gravity = Gravity.CENTER; setTextColor(0xFFB8C7DC.toInt()); setPadding(dp(8),dp(8),dp(8),dp(8)) })
        setContentView(screen); player?.release(); player = ExoPlayer.Builder(this).build().also { exo -> pv.player = exo; exo.setMediaItem(MediaItem.fromUri(uri)); exo.prepare(); exo.playWhenReady = true; exo.addListener(object: Player.Listener { override fun onPlayerError(error: androidx.media3.common.PlaybackException) { Toast.makeText(this@MainActivity,"This video or codec may not be supported on this device.",Toast.LENGTH_LONG).show() } }) }
    }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
