package com.bhanumoti.btvideoplayer

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToLong

class MainActivity : AppCompatActivity() {
    private val blue = Color.rgb(8, 120, 249)
    private val navy = Color.rgb(21, 35, 59)
    private val muted = Color.rgb(99, 115, 138)
    private val prefs by lazy { getSharedPreferences("bt_player", MODE_PRIVATE) }
    private val videos = mutableListOf<VideoEntry>()
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var currentIndex = -1
    private var locked = false
    private var controlsVisible = true
    private var seekStartX = 0f
    private var seekStartY = 0f
    private var startPosition = 0L
    private var gestureMode = ""
    private var startBrightness = 0.5f
    private var startVolume = 0
    private var lastTouchTime = 0L
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var tab = "Videos"
    private lateinit var root: LinearLayout
    private lateinit var listArea: LinearLayout
    private lateinit var recentArea: LinearLayout
    private lateinit var popularArea: LinearLayout
    private lateinit var status: TextView
    private lateinit var seekOverlay: TextView
    private lateinit var searchInput: EditText
    private var isPlayerScreen = false
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = displayName(uri)
            if (videos.none { it.uri == uri.toString() }) videos.add(VideoEntry(name, uri.toString()))
        }
        saveVideos()
        renderHome()
    }

    data class VideoEntry(val name: String, val uri: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        loadVideos()
        renderHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 14f, color: Int = navy): TextView =
        TextView(this).apply { text = value; textSize = size; setTextColor(color) }

    private fun button(value: String, action: () -> Unit): Button =
        Button(this).apply { text = value; setOnClickListener { action() } }

    private fun videoThumbnail(uriString: String): Bitmap? {
        return try {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, Uri.parse(uriString))
                retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            } finally {
                retriever.release()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun thumbnailView(uriString: String, widthDp: Int, heightDp: Int): ImageView {
        val image = ImageView(this)
        image.scaleType = ImageView.ScaleType.CENTER_CROP
        image.setBackgroundColor(Color.rgb(218, 231, 247))
        val bitmap = videoThumbnail(uriString)
        if (bitmap != null) image.setImageBitmap(bitmap)
        else image.setImageResource(android.R.drawable.ic_media_play)
        image.layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(heightDp))
        return image
    }

    private fun renderHome() {
        isPlayerScreen = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(249, 251, 255))
        }

        val pageScroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }

        // Premium compact header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "BT"
            textSize = 26f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(blue)
                cornerRadius = dp(18).toFloat()
            }
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(70), dp(70)))
        val branding = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        branding.addView(TextView(this).apply {
            text = "BT Video Player"
            textSize = 21f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(navy)
            maxLines = 1
            setSingleLine(true)
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        branding.addView(text("Bhanumoti Tamuli", 13f, muted))
        header.addView(branding, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
        header.addView(button("⌕") { searchInput.requestFocus(); (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT) }, LinearLayout.LayoutParams(dp(40), dp(46)))
        header.addView(button("◷") { tab = "Recent"; renderHome() }, LinearLayout.LayoutParams(dp(40), dp(46)))
        header.addView(button("⚙") { showSettings() }, LinearLayout.LayoutParams(dp(40), dp(46)))
        page.addView(header)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(239, 244, 251))
                cornerRadius = dp(24).toFloat()
            }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        listOf("⌂\nHome", "▶\nVideos", "▰\nFolders", "♥\nFavorites", "☷\nPlaylists").forEachIndexed { i, label ->
            val target = when (i) { 0 -> "Home"; 1 -> "Videos"; 2 -> "Folders"; 3 -> "Favorites"; else -> "Playlists" }
            val selected = tab == target || (i == 0 && tab == "Recent")
            val item = TextView(this).apply {
                text = label
                textSize = 11.5f
                gravity = Gravity.CENTER
                setTextColor(if (selected) Color.WHITE else navy)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (selected) blue else Color.TRANSPARENT)
                    cornerRadius = dp(18).toFloat()
                }
                setPadding(dp(2), dp(9), dp(2), dp(9))
                setOnClickListener {
                    tab = target
                    renderHome()
                }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                setMargins(dp(1), 0, dp(1), 0)
            })
        }
        page.addView(nav, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(14); bottomMargin = dp(12)
        })

        searchInput = EditText(this).apply {
            hint = "Search videos..."
            setSingleLine(true)
            textSize = 16f
            setTextColor(navy)
            setHintTextColor(muted)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.rgb(232, 237, 245))
            }
            setPadding(dp(14), dp(4), dp(14), dp(4))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderList() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        page.addView(searchInput, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("＋  ADD VIDEOS") { picker.launch(arrayOf("video/*")) },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { rightMargin = dp(5) })
        actions.addView(button("▶  PLAY LAST") {
            val uri = prefs.getString("last_uri", null)
            val name = prefs.getString("last_name", "Last video") ?: "Last video"
            if (uri != null) playVideo(VideoEntry(name, uri)) else picker.launch(arrayOf("video/*"))
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(5) })
        page.addView(actions)

        status = text("", 12f, muted).apply { setPadding(0, dp(10), 0, dp(8)) }
        page.addView(status)

        // Large featured video with a real frame thumbnail when available.
        val featuredVideo = videos.firstOrNull()
        val featured = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(231, 237, 246))
            }
            clipToOutline = true
        }
        if (featuredVideo != null) {
            val heroFrame = FrameLayout(this)
            val heroImage = thumbnailView(featuredVideo.uri, 320, 180)
            heroFrame.addView(heroImage, FrameLayout.LayoutParams(-1, dp(180)))
            val shade = View(this).apply {
                background = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(Color.TRANSPARENT, 0xCC071426.toInt())
                )
            }
            heroFrame.addView(shade, FrameLayout.LayoutParams(-1, -1))
            val heroText = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM
                setPadding(dp(14), dp(14), dp(14), dp(12))
            }
            heroText.addView(text("FEATURED VIDEO", 10f, Color.WHITE))
            heroText.addView(text(featuredVideo.name, 17f, Color.WHITE).apply { maxLines = 2; setPadding(0, dp(5), 0, dp(2)) })
            heroText.addView(text("Tap to continue watching", 12f, Color.WHITE))
            heroFrame.addView(heroText, FrameLayout.LayoutParams(-1, -1))
            val play = TextView(this).apply {
                text = "▶"
                textSize = 26f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0x66000000)
                    setStroke(dp(2), Color.WHITE)
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                }
                setOnClickListener { playVideo(featuredVideo) }
            }
            heroFrame.addView(play, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })
            heroFrame.setOnClickListener { playVideo(featuredVideo) }
            featured.addView(heroFrame)
        } else {
            featured.setPadding(dp(18))
            featured.addView(text("YOUR VIDEO LIBRARY", 11f, blue))
            featured.addView(text("Add a video to get started", 20f, navy).apply { setPadding(0, dp(8), 0, dp(4)) })
            featured.addView(text("Your local videos will appear here.", 13f, muted))
            featured.addView(button("▶  CHOOSE VIDEO") { picker.launch(arrayOf("video/*")) })
        }
        page.addView(featured, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        page.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(text("Recent Videos", 18f, navy).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD },
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(text("See All  ›", 12f, navy).apply {
                setOnClickListener { tab = "Recent"; renderHome() }
            })
        }.apply { setPadding(0, dp(6), 0, dp(8) }))

        // Horizontal recent-video cards with real local thumbnails.
        recentArea = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val recentScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(recentArea)
        }
        page.addView(recentScroll, LinearLayout.LayoutParams(-1, dp(156)))

        page.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(text("Folders", 18f, navy).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD },
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(text("See All  ›", 12f, navy).apply { setOnClickListener { tab = "Folders"; renderHome() } })
        }.apply { setPadding(0, dp(12), 0, dp(8)) })

        val folderScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val folderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("▣\nMovies", "♫\nSongs", "▣\nDrama", "▧\nCamera", "⬇\nDownloads").forEach { folder ->
            val card = TextView(this).apply {
                text = folder
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(navy)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(14).toFloat()
                    setStroke(dp(1), Color.rgb(232, 237, 245))
                }
                setPadding(dp(12), dp(12), dp(12), dp(12))
            }
            folderRow.addView(card, LinearLayout.LayoutParams(dp(100), dp(82)).apply { rightMargin = dp(8) })
        }
        folderScroll.addView(folderRow)
        page.addView(folderScroll)

        page.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(text("Popular Videos", 18f, navy).apply { typeface = android.graphics.Typeface.DEFAULT_BOLD },
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(text("See All  ›", 12f, navy).apply { setOnClickListener { tab = "Videos"; renderHome() } })
        }.apply { setPadding(0, dp(14), 0, dp(8)) })
        popularArea = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val popularScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(popularArea)
        }
        page.addView(popularScroll, LinearLayout.LayoutParams(-1, dp(140)))

        pageScroll.addView(page)
        root.addView(pageScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderList()
    }

    private fun renderList() {
        if (!::listArea.isInitialized) return
        listArea.removeAllViews()
        if (::recentArea.isInitialized) recentArea.removeAllViews()
        if (::popularArea.isInitialized) popularArea.removeAllViews()

        val query = if (::searchInput.isInitialized) searchInput.text.toString().trim() else ""
        val favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
        val history = prefs.getStringSet("history", emptySet()) ?: emptySet()
        val filtered = videos.filter { v ->
            v.name.contains(query, true) && when (tab) {
                "Favorites" -> v.uri in favorites
                "Recent" -> v.uri in history
                else -> true
            }
        }
        status.text = "${filtered.size} video(s) • Offline library"

        if (filtered.isEmpty()) {
            listArea.addView(text("No videos yet. Tap “Add Videos” to select videos stored on your phone.", 13f, muted).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12))
            }, LinearLayout.LayoutParams(-1, dp(74)))
        }

        filtered.forEach { v ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), Color.rgb(235, 239, 246))
                }
            }
            val thumb = thumbnailView(v.uri, 76, 66)
            card.addView(thumb)
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(text(v.name, 13f, navy).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            details.addView(text("Local video", 11f, muted))
            card.addView(details, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            card.addView(button(if (v.uri in favorites) "♥" else "♡") { toggleFavorite(v); renderList() })
            card.setOnClickListener { playVideo(v) }
            listArea.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) })

            if (::recentArea.isInitialized) {
                val recentCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, dp(8), 0) }
                val recentFrame = FrameLayout(this)
                recentFrame.addView(thumbnailView(v.uri, 142, 82))
                recentFrame.addView(TextView(this).apply {
                    text = "▶"
                    textSize = 20f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(0x66000000); shape = android.graphics.drawable.GradientDrawable.OVAL
                    }
                }, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
                recentFrame.setOnClickListener { playVideo(v) }
                recentCard.addView(recentFrame)
                recentCard.addView(text(v.name, 11f, navy).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0) })
                recentArea.addView(recentCard, LinearLayout.LayoutParams(dp(150), -2))
                if (::popularArea.isInitialized) {
                    val popCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, dp(8), 0) }
                    popCard.addView(thumbnailView(v.uri, 154, 82))
                    popCard.addView(text(v.name, 11f, navy).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0) })
                    popCard.setOnClickListener { playVideo(v) }
                    popularArea.addView(popCard, LinearLayout.LayoutParams(dp(162), -2))
                }
            }
        }
        if (::recentArea.isInitialized && videos.isEmpty()) {
            recentArea.addView(text("Your recent videos will appear here.", 13f, muted).apply { setPadding(dp(8), dp(20), dp(8), dp(20)) })
        }
        if (::popularArea.isInitialized && videos.isEmpty()) {
            popularArea.addView(text("Add videos to see thumbnails here.", 13f, muted).apply { setPadding(dp(8), dp(20), dp(8), dp(20)) })
        }
    }

    private fun playVideo(entry: VideoEntry) {
        currentIndex = videos.indexOfFirst { it.uri == entry.uri }.coerceAtLeast(0)
        isPlayerScreen = true
        locked = false
        controlsVisible = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        val uri = Uri.parse(entry.uri)
        prefs.edit().putString("last_uri", entry.uri).putString("last_name", entry.name).apply()
        addHistory(entry.uri)
        val container = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = true
            controllerShowTimeoutMs = 3500
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView?.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = true
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    toast("Cannot play this file or codec on this device.")
                }
            })
        }
        container.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        seekOverlay = TextView(this).apply {
            textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt()); visibility = View.GONE
        }
        container.addView(seekOverlay, FrameLayout.LayoutParams(-2, dp(70), Gravity.CENTER))
        val topBar = TextView(this).apply {
            text = "‹   ${entry.name}"
            textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(14))
            setBackgroundColor(0x66000000)
            setOnClickListener { releasePlayer(); renderHome() }
        }
        container.addView(topBar, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP))
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(0x66000000)
        }
        bottomBar.addView(button("−10s") { seekBy(-10_000) })
        bottomBar.addView(button("⏮") { playPrevious() })
        bottomBar.addView(button("▶/Ⅱ") { player?.let { if (it.isPlaying) it.pause() else it.play() } })
        bottomBar.addView(button("⏭") { playNext() })
        bottomBar.addView(button("+10s") { seekBy(10_000) })
        bottomBar.addView(button("Tracks") { showTracks() })
        bottomBar.addView(button("Speed") { showSpeed() })
        bottomBar.addView(button("Fit") { cycleResizeMode() })
        bottomBar.addView(button("🔒") { locked = !locked; toast(if (locked) "Controls locked" else "Controls unlocked") })
        bottomBar.addView(button("PiP") { enterPip() })
        container.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM))
        container.setOnTouchListener { _, event -> handleGesture(event) }
        setContentView(container)
    }

    private fun handleGesture(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                seekStartX = e.x; seekStartY = e.y
                startPosition = player?.currentPosition ?: 0L
                startBrightness = window.attributes.screenBrightness.takeIf { it >= 0 } ?: 0.5f
                startVolume = audioVolume()
                val now = System.currentTimeMillis()
                if (now - lastTouchTime < 300 && abs(e.x - lastTouchX) < dp(55) && abs(e.y - lastTouchY) < dp(55)) {
                    val delta = if (e.x < resources.displayMetrics.widthPixels / 2f) -10_000L else 10_000L
                    seekBy(delta)
                    seekOverlay.text = if (delta < 0) "−10 seconds" else "+10 seconds"
                    seekOverlay.visibility = View.VISIBLE
                    lastTouchTime = 0
                    return true
                }
                lastTouchTime = now; lastTouchX = e.x; lastTouchY = e.y
                gestureMode = ""
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - seekStartX
                val dy = e.y - seekStartY
                if (gestureMode.isEmpty()) {
                    gestureMode = when {
                        abs(dx) > dp(12) && abs(dx) > abs(dy) -> "seek"
                        abs(dy) > dp(12) && abs(dy) > abs(dx) ->
                            if (seekStartX < resources.displayMetrics.widthPixels / 2f) "brightness" else "volume"
                        else -> ""
                    }
                }
                when (gestureMode) {
                    "seek" -> {
                        val width = resources.displayMetrics.widthPixels.toFloat().coerceAtLeast(1f)
                        // Smooth MX-style mapping: a full screen-width drag seeks 120 seconds.
                        val seconds = (dx / width * 120.0).roundToLong()
                        val target = (startPosition + seconds * 1000L).coerceIn(0L, player?.duration?.takeIf { it > 0 } ?: Long.MAX_VALUE)
                        player?.seekTo(target)
                        seekOverlay.text = "${if (seconds >= 0) "+" else ""}${seconds}s\n${formatTime(target)}"
                        seekOverlay.visibility = View.VISIBLE
                    }
                    "brightness" -> {
                        val value = (startBrightness - dy / (resources.displayMetrics.heightPixels.toFloat().coerceAtLeast(1f))).coerceIn(0.05f, 1f)
                        val attrs = window.attributes; attrs.screenBrightness = value; window.attributes = attrs
                        seekOverlay.text = "Brightness ${(value * 100).toInt()}%"; seekOverlay.visibility = View.VISIBLE
                    }
                    "volume" -> {
                        val max = audioMaxVolume().coerceAtLeast(1)
                        val value = (startVolume - dy / dp(180).toFloat() * max).toInt().coerceIn(0, max)
                        setAudioVolume(value)
                        seekOverlay.text = "Volume ${(value * 100 / max)}%"; seekOverlay.visibility = View.VISIBLE
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                seekOverlay.visibility = View.GONE
                return true
            }
        }
        return false
    }

    private fun seekBy(delta: Long) {
        val p = player ?: return
        val duration = p.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
        p.seekTo((p.currentPosition + delta).coerceIn(0L, duration))
    }
    private fun formatTime(ms: Long): String {
        val total = (ms.coerceAtLeast(0) / 1000)
        return "%02d:%02d".format(total / 60, total % 60)
    }
    private fun playNext() {
        if (videos.isEmpty()) return
        currentIndex = (currentIndex + 1) % videos.size
        playVideo(videos[currentIndex])
    }
    private fun playPrevious() {
        if (videos.isEmpty()) return
        currentIndex = if (currentIndex <= 0) videos.lastIndex else currentIndex - 1
        playVideo(videos[currentIndex])
    }
    private fun cycleResizeMode() {
        val view = playerView ?: return
        view.resizeMode = when (view.resizeMode) {
            androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
    }
    private fun showTracks() {
        val p = player ?: return
        val tracks = p.currentTracks.groups
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        options.add("Audio: Auto")
        actions.add { p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false).build() }
        options.add("Subtitles: Off")
        actions.add { p.trackSelectionParameters = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }
        tracks.forEach { group ->
            if (group.type == C.TRACK_TYPE_AUDIO || group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val type = if (group.type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                    options.add("$type: ${format.label ?: format.language ?: "Track ${i+1}"}")
                    actions.add {
                        val builder = p.trackSelectionParameters.buildUpon().setTrackTypeDisabled(group.type, false)
                        builder.setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, i))
                        p.trackSelectionParameters = builder.build()
                    }
                }
            }
        }
        AlertDialogBuilder(this).showList("Audio & Subtitles", options.toTypedArray()) { which -> actions[which]() }
    }
    private fun showSpeed() {
        val speeds = arrayOf("0.5×", "0.75×", "1.0×", "1.25×", "1.5×", "1.75×", "2.0×")
        AlertDialogBuilder(this).showList("Playback speed", speeds) { i ->
            val speed = listOf(.5f,.75f,1f,1.25f,1.5f,1.75f,2f)[i]
            player?.setPlaybackSpeed(speed)
        }
    }
    private fun showSettings() {
        val options = arrayOf("Language: English", "Language: অসমীয়া", "Language: हिन्दी", "Clear playback history")
        AlertDialogBuilder(this).showList("Settings", options) { i ->
            when (i) {
                0 -> prefs.edit().putString("language", "en").apply()
                1 -> prefs.edit().putString("language", "as").apply()
                2 -> prefs.edit().putString("language", "hi").apply()
                3 -> { prefs.edit().remove("history").apply(); toast("History cleared") }
            }
            toast(options[i])
        }
    }
    private fun toggleFavorite(v: VideoEntry) {
        val set = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        if (!set.add(v.uri)) set.remove(v.uri)
        prefs.edit().putStringSet("favorites", set).apply()
        renderList()
    }
    private fun addHistory(uri: String) {
        val set = (prefs.getStringSet("history", emptySet()) ?: emptySet()).toMutableSet()
        set.add(uri)
        prefs.edit().putStringSet("history", set).apply()
    }
    private fun saveVideos() {
        val arr = JSONArray()
        videos.forEach { arr.put(JSONObject().put("name", it.name).put("uri", it.uri)) }
        prefs.edit().putString("videos", arr.toString()).apply()
    }
    private fun loadVideos() {
        try {
            val arr = JSONArray(prefs.getString("videos", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                videos.add(VideoEntry(o.getString("name"), o.getString("uri")))
            }
        } catch (_: Exception) {}
    }
    private fun displayName(uri: Uri): String = try {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else uri.lastPathSegment ?: "Video"
        } ?: (uri.lastPathSegment ?: "Video")
    } catch (_: Exception) { uri.lastPathSegment ?: "Video" }
    private fun audioVolume(): Int {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        return am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
    }
    private fun audioMaxVolume(): Int {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        return am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
    }
    private fun setAudioVolume(value: Int) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, value, 0)
    }
    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) }
            catch (_: Exception) { toast("PiP is not available") }
        } else toast("PiP needs Android 8 or newer")
    }
    private fun releasePlayer() {
        player?.release(); player = null; playerView = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() {
        if (isPlayerScreen) { releasePlayer(); renderHome() } else super.onBackPressed()
    }
    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }

    private class AlertDialogBuilder(private val activity: Activity) {
        fun showList(title: String, items: Array<String>, action: (Int) -> Unit) {
            android.app.AlertDialog.Builder(activity).setTitle(title).setItems(items) { _, which -> action(which) }.show()
        }
    }
}
