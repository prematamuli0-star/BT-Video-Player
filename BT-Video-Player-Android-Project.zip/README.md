# BT Video Player
Android starter project — Developed by Bhanumoti Tamuli.

This initial native build can choose local videos and play them using AndroidX Media3/ExoPlayer controls. Container/codec support depends on the phone's decoders. Advanced gestures, playlists, favorites, subtitles, language settings and other requested features are not yet implemented in this starter build.

Build via GitHub Actions workflow `.github/workflows/build-apk.yml` after the project files are present at repository root.
