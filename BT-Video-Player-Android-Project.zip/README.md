# BT Video Player — Native Android starter

Developer credit: Bhanumoti Tamuli.

Includes a native Android UI and Media3 playback foundation: local video document picker, persisted selected library, search, favorites, history/recent, fullscreen player, seek bar/controller, horizontal drag-to-seek with a preview overlay, double-tap ±10s, vertical brightness/volume gestures, audio/subtitle track choices, playback speed, fit/zoom/fill, screen lock toggle, and PiP request.

Important limitations:
- This is a starter project and must be built and tested on real devices. Gesture handling and PiP behavior can vary by device.
- Format support depends on Media3, Android platform decoders, and device codecs.
- Folder browsing and playlist management are basic/limited; language selection currently saves a preference and is not a full translation system.
- APK signing is debug signing; do not publish it as a production release without release signing and testing.
