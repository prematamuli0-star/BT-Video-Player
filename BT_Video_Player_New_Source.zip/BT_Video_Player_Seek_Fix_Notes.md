# BT Video Player – Seek fix audit

## Root cause found in supplied source
`Media3PlaybackEngine` configured `DefaultExtractorsFactory` with both
`setConstantBitrateSeekingEnabled(true)` and
`setConstantBitrateSeekingAlwaysEnabled(true)`. The second setting forces CBR byte seeking
instead of allowing the extractor to use it only when a valid constant-bitrate stream is
identified. For variable-bitrate MP4/MKV media this can produce invalid byte offsets and
incorrect seek destinations (including jumps near the beginning).

## Changes made
- Removed `setConstantBitrateSeekingAlwaysEnabled(true)`; retained normal CBR seeking support.
- Changed Media3 seek parameters from `CLOSEST_SYNC` to `EXACT` so requested timestamps are
  targeted precisely (decoder still decodes from a valid preceding sync frame as needed).
- Kept the existing SeekController request coalescing, timeout, and engine fallback logic.
- Kept minSdk 24 / Android 7.0 compatibility settings unchanged.

## Validation status
- Source ZIP inspected and patch applied.
- Android Gradle build and physical-device playback tests have NOT been completed here.
- Test on multiple variable-bitrate MP4 and MKV files, seeking forward/backward from early,
  middle, and late positions. Confirm displayed timestamp and actual picture position agree.
- Also test AVI/MOV/WEBM and a constant-bitrate sample to ensure no regression.

This is a targeted source correction for the strongest code-level cause found; it is not a
claim that all files/codecs are now verified on every Android device.
