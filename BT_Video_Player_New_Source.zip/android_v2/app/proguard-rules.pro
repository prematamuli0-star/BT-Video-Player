# Keep Media3 and optional LibVLC reflection classes
-keep class org.videolan.libvlc.** { *; }
-dontwarn org.videolan.libvlc.**
-keep class androidx.media3.** { *; }
