package com.bt.videoplayer.player.engine

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.view.SurfaceView
import com.bt.videoplayer.core.logging.DiagnosticCategory
import com.bt.videoplayer.core.logging.PlayerDiagnosticLogger
import com.bt.videoplayer.domain.model.AudioTrackInfo
import com.bt.videoplayer.domain.model.EngineTimelineSnapshot
import com.bt.videoplayer.domain.model.EngineType
import com.bt.videoplayer.domain.model.SubtitleTrackInfo
import com.bt.videoplayer.domain.model.VideoItem
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.interfaces.IVLCVout

/**
 * Strongly-typed VideoLAN LibVLC (`org.videolan.android:libvlc-all:3.6.0`) fallback playback engine.
 *
 * Responsibilities:
 * 1. Direct integration with [LibVLC], [Media], [MediaPlayer], and [IVLCVout].
 * 2. Safe video surface attachment (`setVideoView`, `setWindowSize`, `attachViews`) and
 *    detachment (`detachViews`) with [IVLCVout.OnNewVideoLayoutListener].
 * 3. Asynchronous seek completion tracking via [MediaPlayer.Event.TimeChanged] / [MediaPlayer.Event.PositionChanged].
 * 4. Cross-engine track mapping: when switching from Media3 to LibVLC, matches and applies
 *    the user's selected audio and subtitle tracks (by ID, language/name, or ordinal) as soon
 *    as LibVLC demuxes elementary streams ([MediaPlayer.Event.ESAdded] / [MediaPlayer.Event.Playing]).
 */
class VlcPlaybackEngine(
    private val context: Context,
    private val logger: PlayerDiagnosticLogger
) : PlaybackEngine, IVLCVout.Callback, IVLCVout.OnNewVideoLayoutListener {

    override val engineType: EngineType = EngineType.VLC

    @Volatile
    override var isSurfaceAttached: Boolean = false
        private set

    private var listener: PlaybackEngineListener? = null
    private var currentVideo: VideoItem? = null
    private var libVlc: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private var attachedSurfaceView: SurfaceView? = null
    private var surfaceWidth: Int = 0
    private var surfaceHeight: Int = 0

    @Volatile
    private var isPrepared: Boolean = false

    @Volatile
    private var isCurrentlyPlaying: Boolean = false

    @Volatile
    private var activeSeekRequestId: Long = 0L

    @Volatile
    private var activeSeekTargetMs: Long = -1L

    private var pendingInitialPositionMs: Long = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    private var initialSeekAttempts = 0
    private val initialSeekRunnable = object : Runnable {
        override fun run() {
            val target = pendingInitialPositionMs
            if (target <= 0L) return
            val player = mediaPlayer ?: return
            if (player.isSeekable) {
                pendingInitialPositionMs = 0L
                performEngineSeek(0L, target)
            } else if (initialSeekAttempts++ < 15 && isCurrentlyPlaying) {
                mainHandler.postDelayed(this, 200L)
            } else {
                logger.log(
                    category = DiagnosticCategory.SEEK,
                    message = "VLC initial resume seek unavailable after waiting for seekability",
                    details = mapOf("targetMs" to target, "attempts" to initialSeekAttempts),
                    isWarningOrError = true
                )
                pendingInitialPositionMs = 0L
            }
        }
    }

    @Volatile
    private var pendingDesiredAudio: AudioTrackInfo? = null

    @Volatile
    private var pendingDesiredSubtitle: SubtitleTrackInfo? = null

    override val isAvailable: Boolean = true

    private val vlcEventListener = MediaPlayer.EventListener { event ->
        val player = mediaPlayer ?: return@EventListener
        when (event.type) {
            MediaPlayer.Event.Opening -> {
                listener?.onPlaybackStateChanged(isCurrentlyPlaying, PlaybackEngine.STATE_BUFFERING)
            }
            MediaPlayer.Event.Buffering -> {
                if (event.buffering >= 100f) {
                    listener?.onPlaybackStateChanged(isCurrentlyPlaying, PlaybackEngine.STATE_READY)
                }
            }
            MediaPlayer.Event.Playing -> {
                isPrepared = true
                isCurrentlyPlaying = true
                refreshAndApplyVlcTracks(player)
                listener?.onPlaybackStateChanged(true, PlaybackEngine.STATE_READY)
                listener?.onTimelineSnapshotChanged(captureTimelineSnapshot())
                if (pendingInitialPositionMs > 0L) {
                    initialSeekAttempts = 0
                    mainHandler.removeCallbacks(initialSeekRunnable)
                    mainHandler.post(initialSeekRunnable)
                }
            }
            MediaPlayer.Event.Paused -> {
                isPrepared = true
                isCurrentlyPlaying = false
                listener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_READY)
                listener?.onTimelineSnapshotChanged(captureTimelineSnapshot())
                if (pendingInitialPositionMs > 0L) {
                    initialSeekAttempts = 0
                    mainHandler.removeCallbacks(initialSeekRunnable)
                    mainHandler.post(initialSeekRunnable)
                }
            }
            MediaPlayer.Event.Stopped -> {
                isCurrentlyPlaying = false
                listener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_IDLE)
            }
            MediaPlayer.Event.EndReached -> {
                isCurrentlyPlaying = false
                activeSeekRequestId = 0L
                listener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_ENDED)
                listener?.onMediaEnded(EngineType.VLC)
            }
            MediaPlayer.Event.ESAdded,
            MediaPlayer.Event.ESSelected -> {
                refreshAndApplyVlcTracks(player)
            }
            MediaPlayer.Event.LengthChanged,
            MediaPlayer.Event.SeekableChanged -> {
                listener?.onTimelineSnapshotChanged(captureTimelineSnapshot())
            }
            MediaPlayer.Event.TimeChanged -> {
                val reqId = activeSeekRequestId
                val landedMs = event.timeChanged.coerceAtLeast(0L)
                val targetMs = activeSeekTargetMs
                // VLC emits TimeChanged continuously. Ignore ordinary/stale ticks until
                // the decoder has actually reached the requested seek neighborhood.
                if (reqId != 0L && targetMs >= 0L && kotlin.math.abs(landedMs - targetMs) <= 2_500L) {
                    activeSeekRequestId = 0L
                    activeSeekTargetMs = -1L
                    logger.log(
                        category = DiagnosticCategory.SEEK,
                        message = "LibVLC TimeChanged confirmed pending seek",
                        details = mapOf("requestId" to reqId, "targetMs" to targetMs, "landedPositionMs" to landedMs)
                    )
                    listener?.onEngineSeekCompleted(EngineType.VLC, reqId, landedMs)
                }
            }
            MediaPlayer.Event.EncounteredError -> {
                val failedSeekId = activeSeekRequestId
                activeSeekRequestId = 0L
                activeSeekTargetMs = -1L
                if (failedSeekId != 0L) {
                    listener?.onEngineSeekFailed(EngineType.VLC, failedSeekId, "LibVLC EncounteredError during seek")
                }
                listener?.onEngineFatalError(
                    engineType = EngineType.VLC,
                    errorCode = "VLC_ENCOUNTERED_ERROR",
                    message = "LibVLC encountered a playback error",
                    isSeekRelated = failedSeekId != 0L
                )
            }
        }
    }

    override fun setListener(listener: PlaybackEngineListener?) {
        this.listener = listener
    }

    override fun attachSurfaceView(surfaceView: SurfaceView?, width: Int, height: Int) {
        if (surfaceView == null) {
            detachSurface()
            return
        }

        attachedSurfaceView = surfaceView
        if (width > 0 && height > 0) {
            surfaceWidth = width
            surfaceHeight = height
        } else if (surfaceView.width > 0 && surfaceView.height > 0) {
            surfaceWidth = surfaceView.width
            surfaceHeight = surfaceView.height
        }

        val player = ensureVlcInitialized() ?: return
        bindSurfaceToVlcVout(player, surfaceView, surfaceWidth, surfaceHeight)
    }

    override fun updateSurfaceSize(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        surfaceWidth = width
        surfaceHeight = height

        val player = mediaPlayer ?: return
        try {
            player.vlcVout.setWindowSize(width, height)
            logger.log(
                category = DiagnosticCategory.ENGINE,
                message = "LibVLC IVLCVout window size updated",
                details = mapOf("width" to width, "height" to height)
            )
        } catch (t: Throwable) {
            logger.log(
                category = DiagnosticCategory.ENGINE,
                message = "LibVLC updateSurfaceSize warning",
                details = mapOf("error" to t.message),
                isWarningOrError = true
            )
        }
    }

    override fun detachSurface() {
        val player = mediaPlayer
        if (player != null) {
            try {
                val vout = player.vlcVout
                vout.removeCallback(this)
                if (vout.areViewsAttached()) {
                    vout.detachViews()
                }
            } catch (_: Throwable) {
            }
        }
        attachedSurfaceView = null
        isSurfaceAttached = false
        logger.log(
            category = DiagnosticCategory.ENGINE,
            message = "LibVLC IVLCVout surface detached"
        )
    }

    override fun prepareMedia(video: VideoItem, startPositionMs: Long, autoPlay: Boolean) {
        currentVideo = video
        activeSeekRequestId = 0L
        activeSeekTargetMs = -1L
        pendingInitialPositionMs = startPositionMs.coerceAtLeast(0L)
        initialSeekAttempts = 0
        mainHandler.removeCallbacks(initialSeekRunnable)

        val player = ensureVlcInitialized()
        val vlc = libVlc
        if (player == null || vlc == null) {
            listener?.onEngineFatalError(
                engineType = EngineType.VLC,
                errorCode = "LIBVLC_INIT_FAILED",
                message = "Failed to initialize native LibVLC instance",
                isSeekRelated = false
            )
            return
        }

        // Ensure video surface is attached before starting LibVLC playback so it never plays audio-only
        val surfaceView = attachedSurfaceView
        if (surfaceView != null && !isSurfaceAttached) {
            bindSurfaceToVlcVout(player, surfaceView, surfaceWidth, surfaceHeight)
        }

        try {
            // Prefer the granted content:// URI from MediaStore/SAF. A raw filesystem
            // path is only a last-resort fallback; scoped-storage access may reject it.
            val mediaUri = video.uri ?: runCatching {
                val parsed = Uri.parse(video.path)
                if (parsed.scheme != null) parsed else Uri.fromFile(java.io.File(video.path))
            }.getOrNull()

            if (mediaUri == null) {
                listener?.onEngineFatalError(
                    engineType = EngineType.VLC,
                    errorCode = "VLC_MEDIA_URI_MISSING",
                    message = "No accessible content URI or file path was supplied for this video",
                    isSeekRelated = false
                )
                return
            }

            val media = Media(vlc, mediaUri)
            try {
                media.setHWDecoderEnabled(true, false)
                player.media = media
            } finally {
                media.release()
            }

            isPrepared = false
            isCurrentlyPlaying = false
            if (autoPlay) {
                player.play()
            } else {
                // VLC prepares asynchronously; keep READY false until Playing/Paused events.
                listener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_BUFFERING)
            }
            refreshAndApplyVlcTracks(player)
            listener?.onTimelineSnapshotChanged(captureTimelineSnapshot())
        } catch (t: Throwable) {
            logger.log(
                category = DiagnosticCategory.FALLBACK,
                message = "LibVLC prepareMedia failed",
                details = mapOf("error" to t.message),
                isWarningOrError = true
            )
            listener?.onEngineFatalError(
                engineType = EngineType.VLC,
                errorCode = "LIBVLC_PREPARE_EXCEPTION",
                message = t.message ?: "LibVLC failed to prepare media",
                isSeekRelated = false
            )
        }
    }

    override fun play() {
        val player = mediaPlayer ?: return
        try {
            player.play()
            isCurrentlyPlaying = true
            listener?.onPlaybackStateChanged(true, PlaybackEngine.STATE_READY)
        } catch (_: Throwable) {
        }
    }

    override fun pause() {
        val player = mediaPlayer ?: return
        try {
            player.pause()
            isCurrentlyPlaying = false
            listener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_READY)
        } catch (_: Throwable) {
        }
    }

    override fun stop() {
        val player = mediaPlayer ?: return
        try {
            activeSeekRequestId = 0L
            player.stop()
            isCurrentlyPlaying = false
            isPrepared = false
            listener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_IDLE)
        } catch (_: Throwable) {
        }
    }

    override fun release() {
        activeSeekRequestId = 0L
        activeSeekTargetMs = -1L
        pendingInitialPositionMs = 0L
        mainHandler.removeCallbacks(initialSeekRunnable)
        detachSurface()
        try {
            mediaPlayer?.setEventListener(null)
            mediaPlayer?.release()
            libVlc?.release()
        } catch (_: Throwable) {
        } finally {
            mediaPlayer = null
            libVlc = null
            isPrepared = false
            isCurrentlyPlaying = false
        }
    }

    override fun performEngineSeek(requestId: Long, positionMs: Long): Boolean {
        val player = mediaPlayer ?: return false
        return try {
            val seekable = player.isSeekable
            val vlcLength = player.length
            val effectiveLength = if (vlcLength > 0L) vlcLength else (currentVideo?.durationMs ?: 0L)

            if (!seekable) {
                logger.log(
                    category = DiagnosticCategory.SEEK,
                    message = "LibVLC rejected seek: isSeekable=false and length<=0",
                    details = mapOf("requestId" to requestId, "positionMs" to positionMs),
                    isWarningOrError = true
                )
                if (requestId != 0L) {
                    listener?.onEngineSeekFailed(EngineType.VLC, requestId, "LibVLC media is not seekable")
                }
                return false
            }

            val clampedMs = if (effectiveLength > 0L) {
                positionMs.coerceIn(0L, effectiveLength)
            } else {
                positionMs.coerceAtLeast(0L)
            }

            if (!isPrepared || !seekable) {
                if (requestId != 0L) {
                    listener?.onEngineSeekFailed(EngineType.VLC, requestId, "LibVLC timeline is not ready/seekable")
                }
                return false
            }

            activeSeekRequestId = requestId
            activeSeekTargetMs = if (requestId != 0L) clampedMs else -1L
            // Accurate seek (fast=false) avoids large keyframe drift on high-bitrate MKV files.
            player.setTime(clampedMs, false)

            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "LibVLC setTime(clampedMs, fast=true) dispatched",
                details = mapOf("requestId" to requestId, "clampedMs" to clampedMs)
            )

            // Completion is asynchronous and is acknowledged only by a matching
            // TimeChanged event; never report success from the pre-seek player.time value.
            true
        } catch (t: Throwable) {
            activeSeekRequestId = 0L
            activeSeekTargetMs = -1L
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "LibVLC seek exception",
                details = mapOf("requestId" to requestId, "error" to t.message),
                isWarningOrError = true
            )
            if (requestId != 0L) {
                listener?.onEngineSeekFailed(EngineType.VLC, requestId, t.message ?: "LibVLC seek error")
            }
            false
        }
    }

    override fun setPlaybackSpeed(speed: Float) {
        val player = mediaPlayer ?: return
        try {
            player.rate = speed.coerceIn(0.5f, 2.0f)
        } catch (_: Throwable) {
        }
    }

    override fun selectAudioTrack(track: AudioTrackInfo) {
        pendingDesiredAudio = track
        val player = mediaPlayer ?: return
        applyAudioTrackToPlayer(player, track)
        refreshAndApplyVlcTracks(player)
    }

    override fun selectSubtitleTrack(track: SubtitleTrackInfo) {
        pendingDesiredSubtitle = track
        val player = mediaPlayer ?: return
        applySubtitleTrackToPlayer(player, track)
        refreshAndApplyVlcTracks(player)
    }

    override fun loadExternalSubtitle(uri: Uri) {
        val player = mediaPlayer ?: return
        try {
            player.addSlave(IMedia.Slave.Type.Subtitle, uri, true)
            refreshAndApplyVlcTracks(player)
        } catch (t: Throwable) {
            logger.log(
                category = DiagnosticCategory.TRACKS,
                message = "LibVLC addSlave external subtitle failed",
                details = mapOf("uri" to uri, "error" to t.message),
                isWarningOrError = true
            )
        }
    }

    override fun captureTimelineSnapshot(): EngineTimelineSnapshot {
        val player = mediaPlayer
        val vlcTime = player?.time?.coerceAtLeast(0L) ?: 0L
        val rawLength = player?.length ?: -1L
        val vlcLength = if (rawLength > 0L) rawLength else EngineTimelineSnapshot.TIME_UNSET
        val vlcSeekable = player?.isSeekable ?: false
        val metadataDur = currentVideo?.durationMs ?: 0L

        return EngineTimelineSnapshot(
            engineType = EngineType.VLC,
            currentPositionMs = vlcTime,
            bufferedPositionMs = vlcTime,
            engineDurationMs = vlcLength,
            metadataDurationMs = metadataDur,
            isEngineSeekable = vlcSeekable,
            isTimelineReady = isPrepared,
            isMkvContainer = currentVideo?.isMkvContainer == true
        )
    }

    // --- IVLCVout.Callback & OnNewVideoLayoutListener ---

    override fun onSurfacesCreated(vlcVout: IVLCVout?) {
        isSurfaceAttached = true
        logger.log(
            category = DiagnosticCategory.ENGINE,
            message = "LibVLC onSurfacesCreated callback"
        )
    }

    override fun onSurfacesDestroyed(vlcVout: IVLCVout?) {
        isSurfaceAttached = false
        logger.log(
            category = DiagnosticCategory.ENGINE,
            message = "LibVLC onSurfacesDestroyed callback"
        )
    }

    override fun onNewVideoLayout(
        vout: IVLCVout?,
        width: Int,
        height: Int,
        visibleWidth: Int,
        visibleHeight: Int,
        sarNum: Int,
        sarDen: Int
    ) {
        if (width > 0 && height > 0) {
            listener?.onVideoSizeChanged(EngineType.VLC, width, height)
        }
    }

    private fun bindSurfaceToVlcVout(player: MediaPlayer, surfaceView: SurfaceView, width: Int, height: Int) {
        try {
            val vout = player.vlcVout
            if (vout.areViewsAttached()) {
                vout.removeCallback(this)
                vout.detachViews()
            }

            vout.setVideoView(surfaceView)
            if (width > 0 && height > 0) {
                vout.setWindowSize(width, height)
            }
            vout.addCallback(this)
            vout.attachViews(this)

            logger.log(
                category = DiagnosticCategory.ENGINE,
                message = "LibVLC IVLCVout surface attached successfully",
                details = mapOf("width" to width, "height" to height)
            )
        } catch (t: Throwable) {
            isSurfaceAttached = false
            logger.log(
                category = DiagnosticCategory.ENGINE,
                message = "LibVLC IVLCVout surface attachment failed",
                details = mapOf("error" to t.message),
                isWarningOrError = true
            )
        }
    }

    private fun applyAudioTrackToPlayer(player: MediaPlayer, desired: AudioTrackInfo): Boolean {
        return try {
            val descriptions = player.audioTracks ?: return false
            val validTracks = descriptions.filter { it.id >= 0 }
            if (validTracks.isEmpty()) return false

            val directId = desired.id.removePrefix("vlc_audio_").toIntOrNull()
            val matched = when {
                directId != null && validTracks.any { it.id == directId } ->
                    validTracks.first { it.id == directId }
                !desired.language.isNullOrBlank() ->
                    validTracks.firstOrNull {
                        it.name?.contains(desired.language, ignoreCase = true) == true ||
                            it.name?.contains(desired.name, ignoreCase = true) == true
                    }
                else ->
                    validTracks.firstOrNull { it.name.equals(desired.name, ignoreCase = true) }
                        ?: validTracks.getOrNull(desired.trackIndex.coerceAtLeast(0))
            }

            if (matched != null) {
                player.audioTrack = matched.id
                pendingDesiredAudio = null
                logger.log(
                    category = DiagnosticCategory.TRACKS,
                    message = "LibVLC mapped and selected audio track",
                    details = mapOf("requested" to desired.name, "selectedId" to matched.id, "selectedName" to matched.name)
                )
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun applySubtitleTrackToPlayer(player: MediaPlayer, desired: SubtitleTrackInfo): Boolean {
        return try {
            if (desired.id == "off") {
                player.spuTrack = -1
                pendingDesiredSubtitle = null
                return true
            }

            val descriptions = player.spuTracks ?: return false
            val validTracks = descriptions.filter { it.id >= 0 }
            if (validTracks.isEmpty()) return false

            val directId = desired.id.removePrefix("vlc_sub_").toIntOrNull()
            val matched = when {
                directId != null && validTracks.any { it.id == directId } ->
                    validTracks.first { it.id == directId }
                !desired.language.isNullOrBlank() ->
                    validTracks.firstOrNull {
                        it.name?.contains(desired.language, ignoreCase = true) == true ||
                            it.name?.contains(desired.name, ignoreCase = true) == true
                    }
                else ->
                    validTracks.firstOrNull { it.name.equals(desired.name, ignoreCase = true) }
                        ?: validTracks.getOrNull(desired.trackIndex.coerceAtLeast(0))
            }

            if (matched != null) {
                player.spuTrack = matched.id
                pendingDesiredSubtitle = null
                logger.log(
                    category = DiagnosticCategory.TRACKS,
                    message = "LibVLC mapped and selected subtitle track",
                    details = mapOf("requested" to desired.name, "selectedId" to matched.id, "selectedName" to matched.name)
                )
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun refreshAndApplyVlcTracks(player: MediaPlayer) {
        try {
            pendingDesiredAudio?.let { applyAudioTrackToPlayer(player, it) }
            pendingDesiredSubtitle?.let { applySubtitleTrackToPlayer(player, it) }

            val audioList = mutableListOf<AudioTrackInfo>()
            val subtitleList = mutableListOf<SubtitleTrackInfo>()

            val currentAudioId = player.audioTrack
            player.audioTracks?.forEachIndexed { index, desc ->
                if (desc != null && desc.id >= 0) {
                    audioList.add(
                        AudioTrackInfo(
                            id = "vlc_audio_${desc.id}",
                            name = desc.name ?: "Audio Track ${index + 1}",
                            isSelected = (desc.id == currentAudioId),
                            trackIndex = desc.id
                        )
                    )
                }
            }

            val currentSpuId = player.spuTrack
            var anySpuSelected = false
            player.spuTracks?.forEachIndexed { index, desc ->
                if (desc != null && desc.id >= 0) {
                    val selected = (desc.id == currentSpuId)
                    if (selected) anySpuSelected = true
                    subtitleList.add(
                        SubtitleTrackInfo(
                            id = "vlc_sub_${desc.id}",
                            name = desc.name ?: "Subtitle ${index + 1}",
                            isSelected = selected,
                            trackIndex = desc.id
                        )
                    )
                }
            }

            val finalSubtitles = buildList {
                add(
                    SubtitleTrackInfo(
                        id = "off",
                        name = "Disable Subtitles",
                        isSelected = !anySpuSelected
                    )
                )
                addAll(subtitleList)
            }

            listener?.onTracksUpdated(audioList, finalSubtitles)
        } catch (_: Throwable) {
        }
    }

    private fun ensureVlcInitialized(): MediaPlayer? {
        mediaPlayer?.let { return it }
        return try {
            val options = arrayListOf(
                "--avcodec-fast",
                "--drop-late-frames",
                "--skip-frames",
                "--audio-time-stretch"
            )
            val vlc = LibVLC(context, options)
            libVlc = vlc
            MediaPlayer(vlc).also { mp ->
                mp.setEventListener(vlcEventListener)
                mediaPlayer = mp
            }
        } catch (t: Throwable) {
            logger.log(
                category = DiagnosticCategory.FALLBACK,
                message = "LibVLC initialization exception",
                details = mapOf("error" to t.message),
                isWarningOrError = true
            )
            null
        }
    }
}
