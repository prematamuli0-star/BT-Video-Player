package com.bt.videoplayer.domain.model

data class FolderItem(
    val name: String,
    val path: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val latestVideoDateSec: Long
)
