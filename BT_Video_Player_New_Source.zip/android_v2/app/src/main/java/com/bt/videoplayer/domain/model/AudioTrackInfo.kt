package com.bt.videoplayer.domain.model

data class AudioTrackInfo(
    val id: String,
    val name: String,
    val language: String? = null,
    val codec: String? = null,
    val channels: Int = 2,
    val sampleRate: Int = 48000,
    val isSelected: Boolean = false,
    val groupIndex: Int = -1,
    val trackIndex: Int = -1
)
