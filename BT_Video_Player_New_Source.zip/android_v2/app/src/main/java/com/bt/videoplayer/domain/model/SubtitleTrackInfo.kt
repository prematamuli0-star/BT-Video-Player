package com.bt.videoplayer.domain.model

import android.net.Uri

data class SubtitleTrackInfo(
    val id: String,
    val name: String,
    val language: String? = null,
    val uri: Uri? = null,
    val mimeType: String? = null,
    val isExternal: Boolean = false,
    val isSelected: Boolean = false,
    val groupIndex: Int = -1,
    val trackIndex: Int = -1
)
