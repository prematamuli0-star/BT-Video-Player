package com.bt.videoplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.bt.videoplayer.data.preferences.PlayerPreferences
import com.bt.videoplayer.domain.model.FolderItem
import com.bt.videoplayer.domain.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaStoreVideoRepository(
    private val context: Context,
    private val preferences: PlayerPreferences
) {
    suspend fun scanAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<VideoItem>()

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val displayCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val widthCol = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Untitled Video"
                    val displayName = cursor.getString(displayCol) ?: title
                    val path = cursor.getString(dataCol) ?: ""
                    val durationMs = cursor.getLong(durationCol).coerceAtLeast(0L)
                    val sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val dateAddedSec = cursor.getLong(dateCol).coerceAtLeast(0L)
                    val mimeType = if (mimeCol != -1) cursor.getString(mimeCol) ?: "video/*" else "video/*"
                    val width = if (widthCol != -1) cursor.getInt(widthCol) else 0
                    val height = if (heightCol != -1) cursor.getInt(heightCol) else 0

                    val folderName = try {
                        File(path).parentFile?.name ?: "Internal Storage"
                    } catch (_: Exception) {
                        "Videos"
                    }

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    videos.add(
                        VideoItem(
                            id = id,
                            title = title,
                            displayName = displayName,
                            uri = contentUri,
                            path = path,
                            durationMs = durationMs,
                            sizeBytes = sizeBytes,
                            dateAddedSec = dateAddedSec,
                            folderName = folderName,
                            mimeType = mimeType,
                            width = width,
                            height = height,
                            isFavorite = preferences.isFavorite(id),
                            lastPositionMs = preferences.getLastPosition(id),
                            isSafExternal = false
                        )
                    )
                }
            }
        } catch (_: Exception) {
            // Safely return whatever was collected if permission is revoked mid-query
        }

        videos
    }

    suspend fun groupFolders(videos: List<VideoItem>): List<FolderItem> = withContext(Dispatchers.Default) {
        videos
            .groupBy { it.folderName }
            .map { (folderName, items) ->
                val samplePath = items.firstOrNull()?.path.orEmpty()
                val folderPath = try {
                    File(samplePath).parent ?: folderName
                } catch (_: Exception) {
                    folderName
                }
                FolderItem(
                    name = folderName,
                    path = folderPath,
                    videoCount = items.size,
                    totalSizeBytes = items.sumOf { it.sizeBytes },
                    latestVideoDateSec = items.maxOfOrNull { it.dateAddedSec } ?: 0L
                )
            }
            .sortedByDescending { it.videoCount }
    }

    fun toggleFavorite(videoId: Long): Boolean = preferences.toggleFavorite(videoId)

    fun saveResumePosition(videoId: Long, positionMs: Long) {
        preferences.saveLastPosition(videoId, positionMs)
    }
}
