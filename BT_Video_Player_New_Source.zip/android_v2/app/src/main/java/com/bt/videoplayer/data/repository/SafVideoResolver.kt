package com.bt.videoplayer.data.repository

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.bt.videoplayer.data.preferences.PlayerPreferences
import com.bt.videoplayer.domain.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Resolves video metadata (display name, file size, duration, dimensions, MIME type)
 * for Storage Access Framework (SAF) document URIs and external VIEW intent URIs.
 */
class SafVideoResolver(
    private val context: Context,
    private val preferences: PlayerPreferences
) {
    suspend fun resolveUri(uri: Uri): VideoItem = withContext(Dispatchers.IO) {
        // Persist read permission if offered by SAF picker
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Non-persistable URI (e.g. one-time ACTION_VIEW intent); proceed with active grant
        }

        var displayName = uri.lastPathSegment ?: "External Video"
        var sizeBytes = 0L

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx != -1 && !cursor.isNull(nameIdx)) {
                        displayName = cursor.getString(nameIdx)
                    }
                    if (sizeIdx != -1 && !cursor.isNull(sizeIdx)) {
                        sizeBytes = cursor.getLong(sizeIdx).coerceAtLeast(0L)
                    }
                }
            }
        } catch (_: Exception) {
        }

        val mimeType = try {
            context.contentResolver.getType(uri) ?: inferMimeType(displayName)
        } catch (_: Exception) {
            inferMimeType(displayName)
        }

        var durationMs = 0L
        var width = 0
        var height = 0

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull()?.coerceAtLeast(0) ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        } catch (_: Exception) {
            // Large or unindexed MKV over SAF may not yield metadata via MediaMetadataRetriever
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        val syntheticId = uri.toString().hashCode().toLong() and 0x7FFFFFFFL
        val title = displayName.substringBeforeLast('.')

        VideoItem(
            id = syntheticId,
            title = title,
            displayName = displayName,
            uri = uri,
            path = uri.toString(),
            durationMs = durationMs,
            sizeBytes = sizeBytes,
            dateAddedSec = System.currentTimeMillis() / 1000L,
            folderName = "SAF / External",
            mimeType = mimeType,
            width = width,
            height = height,
            isFavorite = preferences.isFavorite(syntheticId),
            lastPositionMs = preferences.getLastPosition(syntheticId),
            isSafExternal = true
        )
    }

    private fun inferMimeType(fileName: String): String {
        val lower = fileName.lowercase()
        return when {
            lower.endsWith(".mkv") -> "video/x-matroska"
            lower.endsWith(".mp4") || lower.endsWith(".m4v") -> "video/mp4"
            lower.endsWith(".webm") -> "video/webm"
            lower.endsWith(".avi") -> "video/x-msvideo"
            lower.endsWith(".ts") || lower.endsWith(".m2ts") -> "video/mp2t"
            else -> "video/*"
        }
    }
}
