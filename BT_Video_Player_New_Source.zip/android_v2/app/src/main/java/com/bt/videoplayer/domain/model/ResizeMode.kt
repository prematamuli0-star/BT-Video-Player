package com.bt.videoplayer.domain.model

import androidx.media3.ui.AspectRatioFrameLayout

enum class ResizeMode(val label: String, val shortTag: String, val media3ResizeMode: Int) {
    FIT("Fit to Screen", "FIT", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill (Crop)", "FILL", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH("Stretch", "STR", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    FIXED_WIDTH("Fit Width", "WID", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
    FIXED_HEIGHT("Fit Height", "HGT", AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT),
    ORIGINAL_100("100% Original", "100%", AspectRatioFrameLayout.RESIZE_MODE_FIT);

    fun next(): ResizeMode {
        val all = entries
        return all[(ordinal + 1) % all.size]
    }
}
