package com.bt.videoplayer.domain.model

import android.net.Uri
import java.util.Locale

data class VideoItem(
    val id: Long,
    val title: String,
    val displayName: String,
    val uri: Uri? = null,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val folderName: String,
    val mimeType: String = "video/*",
    val width: Int = 0,
    val height: Int = 0,
    val isFavorite: Boolean = false,
    val lastPositionMs: Long = 0L,
    val isSafExternal: Boolean = false
) {
    val isMkvContainer: Boolean
        get() = displayName.endsWith(".mkv", ignoreCase = true) ||
            path.endsWith(".mkv", ignoreCase = true) ||
            mimeType.contains("matroska", ignoreCase = true) ||
            mimeType.contains("x-matroska", ignoreCase = true)

    val formattedDuration: String
        get() = formatTimestampMs(durationMs)

    val formattedSize: String
        get() {
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
                mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
                else -> String.format(Locale.US, "%.0f KB", kb.coerceAtLeast(0.0))
            }
        }

    val resolutionLabel: String
        get() {
            val maxDim = maxOf(width, height)
            val minDim = minOf(width, height)
            return when {
                maxDim >= 3840 || minDim >= 2160 -> "4K"
                maxDim >= 1920 || minDim >= 1080 -> "1080p"
                maxDim >= 1280 || minDim >= 720 -> "720p"
                width > 0 && height > 0 -> "${minDim}p"
                else -> "HD"
            }
        }

    companion object {
        fun formatTimestampMs(ms: Long): String {
            val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
            val hours = totalSeconds / 3600L
            val minutes = (totalSeconds % 3600L) / 60L
            val seconds = totalSeconds % 60L
            return if (hours > 0L) {
                String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }
    }
}
