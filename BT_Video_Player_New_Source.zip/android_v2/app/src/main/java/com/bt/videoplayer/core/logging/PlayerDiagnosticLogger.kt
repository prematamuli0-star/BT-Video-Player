package com.bt.videoplayer.core.logging

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.CopyOnWriteArrayList

enum class DiagnosticCategory {
    SEEK,
    ENGINE,
    TIMELINE,
    FALLBACK,
    TRACKS,
    SESSION
}

data class DiagnosticEvent(
    val timestampMs: Long,
    val category: DiagnosticCategory,
    val message: String,
    val details: Map<String, String> = emptyMap(),
    val isWarningOrError: Boolean = false
)

/**
 * Thread-safe diagnostic logger with an in-memory bounded ring buffer (max 250 entries)
 * and optional Android Logcat emission. Safe to use in both JVM unit tests and Android runtime.
 */
class PlayerDiagnosticLogger(
    private val maxEntries: Int = 250,
    private val enableLogcat: Boolean = false,
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private val buffer = CopyOnWriteArrayList<DiagnosticEvent>()
    private val _events = MutableStateFlow<List<DiagnosticEvent>>(emptyList())
    val events: StateFlow<List<DiagnosticEvent>> = _events.asStateFlow()

    fun log(
        category: DiagnosticCategory,
        message: String,
        details: Map<String, Any?> = emptyMap(),
        isWarningOrError: Boolean = false
    ) {
        val cleanDetails = details.mapValues { it.value?.toString() ?: "null" }
        val event = DiagnosticEvent(
            timestampMs = clockMs(),
            category = category,
            message = message,
            details = cleanDetails,
            isWarningOrError = isWarningOrError
        )

        synchronized(buffer) {
            buffer.add(event)
            while (buffer.size > maxEntries) {
                buffer.removeAt(0)
            }
            _events.value = buffer.toList()
        }

        if (enableLogcat) {
            try {
                val formatted = buildString {
                    append("[")
                    append(category.name)
                    append("] ")
                    append(message)
                    if (cleanDetails.isNotEmpty()) {
                        append(" | ")
                        append(cleanDetails.entries.joinToString(", ") { "${it.key}=${it.value}" })
                    }
                }
                if (isWarningOrError) {
                    Log.w(TAG, formatted)
                } else {
                    Log.d(TAG, formatted)
                }
            } catch (_: Throwable) {
                // Ignored in pure JVM unit test environment where android.util.Log is stubbed
            }
        }
    }

    fun clear() {
        synchronized(buffer) {
            buffer.clear()
            _events.value = emptyList()
        }
    }

    companion object {
        private const val TAG = "BTPlayer2_Diag"
    }
}
