package com.btplayer.video

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.util.LruCache
import java.util.concurrent.Executors
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

data class VideoItem(val uri: Uri, val title: String, val duration: Long, val folder: String)
data class VideoFolder(val name: String, val videos: List<VideoItem>)

class MainActivity : AppCompatActivity() {
    private val videos = mutableListOf<VideoItem>()
    private val thumbnailExecutor = Executors.newFixedThreadPool(2)
    private val thumbnailCache = object : LruCache<String, Bitmap>(12) {}
    private var shown = mutableListOf<VideoItem>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var countView: TextView
    private lateinit var tabs: LinearLayout
    private var tab = "Folders"
    private val purple = Color.rgb(108, 53, 213)
    private val requestCode = 81

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep app content below the Android status bar on edge-to-edge Android versions.
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.rgb(40, 40, 40)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()
        if (hasPermission()) loadVideos() else requestPermission()
    }

    private fun hasPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        ActivityCompat.requestPermissions(this, arrayOf(p), requestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadVideos()
        else Toast.makeText(this, "Allow video access to show videos", Toast.LENGTH_LONG).show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(18), dp(16), 0)
        }

        // Header uses weighted text and a fixed logo/settings area to prevent title overlap.
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(purple, 22)
            clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(62), dp(62)))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(4), 0) }
        heading.addView(TextView(this).apply {
            text = "BT VIDEO PLAYER"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(purple); maxLines = 1; setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END
        })
        heading.addView(TextView(this).apply {
            text = "Created by BT Player • Video for everyone"; textSize = 11f
            setTextColor(Color.DKGRAY); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        })
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = TextView(this).apply {
            text = "⚙"; textSize = 27f; setTextColor(purple); gravity = Gravity.CENTER
            contentDescription = "Settings"
            setOnClickListener { Toast.makeText(this@MainActivity, "Settings will be added in a future update", Toast.LENGTH_SHORT).show() }
        }
        header.addView(settings, LinearLayout.LayoutParams(dp(38), dp(54)))
        root.addView(header)

        tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(16), 0, dp(10))
        }
        listOf("Folders", "Videos", "Recent", "Favourites").forEach { label ->
            val b = TextView(this).apply {
                text = label; textSize = 13f; gravity = Gravity.CENTER
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setTextColor(if (label == tab) Color.WHITE else Color.DKGRAY)
                background = if (label == tab) rounded(purple, 28) else null
                setOnClickListener { tab = label; refreshList() }
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabs)

        search = EditText(this).apply {
            hint = "Search folders and videos…"; textSize = 15f; setSingleLine(true)
            setPadding(dp(16), 0, dp(12), 0); background = rounded(Color.rgb(247, 247, 250), 32)
            setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search, 0, 0, 0)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        search.addTextChangedListener(SimpleTextWatcher { refreshList() })

        countView = TextView(this).apply {
            textSize = 14f; setTextColor(Color.DKGRAY); setPadding(dp(4), dp(12), 0, dp(7))
        }
        root.addView(countView)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadVideos() {
        videos.clear()
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        try {
            contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val folderI = c.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idI)
                    val uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString())
                    videos.add(VideoItem(uri, c.getString(nameI) ?: "Video", c.getLong(durI),
                        if (folderI >= 0) c.getString(folderI)?.takeIf { it.isNotBlank() } ?: "Videos" else "Videos"))
                }
            }
        } catch (_: Exception) { }
        refreshList()
    }

    private fun refreshList() {
        if (!::list.isInitialized) return
        // Update selected tab appearance.
        for (i in 0 until tabs.childCount) {
            val b = tabs.getChildAt(i) as TextView
            b.setTextColor(if (b.text.toString() == tab) Color.WHITE else Color.DKGRAY)
            b.background = if (b.text.toString() == tab) rounded(purple, 28) else null
        }
        val q = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        shown = videos.filter { it.title.lowercase().contains(q) || it.folder.lowercase().contains(q) }.toMutableList()
        list.removeAllViews()

        if (tab == "Folders") {
            val folders = shown.groupBy { it.folder }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
            countView.text = "${folders.size} folders • ${shown.size} videos"
            if (folders.isEmpty()) showEmpty("No folders found on this phone")
            folders.forEach { (name, items) -> addFolderRow(VideoFolder(name, items)) }
        } else {
            val items = when (tab) {
                "Recent" -> shown.take(30)
                "Favourites" -> emptyList() // Favorites are not yet persisted in this initial source.
                else -> shown
            }
            countView.text = "${items.size} videos on this phone"
            if (items.isEmpty()) showEmpty(if (tab == "Favourites") "No favourites yet" else "No videos found on this phone")
            items.forEachIndexed { index, item -> addVideoRow(item, index + 1) }
        }
    }

    private fun addFolderRow(folder: VideoFolder) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(10), dp(2), dp(10))
            setOnClickListener {
                tab = "Videos"
                search.setText(folder.name)
                search.setSelection(search.text.length)
                refreshList()
            }
        }
        val icon = TextView(this).apply {
            text = "📁"; textSize = 34f; gravity = Gravity.CENTER
            background = rounded(Color.rgb(250, 247, 255), 12)
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(70), dp(62)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(4), 0) }
        info.addView(TextView(this).apply {
            text = folder.name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(25, 25, 30)); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        })
        info.addView(TextView(this).apply {
            text = "${folder.videos.size} videos"; textSize = 12f; setTextColor(Color.GRAY)
        })
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply { text = "›"; textSize = 28f; setTextColor(Color.GRAY); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(28), dp(48)))
        list.addView(row)
        addDivider()
    }

    private fun addVideoRow(item: VideoItem, index: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
            setOnClickListener {
                startActivity(Intent(this@MainActivity, PlayerActivity::class.java)
                    .putExtra("uri", item.uri.toString()).putExtra("title", item.title))
            }
        }
        val num = TextView(this).apply { text = "$index"; textSize = 13f; setTextColor(Color.GRAY); gravity = Gravity.CENTER }
        row.addView(num, LinearLayout.LayoutParams(dp(24), dp(58)))

        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(35, 43, 68), 12)
            clipToOutline = true
            setImageResource(android.R.drawable.ic_media_play)
            tag = item.uri.toString()
            val key = item.uri.toString()
            val cached = thumbnailCache.get(key)
            if (cached != null) {
                setImageBitmap(cached)
            } else {
                thumbnailExecutor.execute {
                    val bitmap = getVideoThumbnail(item.uri)
                    if (bitmap != null) {
                        thumbnailCache.put(key, bitmap)
                        runOnUiThread {
                            if (tag == key) setImageBitmap(bitmap)
                        }
                    }
                }
            }
        }
        row.addView(thumb, LinearLayout.LayoutParams(dp(76), dp(58)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(4), 0) }
        info.addView(TextView(this).apply {
            text = item.title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(25, 25, 30)); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        })
        info.addView(TextView(this).apply {
            text = "${formatDuration(item.duration)} • ${item.folder}"; textSize = 12f
            setTextColor(Color.GRAY); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        })
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply {
            text = "⋮"; textSize = 25f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
            setOnClickListener { Toast.makeText(this@MainActivity, item.title, Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(dp(28), dp(52)))
        list.addView(row)
        addDivider()
    }

    private fun getVideoThumbnail(uri: Uri): Bitmap? {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            val bitmap = retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            retriever.release()
            bitmap
        } catch (_: Exception) { null }
    }

    private fun showEmpty(message: String) {
        list.addView(TextView(this).apply {
            text = message; textSize = 15f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
            setPadding(0, dp(40), 0, dp(40))
        })
    }
    private fun addDivider() {
        list.addView(View(this).apply { setBackgroundColor(Color.rgb(230, 230, 230)) }, LinearLayout.LayoutParams(-1, dp(1)))
    }
    private fun formatDuration(ms: Long): String {
        val s = ms / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
}
