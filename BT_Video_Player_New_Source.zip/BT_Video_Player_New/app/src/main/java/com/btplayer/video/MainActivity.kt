package com.btplayer.video

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

 data class VideoItem(val uri: Uri, val title: String, val duration: Long, val folder: String)

class MainActivity : AppCompatActivity() {
    private val videos = mutableListOf<VideoItem>()
    private var shown = mutableListOf<VideoItem>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var tab = "All Videos"
    private val purple = Color.rgb(108, 53, 213)
    private val blue = Color.rgb(52, 120, 246)
    private val requestCode = 81

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.rgb(40,40,40)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        buildUi()
        if (hasPermission()) loadVideos() else requestPermission()
    }

    private fun hasPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }
    private fun requestPermission() {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE
        ActivityCompat.requestPermissions(this, arrayOf(p), requestCode)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadVideos()
        else Toast.makeText(this, "Allow video access to show videos", Toast.LENGTH_LONG).show()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(dp(18), dp(14), dp(18), 0) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply { text = "BT"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; background = rounded(purple, 24); layoutParams = LinearLayout.LayoutParams(dp(62), dp(62)) }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        heading.addView(TextView(this).apply { text = "BT VIDEO PLAYER"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD; setTextColor(purple) })
        heading.addView(TextView(this).apply { text = "Created by BT Player • Video for everyone"; textSize = 12f; setTextColor(Color.DKGRAY) })
        val settings = TextView(this).apply { text = "⚙"; textSize = 27f; setTextColor(purple); gravity = Gravity.CENTER }
        header.addView(logo); header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(settings)
        root.addView(header)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(18), 0, dp(10)) }
        listOf("All Videos", "Folders", "Recent", "Favourites").forEach { label ->
            val b = TextView(this).apply { text = label; textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(10), dp(10), dp(10), dp(10)); setTextColor(if (label == tab) Color.WHITE else Color.DKGRAY); background = if (label == tab) rounded(purple, 28) else null; setOnClickListener { tab = label; refreshList() } }
            tabs.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabs)
        search = EditText(this).apply { hint = "Search videos, folders..."; textSize = 15f; singleLine = true; setPadding(dp(16),0,dp(12),0); background = rounded(Color.rgb(247,247,250), 32); setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search,0,0,0) }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        search.addTextChangedListener(SimpleTextWatcher { refreshList() })
        val count = TextView(this).apply { tag = "count"; textSize = 14f; setTextColor(Color.DKGRAY); setPadding(dp(4), dp(14), 0, dp(8)) }
        root.addView(count)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadVideos() {
        videos.clear()
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        try {
            contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, sort)?.use { c ->
                val idI = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durI = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val folderI = c.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idI)
                    val uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString())
                    videos.add(VideoItem(uri, c.getString(nameI) ?: "Video", c.getLong(durI), if (folderI >= 0) c.getString(folderI) ?: "Videos" else "Videos"))
                }
            }
        } catch (_: Exception) { }
        refreshList()
    }

    private fun refreshList() {
        if (!::list.isInitialized) return
        val q = if (::search.isInitialized) search.text.toString().trim().lowercase() else ""
        shown = when (tab) {
            "Folders" -> videos.distinctBy { it.folder }.toMutableList()
            "Recent" -> videos.take(30).toMutableList()
            else -> videos.toMutableList()
        }.filter { it.title.lowercase().contains(q) || it.folder.lowercase().contains(q) }.toMutableList()
        list.removeAllViews()
        findViewWithTag<TextView>("count")?.text = if (tab == "Folders") "${shown.size} folders" else "${shown.size} videos on this phone"
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply { text = if (videos.isEmpty()) "No videos found on this phone" else "No matching videos"; textSize = 15f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, dp(40), 0, dp(40)) })
        }
        shown.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8)); setOnClickListener {
                if (tab == "Folders") { tab = "All Videos"; search.setText(item.folder) } else { startActivity(Intent(this@MainActivity, PlayerActivity::class.java).putExtra("uri", item.uri.toString()).putExtra("title", item.title)) }
            } }
            val num = TextView(this).apply { text = "${index + 1}"; textSize = 13f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(26), dp(50)) }
            val thumb = TextView(this).apply { text = "▶"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = rounded(Color.rgb(35,43,68), 12); layoutParams = LinearLayout.LayoutParams(dp(76), dp(58)) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(4), 0) }
            info.addView(TextView(this).apply { text = if (tab == "Folders") item.folder else item.title; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(25,25,30)); maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END })
            info.addView(TextView(this).apply { text = if (tab == "Folders") "Folder • videos" else "${formatDuration(item.duration)} • ${item.folder}"; textSize = 12f; setTextColor(Color.GRAY); maxLines = 1 })
            val more = TextView(this).apply { text = "⋮"; textSize = 25f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setOnClickListener { Toast.makeText(this@MainActivity, item.title, Toast.LENGTH_SHORT).show() } }
            row.addView(num); row.addView(thumb); row.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(more, LinearLayout.LayoutParams(dp(28), dp(52)))
            list.addView(row)
            val line = View(this).apply { setBackgroundColor(Color.rgb(230,230,230)) }; list.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }
    private fun formatDuration(ms: Long): String { val s = ms / 1000; return String.format("%d:%02d", s / 60, s % 60) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
}
