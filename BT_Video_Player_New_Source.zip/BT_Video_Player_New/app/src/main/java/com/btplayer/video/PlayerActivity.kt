package com.btplayer.video

import android.content.ContentValues
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private lateinit var titleView: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var floatingBar: LinearLayout
    private lateinit var centerBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var seekBar: SeekBar
    private lateinit var currentTimeView: TextView
    private lateinit var durationView: TextView
    private lateinit var playPauseButton: TextView
    private val uiHandler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private val updateProgress = object : Runnable {
        override fun run() {
            val exo = player
            if (exo != null && !userSeeking) {
                val duration = exo.duration.coerceAtLeast(0L)
                seekBar.max = if (duration > Int.MAX_VALUE) Int.MAX_VALUE else duration.toInt().coerceAtLeast(1)
                seekBar.progress = exo.currentPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                currentTimeView.text = formatTime(exo.currentPosition)
                durationView.text = formatTime(duration)
                playPauseButton.text = if (exo.isPlaying) "Ⅱ" else "▶"
            }
            uiHandler.postDelayed(this, 500)
        }
    }
    private var hideControlsTask: Runnable? = null
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var speedIndex = 0
    private val speeds = floatArrayOf(1f, 1.25f, 1.5f, 2f, 0.75f)
    private var controlsVisible = true
    private var isLandscape = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insets = WindowInsetsControllerCompat(window, window.decorView)
        insets.hide(WindowInsetsCompat.Type.systemBars())
        insets.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        val frame = FrameLayout(this)
        playerView = PlayerView(this).apply {
            useController = false
            setKeepContentOnPlayerReset(true)
        }
        overlay = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(32, 18, 32, 18); visibility = View.GONE
            background = rounded(Color.argb(155, 0, 0, 0), 18)
        }
        frame.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(10), dp(8)); background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(170,0,0,0), Color.TRANSPARENT))
        }
        val back = textButton("‹", 34) { finishPlayer() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(42), dp(48)))
        titleView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(dp(8),0,dp(6),0) }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, dp(48), 1f))
        topBar.addView(textButton("♫", 22) { Toast.makeText(this, "Audio track options are available when the video contains multiple audio tracks", Toast.LENGTH_SHORT).show() })
        topBar.addView(textButton("CC", 15) { playerView.showController() })
        topBar.addView(textButton("HW+", 14) { Toast.makeText(this, "Hardware decoding is managed automatically by the player", Toast.LENGTH_SHORT).show() })
        topBar.addView(textButton("⋮", 26) { showMoreMenu() })
        frame.addView(topBar, FrameLayout.LayoutParams(-1, dp(64), Gravity.TOP))

        floatingBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6)); background = rounded(Color.argb(145, 15, 22, 35), 40)
        }
        floatingBar.addView(circleButton("☷") { Toast.makeText(this, "Equalizer is not available in this build", Toast.LENGTH_SHORT).show() })
        floatingBar.addView(circleButton("1X") { cycleSpeed() })
        floatingBar.addView(circleButton("▣") { takeScreenshot() })
        floatingBar.addView(circleButton("♧") { Toast.makeText(this, "Audio output follows your phone's audio settings", Toast.LENGTH_SHORT).show() })
        floatingBar.addView(circleButton("▱") { toggleOrientation() })
        floatingBar.addView(circleButton("›") { showAllControls() })
        val midParams = FrameLayout.LayoutParams(-2, dp(56), Gravity.TOP or Gravity.START).apply { topMargin = dp(76); leftMargin = dp(12) }
        frame.addView(floatingBar, midParams)

        // MX-style center transport controls.
        centerBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.argb(70, 0, 0, 0), 36)
        }
        centerBar.addView(centerButton("|◀", 27) { seekRelative(-10_000L) })
        centerBar.addView(centerButton("↶₅", 28) { seekRelative(-5_000L) })
        playPauseButton = centerButton("▶", 30) { togglePlayPause() }
        playPauseButton.background = rounded(Color.WHITE, 100)
        playPauseButton.setTextColor(Color.BLACK)
        centerBar.addView(playPauseButton)
        centerBar.addView(centerButton("↷₁₅", 28) { seekRelative(15_000L) })
        centerBar.addView(centerButton("▶|", 27) { seekRelative(30_000L) })
        frame.addView(centerBar, FrameLayout.LayoutParams(-2, dp(68), Gravity.CENTER))

        // Bottom seek bar, timestamps and utility buttons.
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(205, 0, 0, 0)))
        }
        seekBar = SeekBar(this).apply {
            max = 1
            progress = 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar) { userSeeking = true; showAllControls() }
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) currentTimeView.text = formatTime(progress.toLong())
                }
                override fun onStopTrackingTouch(seekBar: SeekBar) {
                    player?.seekTo(seekBar.progress.toLong()); userSeeking = false; scheduleHideControls()
                }
            })
        }
        bottomBar.addView(seekBar, LinearLayout.LayoutParams(-1, dp(32)))
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        currentTimeView = TextView(this).apply { text = "00:00"; textSize = 13f; setTextColor(Color.WHITE) }
        durationView = TextView(this).apply { text = "00:00"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.END }
        timeRow.addView(currentTimeView, LinearLayout.LayoutParams(0, dp(30), 1f))
        timeRow.addView(textButton("CC", 15) { showSubtitleInfo() }, LinearLayout.LayoutParams(dp(42), dp(34)))
        timeRow.addView(textButton("⚙", 22) { showMoreMenu() }, LinearLayout.LayoutParams(dp(42), dp(34)))
        timeRow.addView(textButton("⛶", 24) { toggleOrientation() }, LinearLayout.LayoutParams(dp(42), dp(34)))
        timeRow.addView(durationView, LinearLayout.LayoutParams(-2, dp(30)))
        bottomBar.addView(timeRow, LinearLayout.LayoutParams(-1, dp(34)))
        frame.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(82), Gravity.BOTTOM))
        frame.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finishPlayer() }
        })
        playerView.setOnTouchListener { _, event -> handleTouch(event) }
        uiHandler.post(updateProgress)
        val uri = intent.getStringExtra("uri")?.let(Uri::parse)
        if (uri == null) { finish(); return }
        titleView.text = intent.getStringExtra("title") ?: uri.lastPathSegment ?: "BT Video Player"
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri)); exo.prepare(); exo.playWhenReady = true
            exo.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) { playPauseButton.text = if (isPlaying) "Ⅱ" else "▶" }
                override fun onPlaybackStateChanged(playbackState: Int) { scheduleHideControls() }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "Unable to play this video", Toast.LENGTH_LONG).show()
                }
            })
        }
    }

    private fun textButton(label: String, size: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = size.toFloat(); setTextColor(Color.WHITE); gravity = Gravity.CENTER
        isClickable = true; isFocusable = true; setPadding(dp(6), 0, dp(6), 0); setOnClickListener { action() }
        // Use a regular drawable background for reliable Kotlin/Android SDK compilation.
        background = rounded(Color.TRANSPARENT, 12)
    }
    private fun circleButton(label: String, action: () -> Unit): TextView = textButton(label, if (label == "1X") 16 else 22, action).apply {
        background = rounded(Color.argb(190, 38, 47, 62), 100)
        val params = LinearLayout.LayoutParams(dp(44), dp(44)); params.setMargins(dp(4),0,dp(4),0); layoutParams = params
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % speeds.size
        player?.setPlaybackSpeed(speeds[speedIndex])
        Toast.makeText(this, "Playback speed ${speeds[speedIndex]}X", Toast.LENGTH_SHORT).show()
    }
    private fun toggleOrientation() {
        isLandscape = !isLandscape
        requestedOrientation = if (isLandscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }
    private fun takeScreenshot() {
        try {
            val bitmap = Bitmap.createBitmap(playerView.width, playerView.height, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            playerView.draw(canvas)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "BTVideo_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BT Video Player")
            }
            val imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (imageUri != null) contentResolver.openOutputStream(imageUri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            bitmap.recycle()
            Toast.makeText(this, if (imageUri != null) "Screenshot saved to Pictures/BT Video Player" else "Could not save screenshot", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "Could not capture screenshot", Toast.LENGTH_SHORT).show() }
    }
    private fun showMoreMenu() {
        val options = arrayOf("Playback speed", "Restart video", "Show controls")
        android.app.AlertDialog.Builder(this).setTitle("BT Video Player").setItems(options) { _, which ->
            when (which) {
                0 -> cycleSpeed()
                1 -> { player?.seekTo(0); player?.play() }
                2 -> showAllControls()
            }
        }.show()
    }
    private fun finishPlayer() { player?.pause(); finish(); overridePendingTransition(0, 0) }

    private fun handleTouch(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downTime = System.currentTimeMillis(); return false }
            MotionEvent.ACTION_UP -> {
                val dx = e.x - downX; val dy = e.y - downY
                val duration = System.currentTimeMillis() - downTime
                if (abs(dx) > 65 && abs(dx) > abs(dy) * 1.25f) {
                    val base = if (abs(dx) > playerView.width * 0.55f) 30000L else if (abs(dx) > playerView.width * 0.28f) 20000L else 10000L
                    val jump = if (dx > 0) base else -base
                    player?.let { it.seekTo((it.currentPosition + jump).coerceIn(0L, it.duration.takeIf { d -> d > 0 } ?: Long.MAX_VALUE)) }
                    showOverlay(if (dx > 0) "+${base/1000}s  ▶" else "◀  ${base/1000}s")
                } else if (abs(dy) > 55 && abs(dy) > abs(dx)) {
                    if (downX < playerView.width / 2) {
                        val attrs = window.attributes
                        val current = if (attrs.screenBrightness >= 0) attrs.screenBrightness else 0.5f
                        attrs.screenBrightness = (current - dy / playerView.height).coerceIn(0.05f, 1f)
                        window.attributes = attrs; showOverlay("☀ ${(attrs.screenBrightness * 100).toInt()}%")
                    } else {
                        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                        val current = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                        val next = (current - (dy / playerView.height * max).toInt()).coerceIn(0, max)
                        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, next, 0); showOverlay("🔊 ${next * 100 / max}%")
                    }
                } else if (duration < 250 && abs(dx) < 20 && abs(dy) < 20) {
                    if (controlsVisible) hideAllControls() else showAllControls()
                }
                return false
            }
        }
        return false
    }
    private fun centerButton(label: String, size: Int, action: () -> Unit): TextView = textButton(label, size, action).apply {
        background = rounded(Color.argb(115, 12, 15, 20), 100)
        val params = LinearLayout.LayoutParams(dp(54), dp(54)); params.setMargins(dp(5), 0, dp(5), 0); layoutParams = params
    }
    private fun seekRelative(delta: Long) {
        val exo = player ?: return
        val duration = exo.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + delta).coerceIn(0L, duration))
        showOverlay(if (delta >= 0) "+${delta / 1000}s" else "${delta / 1000}s")
        showAllControls()
    }
    private fun togglePlayPause() {
        val exo = player ?: return
        if (exo.isPlaying) exo.pause() else exo.play()
        playPauseButton.text = if (exo.isPlaying) "Ⅱ" else "▶"
        scheduleHideControls()
    }
    private fun formatTime(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) / 1000L)
        val h = total / 3600; val m = (total % 3600) / 60; val sec = total % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(java.util.Locale.US, "%02d:%02d", m, sec)
    }
    private fun hideAllControls() {
        topBar.visibility = View.GONE; floatingBar.visibility = View.GONE
        centerBar.visibility = View.GONE; bottomBar.visibility = View.GONE
        controlsVisible = false
        hideControlsTask?.let(uiHandler::removeCallbacks)
    }
    private fun showAllControls() {
        topBar.visibility = View.VISIBLE; floatingBar.visibility = View.VISIBLE
        centerBar.visibility = View.VISIBLE; bottomBar.visibility = View.VISIBLE
        controlsVisible = true
        scheduleHideControls()
    }
    private fun scheduleHideControls() {
        hideControlsTask?.let(uiHandler::removeCallbacks)
        val task = Runnable { if (!userSeeking) hideAllControls() }
        hideControlsTask = task
        uiHandler.postDelayed(task, 4500)
    }
    private fun showSubtitleInfo() {
        Toast.makeText(this, "Subtitle options depend on subtitle tracks available in this video", Toast.LENGTH_SHORT).show()
    }
    private fun showOverlay(text: String) { overlay.text = text; overlay.visibility = View.VISIBLE; overlay.removeCallbacks(hideOverlayRunnable); overlay.postDelayed(hideOverlayRunnable, 850) }
    private val hideOverlayRunnable = Runnable { overlay.visibility = View.GONE }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() {
        uiHandler.removeCallbacks(updateProgress)
        hideControlsTask?.let(uiHandler::removeCallbacks)
        playerView.player = null; player?.release(); player = null
        super.onDestroy()
    }
}
