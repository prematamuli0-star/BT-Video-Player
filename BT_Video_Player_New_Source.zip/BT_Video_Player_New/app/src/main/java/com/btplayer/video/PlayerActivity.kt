package com.btplayer.video

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var brightness = 0.5f
    private var volume = 0.5f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply { hide(WindowInsetsCompat.Type.systemBars()); systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE }
        val frame = FrameLayout(this)
        playerView = PlayerView(this).apply { useController = true; controllerAutoShow = true; setShowSubtitleButton(true) }
        overlay = TextView(this).apply { textSize = 22f; setTextColor(android.graphics.Color.WHITE); gravity = Gravity.CENTER; setPadding(32,18,32,18); visibility = View.GONE; setBackgroundColor(0x99000000.toInt()) }
        frame.addView(playerView, FrameLayout.LayoutParams(-1,-1)); frame.addView(overlay, FrameLayout.LayoutParams(-2,-2, Gravity.CENTER))
        setContentView(frame)
        playerView.setOnTouchListener { _, event -> handleTouch(event) }
        val uri = intent.getStringExtra("uri")?.let(Uri::parse)
        if (uri == null) { finish(); return }
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = true
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) { Toast.makeText(this@PlayerActivity, "Unable to play this video", Toast.LENGTH_LONG).show() }
            })
        }
    }

    private fun handleTouch(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downTime = System.currentTimeMillis(); brightness = window.attributes.screenBrightness.takeIf { it >= 0 } ?: 0.5f; volume = 0.5f; return true }
            MotionEvent.ACTION_UP -> {
                val dx = e.x - downX; val dy = e.y - downY
                val duration = System.currentTimeMillis() - downTime
                if (abs(dx) > 65 && abs(dx) > abs(dy) * 1.25f) {
                    val base = if (abs(dx) > playerView.width * 0.55f) 30000L else if (abs(dx) > playerView.width * 0.28f) 20000L else 10000L
                    val jump = if (dx > 0) base else -base
                    player?.let { it.seekTo((it.currentPosition + jump).coerceIn(0L, it.duration.takeIf { d -> d > 0 } ?: Long.MAX_VALUE)) }
                    showOverlay(if (dx > 0) "+${base/1000}s  ▶" else "◀  ${base/1000}s")
                } else if (abs(dy) > 55 && abs(dy) > abs(dx)) {
                    val leftSide = downX < playerView.width / 2
                    if (leftSide) {
                        val attrs = window.attributes
                        val current = if (attrs.screenBrightness >= 0) attrs.screenBrightness else 0.5f
                        attrs.screenBrightness = (current - dy / playerView.height).coerceIn(0.05f, 1f)
                        window.attributes = attrs
                        showOverlay("☀ ${(attrs.screenBrightness * 100).toInt()}%")
                    } else {
                        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                        val current = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                        val next = (current - (dy / playerView.height * max).toInt()).coerceIn(0, max)
                        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, next, 0)
                        showOverlay("🔊 ${(next * 100 / max)}%")
                    }
                } else if (duration < 250 && abs(dx) < 20 && abs(dy) < 20) {
                    playerView.showController()
                }
                return true
            }
        }
        return true
    }
    private fun showOverlay(text: String) { overlay.text = text; overlay.visibility = View.VISIBLE; overlay.postDelayed({ overlay.visibility = View.GONE }, 850) }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { playerView.player = null; player?.release(); player = null; super.onDestroy() }
}
