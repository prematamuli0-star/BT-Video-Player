package com.btplayer.video

import android.content.ContentValues
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.TrackSelectionDialogBuilder
import kotlin.math.abs

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var overlay: TextView
    private lateinit var titleView: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var floatingBar: LinearLayout
    private lateinit var centerBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var seekBar: SeekBar
    private lateinit var currentTimeView: TextView
    private lateinit var durationView: TextView
    private lateinit var playPauseButton: TextView
    private val uiHandler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private val updateProgress = object : Runnable {
        override fun run() {
            val exo = player
            if (exo != null && !userSeeking) {
                val duration = exo.duration.coerceAtLeast(0L)
                // SeekBar uses seconds, avoiding Int overflow on long movies.
                seekBar.max = (duration / 1000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt().coerceAtLeast(1)
                seekBar.progress = (exo.currentPosition / 1000L).coerceAtMost(seekBar.max.toLong()).toInt()
                currentTimeView.text = formatTime(exo.currentPosition)
                durationView.text = formatTime(duration)
                playPauseButton.text = if (exo.isPlaying) "Ⅱ" else "▶"
                findBottomPlayButton()?.text = if (exo.isPlaying) "Ⅱ" else "▶"
            }
            uiHandler.postDelayed(this, 500)
        }
    }
    private var hideControlsTask: Runnable? = null
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var speedIndex = 0
    private val speeds = floatArrayOf(1f, 1.25f, 1.5f, 2f, 0.75f)
    private var controlsVisible = true
    private var controlsLocked = false
    private var resizeModeIndex = 0
    private var isLandscape = true
    private var zoomScale = 1f
    private var pinchUsed = false
    private lateinit var scaleGestureDetector: ScaleGestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = false
            setKeepContentOnPlayerReset(true)
            setShutterBackgroundColor(Color.TRANSPARENT)
            setBackgroundColor(Color.BLACK)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        overlay = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(32, 18, 32, 18); visibility = View.GONE
            background = rounded(Color.argb(155, 0, 0, 0), 18)
        }
        frame.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(22), dp(10), dp(8))
            // Transparent MX-style top overlay; no solid/gradient panel behind controls.
            setBackgroundColor(Color.TRANSPARENT)
        }
        val back = textButton("‹", 34) { finishPlayer() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(42), dp(48)))
        titleView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(dp(8),0,dp(6),0) }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, dp(48), 1f))
        topBar.addView(textButton("HW+", 14) { Toast.makeText(this, "Hardware decoding is managed automatically by the player", Toast.LENGTH_SHORT).show() })
        topBar.addView(textButton("⋮", 26) { showMoreMenu() })
        topBar.elevation = dp(12).toFloat()
        frame.addView(topBar, FrameLayout.LayoutParams(-1, dp(78), Gravity.TOP))

        floatingBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            // Keep only the circular buttons visible; capsule background is transparent.
            setBackgroundColor(Color.TRANSPARENT)
        }
        floatingBar.addView(circleButton("1X") { cycleSpeed() })
        floatingBar.addView(circleButton("SUB") { showSubtitleTrackDialog() })
        floatingBar.addView(circleButton("↻") { toggleOrientation() })
        floatingBar.addView(circleButton("⊕") { zoomIn() })
        floatingBar.addView(circleButton("⊖") { zoomOut() })
        floatingBar.addView(circleButton("⛶") { cycleResizeMode() })
        floatingBar.addView(circleButton("⋮") { showMoreMenu() })
        val midParams = FrameLayout.LayoutParams(-2, dp(56), Gravity.TOP or Gravity.START).apply { topMargin = dp(90); leftMargin = dp(12) }
        floatingBar.elevation = dp(12).toFloat()
        frame.addView(floatingBar, midParams)

        // MX-style center transport controls.
        centerBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.TRANSPARENT, 36)
        }
        centerBar.addView(centerButton("|◀", 27) { restartVideo() })
        centerBar.addView(centerButton("↶₅", 28) { seekRelative(-5_000L) })
        playPauseButton = centerButton("▶", 30) { togglePlayPause() }
        playPauseButton.background = rounded(Color.WHITE, 100)
        playPauseButton.setTextColor(Color.BLACK)
        centerBar.addView(playPauseButton)
        centerBar.addView(centerButton("↷₁₅", 28) { seekRelative(15_000L) })
        centerBar.addView(centerButton("▶|", 27) { playNextIfAvailable() })
        frame.addView(centerBar, FrameLayout.LayoutParams(-2, dp(68), Gravity.CENTER))

        // MX Player-inspired bottom layout: time + seek bar on the first row,
        // then a separate transport/action row underneath.
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(7), dp(18), dp(5))
            // Transparent bottom control layer, matching the reference screenshot.
            setBackgroundColor(Color.TRANSPARENT)
        }

        currentTimeView = TextView(this).apply {
            text = "00:00"; textSize = 14f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
        }
        durationView = TextView(this).apply {
            text = "00:00"; textSize = 14f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        }
        seekBar = SeekBar(this).apply {
            max = 1
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(75, 170, 245))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(75, 170, 245))
            setPadding(dp(8), 0, dp(8), 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar) {
                    userSeeking = true
                    showAllControls()
                }
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) currentTimeView.text = formatTime(progress.toLong() * 1000L)
                }
                override fun onStopTrackingTouch(seekBar: SeekBar) {
                    player?.seekTo(seekBar.progress.toLong() * 1000L)
                    userSeeking = false
                    scheduleHideControls()
                }
            })
        }
        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        seekRow.addView(currentTimeView, LinearLayout.LayoutParams(dp(58), dp(34)))
        seekRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(34), 1f))
        seekRow.addView(durationView, LinearLayout.LayoutParams(dp(70), dp(34)))
        bottomBar.addView(seekRow, LinearLayout.LayoutParams(-1, dp(38)))

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun bottomAction(label: String, size: Int, action: () -> Unit): TextView =
            textButton(label, size, action).apply {
                background = rounded(Color.TRANSPARENT, 8)
                setPadding(0, 0, 0, 0)
            }

        actionRow.addView(bottomAction("🔒", 21) { toggleControlsLock() },
            LinearLayout.LayoutParams(0, dp(43), 0.9f))
        actionRow.addView(bottomAction("|◀", 25) { playPreviousIfAvailable() },
            LinearLayout.LayoutParams(0, dp(43), 1f))
        actionRow.addView(bottomAction("↶₅", 25) { seekRelative(-5_000L) },
            LinearLayout.LayoutParams(0, dp(43), 1f))
        val bottomPlay = bottomAction("Ⅱ", 32) { togglePlayPause() }
        bottomPlay.tag = "bottomPlay"
        actionRow.addView(bottomPlay, LinearLayout.LayoutParams(0, dp(43), 1.15f))
        actionRow.addView(bottomAction("↷₁₅", 25) { seekRelative(15_000L) },
            LinearLayout.LayoutParams(0, dp(43), 1f))
        actionRow.addView(bottomAction("▶|", 25) { playNextIfAvailable() },
            LinearLayout.LayoutParams(0, dp(43), 1f))
        actionRow.addView(bottomAction("⛶", 24) { cycleResizeMode() },
            LinearLayout.LayoutParams(0, dp(43), 0.9f))
        bottomBar.addView(actionRow, LinearLayout.LayoutParams(-1, dp(45)))
        bottomBar.elevation = dp(12).toFloat()
        frame.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(91), Gravity.BOTTOM))

        // The reference layout keeps transport buttons in the bottom strip,
        // not as a second set floating over the middle of the video.
        centerBar.visibility = View.GONE
        frame.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finishPlayer() }
        })
        scaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                pinchUsed = true
                return true
            }
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                applyZoom(zoomScale * detector.scaleFactor)
                return true
            }
        })
        playerView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            handleTouch(event)
        }
        uiHandler.post(updateProgress)
        val uri = intent.getStringExtra("uri")?.let(Uri::parse)
        if (uri == null) { finish(); return }
        titleView.text = intent.getStringExtra("title") ?: uri.lastPathSegment ?: "BT Video Player"
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            val queueUris = intent.getStringArrayListExtra("queue_uris").orEmpty()
            val queueTitles = intent.getStringArrayListExtra("queue_titles").orEmpty()
            val startIndex = intent.getIntExtra("start_index", 0).coerceAtLeast(0)
            val mediaItems = if (queueUris.isNotEmpty()) {
                queueUris.mapIndexed { index, value ->
                    MediaItem.Builder()
                        .setUri(Uri.parse(value))
                        .setMediaId(queueTitles.getOrNull(index) ?: "Video ${index + 1}")
                        .build()
                }
            } else listOf(MediaItem.fromUri(uri))
            exo.setMediaItems(mediaItems, startIndex.coerceAtMost(mediaItems.lastIndex), 0L)
            exo.prepare(); exo.playWhenReady = true
            exo.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playPauseButton.text = if (isPlaying) "Ⅱ" else "▶"
                    findBottomPlayButton()?.text = if (isPlaying) "Ⅱ" else "▶"
                }
                override fun onPlaybackStateChanged(playbackState: Int) { scheduleHideControls() }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "Unable to play this video", Toast.LENGTH_LONG).show()
                }
            })
        }
    }

    private fun findBottomPlayButton(): TextView? {
        if (!::bottomBar.isInitialized || bottomBar.childCount < 2) return null
        val row = bottomBar.getChildAt(1) as? LinearLayout ?: return null
        return row.getChildAt(2) as? TextView
    }

    private fun textButton(label: String, size: Int, action: () -> Unit): TextView = TextView(this).apply {
        text = label; textSize = size.toFloat(); setTextColor(Color.WHITE); gravity = Gravity.CENTER
        isClickable = true; isFocusable = true; setPadding(dp(6), 0, dp(6), 0); setOnClickListener { action() }
        // Use a regular drawable background for reliable Kotlin/Android SDK compilation.
        background = rounded(Color.TRANSPARENT, 12)
    }
    private fun circleButton(label: String, action: () -> Unit): TextView = textButton(label, if (label == "1X") 16 else 22, action).apply {
        background = rounded(Color.argb(190, 38, 47, 62), 100)
        val params = LinearLayout.LayoutParams(dp(if (label == "SUB") 48 else 44), dp(44)); params.setMargins(dp(4),0,dp(4),0); layoutParams = params
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun cycleSpeed() {
        speedIndex = (speedIndex + 1) % speeds.size
        player?.setPlaybackSpeed(speeds[speedIndex])
        Toast.makeText(this, "Playback speed ${speeds[speedIndex]}X", Toast.LENGTH_SHORT).show()
    }
    private fun toggleOrientation() {
        isLandscape = !isLandscape
        requestedOrientation = if (isLandscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }
    private fun takeScreenshot() {
        try {
            val bitmap = Bitmap.createBitmap(playerView.width, playerView.height, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            playerView.draw(canvas)
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "BTVideo_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/BT Video Player")
            }
            val imageUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (imageUri != null) contentResolver.openOutputStream(imageUri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            bitmap.recycle()
            Toast.makeText(this, if (imageUri != null) "Screenshot saved to Pictures/BT Video Player" else "Could not save screenshot", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { Toast.makeText(this, "Could not capture screenshot", Toast.LENGTH_SHORT).show() }
    }
    private fun showMoreMenu() {
        val options = arrayOf("Playback speed", "Subtitle", "Screen rotate", "Screen fit", "Zoom in", "Zoom out", "Reset zoom", "Lock controls", "Video information")
        android.app.AlertDialog.Builder(this).setTitle("BT Video Player").setItems(options) { _, which ->
            when (which) {
                0 -> cycleSpeed()
                1 -> showSubtitleTrackDialog()
                2 -> toggleOrientation()
                3 -> cycleResizeMode()
                4 -> zoomIn()
                5 -> zoomOut()
                6 -> resetZoom()
                7 -> toggleControlsLock()
                8 -> showVideoInfo()
            }
        }.show()
    }

    private fun applyZoom(value: Float) {
        zoomScale = value.coerceIn(1f, 3f)
        playerView.scaleX = zoomScale
        playerView.scaleY = zoomScale
        showOverlay("Zoom ${((zoomScale - 1f) * 100f + 100f).toInt()}%")
    }

    private fun zoomIn() {
        applyZoom(zoomScale + 0.25f)
        showAllControls()
    }

    private fun zoomOut() {
        applyZoom(zoomScale - 0.25f)
        showAllControls()
    }

    private fun resetZoom() {
        applyZoom(1f)
        showAllControls()
    }
    private fun finishPlayer() { player?.pause(); finish(); overridePendingTransition(0, 0) }

    private fun handleTouch(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downTime = System.currentTimeMillis(); return true }
            MotionEvent.ACTION_UP -> {
                if (pinchUsed) { pinchUsed = false; return true }
                val dx = e.x - downX; val dy = e.y - downY
                val duration = System.currentTimeMillis() - downTime
                if (abs(dx) > 65 && abs(dx) > abs(dy) * 1.25f) {
                    val base = if (abs(dx) > playerView.width * 0.55f) 30000L else if (abs(dx) > playerView.width * 0.28f) 20000L else 10000L
                    val jump = if (dx > 0) base else -base
                    player?.let { it.seekTo((it.currentPosition + jump).coerceIn(0L, it.duration.takeIf { d -> d > 0 } ?: Long.MAX_VALUE)) }
                    showOverlay(if (dx > 0) "+${base/1000}s  ▶" else "◀  ${base/1000}s")
                } else if (abs(dy) > 55 && abs(dy) > abs(dx)) {
                    if (downX < playerView.width / 2) {
                        val attrs = window.attributes
                        val current = if (attrs.screenBrightness >= 0) attrs.screenBrightness else 0.5f
                        attrs.screenBrightness = (current - dy / playerView.height).coerceIn(0.05f, 1f)
                        window.attributes = attrs; showOverlay("☀ ${(attrs.screenBrightness * 100).toInt()}%")
                    } else {
                        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                        val current = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                        val next = (current - (dy / playerView.height * max).toInt()).coerceIn(0, max)
                        am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, next, 0); showOverlay("🔊 ${next * 100 / max}%")
                    }
                } else if (controlsLocked) {
                    if (duration >= 700L) {
                        controlsLocked = false
                        showAllControls()
                        showOverlay("Controls unlocked")
                    } else {
                        showOverlay("Controls locked • Long press to unlock")
                    }
                } else if (duration < 250 && abs(dx) < 20 && abs(dy) < 20) {
                    if (controlsVisible) hideAllControls() else showAllControls()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> return true
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }
    private fun centerButton(label: String, size: Int, action: () -> Unit): TextView = textButton(label, size, action).apply {
        background = rounded(Color.argb(115, 12, 15, 20), 100)
        val params = LinearLayout.LayoutParams(dp(54), dp(54)); params.setMargins(dp(7), 0, dp(7), 0); layoutParams = params
    }
    private fun restartVideo() {
        val exo = player ?: return
        exo.seekTo(0L)
        exo.play()
        showOverlay("↺ Restart")
        showAllControls()
    }

    private fun playPreviousIfAvailable() {
        val exo = player ?: return
        if (exo.hasPreviousMediaItem()) {
            exo.seekToPreviousMediaItem()
            exo.play()
        } else {
            exo.seekTo(0L)
            exo.play()
        }
        showAllControls()
    }

    private fun playNextIfAvailable() {
        val exo = player ?: return
        if (exo.hasNextMediaItem()) {
            exo.seekToNextMediaItem()
            exo.play()
        } else {
            Toast.makeText(this, "No next video in the current queue", Toast.LENGTH_SHORT).show()
        }
        showAllControls()
    }

    private fun seekRelative(delta: Long) {
        val exo = player ?: return
        val duration = exo.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
        exo.seekTo((exo.currentPosition + delta).coerceIn(0L, duration))
        showOverlay(if (delta >= 0) "+${delta / 1000}s" else "${delta / 1000}s")
        showAllControls()
    }
    private fun togglePlayPause() {
        val exo = player ?: return
        if (exo.isPlaying) exo.pause() else exo.play()
        playPauseButton.text = if (exo.isPlaying) "Ⅱ" else "▶"
        findBottomPlayButton()?.text = if (exo.isPlaying) "Ⅱ" else "▶"
        scheduleHideControls()
    }
    private fun formatTime(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) / 1000L)
        val h = total / 3600; val m = (total % 3600) / 60; val sec = total % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(java.util.Locale.US, "%02d:%02d", m, sec)
    }
    private fun hideAllControls() {
        topBar.visibility = View.GONE; floatingBar.visibility = View.GONE
        centerBar.visibility = View.GONE; bottomBar.visibility = View.GONE
        controlsVisible = false
        hideControlsTask?.let(uiHandler::removeCallbacks)
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
    }
    private fun showAllControls() {
        if (controlsLocked) return
        topBar.visibility = View.VISIBLE; floatingBar.visibility = View.VISIBLE
        centerBar.visibility = View.GONE; bottomBar.visibility = View.VISIBLE
        controlsVisible = true
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
        scheduleHideControls()
    }

    private fun toggleControlsLock() {
        controlsLocked = !controlsLocked
        if (controlsLocked) {
            showOverlay("Controls locked • Long press screen to unlock")
            hideAllControls()
        } else {
            showAllControls()
            showOverlay("Controls unlocked")
        }
    }

    private fun cycleResizeMode() {
        val modes = intArrayOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        )
        val labels = arrayOf("Fit", "Zoom", "Stretch")
        resizeModeIndex = (resizeModeIndex + 1) % modes.size
        playerView.resizeMode = modes[resizeModeIndex]
        showOverlay(labels[resizeModeIndex])
        showAllControls()
    }

    private fun showAudioTrackDialog() {
        val exo = player ?: return
        TrackSelectionDialogBuilder(this, "Audio track", exo, C.TRACK_TYPE_AUDIO)
            .build().show()
        showAllControls()
    }

    private fun showSubtitleTrackDialog() {
        val exo = player ?: return
        TrackSelectionDialogBuilder(this, "Subtitles", exo, C.TRACK_TYPE_TEXT)
            .build().show()
        showAllControls()
    }
    private fun scheduleHideControls() {
        hideControlsTask?.let(uiHandler::removeCallbacks)
        val task = Runnable { if (!userSeeking) hideAllControls() }
        hideControlsTask = task
        uiHandler.postDelayed(task, 4500)
    }
    private fun showVideoInfo() {
        val exo = player ?: return
        val duration = if (exo.duration > 0) formatTime(exo.duration) else "Unknown"
        android.app.AlertDialog.Builder(this)
            .setTitle("Video information")
            .setMessage("Name: ${titleView.text}\\nDuration: $duration\\nPlayback: ${speeds[speedIndex]}X")
            .setPositiveButton("OK", null)
            .show()
        showAllControls()
    }

    private fun showSubtitleInfo() {
        Toast.makeText(this, "Subtitle options depend on subtitle tracks available in this video", Toast.LENGTH_SHORT).show()
    }
    private fun showOverlay(text: String) { overlay.text = text; overlay.visibility = View.VISIBLE; overlay.removeCallbacks(hideOverlayRunnable); overlay.postDelayed(hideOverlayRunnable, 850) }
    private val hideOverlayRunnable = Runnable { overlay.visibility = View.GONE }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() {
        uiHandler.removeCallbacks(updateProgress)
        hideControlsTask?.let(uiHandler::removeCallbacks)
        playerView.player = null; player?.release(); player = null
        super.onDestroy()
    }
}
