# BT Video Player — New Android Source

Fresh Android Studio project for **BT Video Player**, with a white/purple/blue home screen inspired by the BT Music Player reference.

## Included
- Local video library using Android MediaStore
- Search by video title or folder
- All Videos / Folders / Recent navigation
- Full-screen landscape playback using AndroidX Media3 ExoPlayer
- Play/pause, seek bar, subtitle button and track selection controls provided by Media3 PlayerView
- Horizontal swipe: 10-second short, 20-second medium, 30-second long seek forward/backward with visual indicator
- Vertical swipe: brightness on left side, volume on right side
- Screen stays awake while playing
- GitHub Actions workflow builds a debug APK artifact

## Build on GitHub
1. Create a new repository named `BT-Video-Player`.
2. Upload the contents of this folder to the repository root (not the containing folder).
3. Open **Actions** and run **Build BT Video Player** or push a commit.
4. Open the successful workflow run and download the `BT-Video-Player-APK` artifact ZIP.
5. Extract the ZIP to get `app-debug.apk` and install it on your Android phone.

## Notes
- This is a fresh source project, not a tested signed release. The workflow builds a debug APK for device testing.
- Media3 supplies standard player controls and available audio/subtitle track selection; exact support depends on each video's codecs and embedded tracks.
- The current fresh version intentionally focuses on the core player. Favorites persistence, custom thumbnail extraction, background playback, and a production-signed Play Store AAB are not included yet.
