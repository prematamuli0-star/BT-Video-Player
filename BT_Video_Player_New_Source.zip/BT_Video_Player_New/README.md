# BT Video Player — Updated Android Source

Android video player project for **BT Video Player**.

## Included
- Local video library using Android MediaStore
- Folder, Videos, Recent and persistent Favourites tabs
- Search by video title or folder
- Video thumbnails
- Full-screen landscape playback using AndroidX Media3 ExoPlayer
- Custom MX-style top actions, floating tools and bottom playback controls
- Previous/next queue navigation and restart
- Seek bar with elapsed and total time
- Tap-to-show/hide controls with automatic hide
- Horizontal swipe seeking and vertical brightness/volume gestures
- Playback speed control
- Audio and subtitle track selection dialogs (when tracks exist)
- Fit, Zoom and Stretch display modes
- Screen lock; long-press the video area to unlock
- Screen stays awake while playing
- GitHub Actions workflow for a debug APK

## Build
Upload the contents of this folder to the repository root. Then open **Actions** and run **Build BT Video Player APK**. Download the `BT-Video-Player-APK` artifact from a successful workflow run, extract it, and install `app-debug.apk`.

## Notes
- This is a debug build for testing, not a signed Play Store release.
- Audio/subtitle choices depend on the tracks present in each video.
- Playback compatibility depends on the device and video codec.
- Test on a real phone before publishing.
