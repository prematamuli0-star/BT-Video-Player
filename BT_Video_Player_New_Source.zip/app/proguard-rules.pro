# Add project specific ProGuard rules here.
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.media3.common.util.UnstableApi <methods>;
    @androidx.media3.common.util.UnstableApi <fields>;
}

# LibVLC uses JNI and reflection-backed native bindings.
-keep class org.videolan.libvlc.** { *; }
-dontwarn org.videolan.libvlc.**
