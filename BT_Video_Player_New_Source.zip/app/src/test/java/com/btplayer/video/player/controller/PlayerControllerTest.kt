package com.btplayer.video.player.controller

import android.net.Uri
import android.view.SurfaceView
import com.btplayer.video.core.logging.PlayerDiagnosticLogger
import com.btplayer.video.domain.model.AudioTrackInfo
import com.btplayer.video.domain.model.EngineTimelineSnapshot
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.ResizeMode
import com.btplayer.video.domain.model.SeekSubmissionResult
import com.btplayer.video.domain.model.SubtitleTrackInfo
import com.btplayer.video.domain.model.VideoItem
import com.btplayer.video.player.engine.PlaybackEngine
import com.btplayer.video.player.engine.PlaybackEngineListener
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class PlayerControllerTest {

    private class FakePlaybackEngine(
        override val engineType: EngineType,
        override var isAvailable: Boolean = true,
        private val eventOrderLog: MutableList<String> = mutableListOf()
    ) : PlaybackEngine {
        private var engineListener: PlaybackEngineListener? = null
        override var isSurfaceAttached: Boolean = false
        var lastSurfaceWidth: Int = 0
        var lastSurfaceHeight: Int = 0
        var preparedVideo: VideoItem? = null
        var lastStartPosMs: Long = 0L
        var currentPosMs: Long = 0L
        var durationMs: Long = 3_600_000L
        var seekable: Boolean = true
        var timelineReady: Boolean = true
        var selectedAudio: AudioTrackInfo? = null
        var selectedSubtitle: SubtitleTrackInfo? = null
        var appliedSpeed: Float = 1.0f
        val dispatchedSeeks = mutableListOf<Pair<Long, Long>>()

        override fun setListener(listener: PlaybackEngineListener?) {
            this.engineListener = listener
        }

        override fun attachSurfaceView(surfaceView: SurfaceView?, width: Int, height: Int) {
            isSurfaceAttached = true
            lastSurfaceWidth = width
            lastSurfaceHeight = height
            eventOrderLog.add("${engineType.name}:attachSurface(${width}x${height})")
        }

        override fun updateSurfaceSize(width: Int, height: Int) {
            lastSurfaceWidth = width
            lastSurfaceHeight = height
            eventOrderLog.add("${engineType.name}:updateSurfaceSize(${width}x${height})")
        }

        override fun detachSurface() {
            isSurfaceAttached = false
            eventOrderLog.add("${engineType.name}:detachSurface")
        }

        override fun prepareMedia(video: VideoItem, startPositionMs: Long, autoPlay: Boolean) {
            eventOrderLog.add("${engineType.name}:prepareMedia($startPositionMs)")
            preparedVideo = video
            lastStartPosMs = startPositionMs
            currentPosMs = startPositionMs
            durationMs = if (video.durationMs > 0L) video.durationMs else 3_600_000L
            engineListener?.onPlaybackStateChanged(autoPlay, PlaybackEngine.STATE_READY)
            engineListener?.onTimelineSnapshotChanged(captureTimelineSnapshot())
        }

        override fun play() {
            engineListener?.onPlaybackStateChanged(true, PlaybackEngine.STATE_READY)
        }

        override fun pause() {
            engineListener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_READY)
        }

        override fun stop() {
            eventOrderLog.add("${engineType.name}:stop")
            engineListener?.onPlaybackStateChanged(false, PlaybackEngine.STATE_IDLE)
        }

        override fun release() {
            detachSurface()
        }

        override fun performEngineSeek(requestId: Long, positionMs: Long): Boolean {
            dispatchedSeeks.add(requestId to positionMs)
            return true
        }

        override fun setPlaybackSpeed(speed: Float) {
            appliedSpeed = speed
        }

        override fun selectAudioTrack(track: AudioTrackInfo) {
            selectedAudio = track
        }

        override fun selectSubtitleTrack(track: SubtitleTrackInfo) {
            selectedSubtitle = track
        }

        override fun loadExternalSubtitle(uri: Uri) {}

        override fun captureTimelineSnapshot(): EngineTimelineSnapshot {
            return EngineTimelineSnapshot(
                engineType = engineType,
                currentPositionMs = currentPosMs,
                bufferedPositionMs = currentPosMs,
                engineDurationMs = durationMs,
                metadataDurationMs = preparedVideo?.durationMs ?: durationMs,
                isEngineSeekable = seekable,
                isTimelineReady = timelineReady,
                isMkvContainer = preparedVideo?.isMkvContainer == true
            )
        }
    }

    private fun sampleVideos(): List<VideoItem> = listOf(
        VideoItem(
            id = 1L,
            title = "Movie_1080p",
            displayName = "Movie_1080p.mkv",
            uri = null,
            path = "/storage/emulated/0/Movies/Movie_1080p.mkv",
            durationMs = 8_880_000L, // 2h 28m
            sizeBytes = 8_482_560_000L,
            dateAddedSec = 1_700_000_000L,
            folderName = "Movies",
            mimeType = "video/x-matroska",
            width = 1920,
            height = 1080
        ),
        VideoItem(
            id = 2L,
            title = "Clip_720p",
            displayName = "Clip_720p.mp4",
            uri = null,
            path = "/storage/emulated/0/Movies/Clip_720p.mp4",
            durationMs = 600_000L,
            sizeBytes = 150_000_000L,
            dateAddedSec = 1_700_001_000L,
            folderName = "Movies",
            mimeType = "video/mp4",
            width = 1280,
            height = 720
        )
    )

    @Test
    fun `next and previous navigation works independently of pending MKV seek`() = runTest {
        val media3 = FakePlaybackEngine(EngineType.MEDIA3)
        val vlc = FakePlaybackEngine(EngineType.VLC, isAvailable = true)
        val controller = buildController(this, media3, vlc)

        val videos = sampleVideos()
        controller.loadPlaylist(videos, startIndex = 0, startPositionMs = 0L)
        assertEquals("Movie_1080p.mkv", controller.currentVideo.value?.displayName)

        val seekRes = controller.seekForward10s()
        assertTrue(seekRes is SeekSubmissionResult.Accepted)
        advanceTimeBy(130L)
        runCurrent()
        assertEquals(1, media3.dispatchedSeeks.size)

        assertTrue(controller.playNext())
        assertEquals("Clip_720p.mp4", controller.currentVideo.value?.displayName)
        assertEquals(0L, controller.displayedPositionMs.value)
        assertEquals(600_000L, controller.effectiveDurationMs.value)

        assertTrue(controller.playPrevious())
        assertEquals("Movie_1080p.mkv", controller.currentVideo.value?.displayName)
        assertEquals(0L, controller.displayedPositionMs.value)
    }

    @Test
    fun `engine fallback detaches Media3 surface before VLC prepare and preserves position audio subtitle and speed`() = runTest {
        val eventOrder = mutableListOf<String>()
        val media3 = FakePlaybackEngine(EngineType.MEDIA3, eventOrderLog = eventOrder)
        val vlc = FakePlaybackEngine(EngineType.VLC, isAvailable = true, eventOrderLog = eventOrder)
        val controller = buildController(this, media3, vlc)

        val videos = sampleVideos()
        controller.loadPlaylist(videos, startIndex = 0, startPositionMs = 0L)
        controller.onMedia3SurfaceAttached(1920, 1080)
        assertTrue(media3.isSurfaceAttached)

        // Select audio track, subtitle track, playback speed, and seek to 50% (4,440,000 ms)
        val hindiAudio = AudioTrackInfo(id = "audio_0_1", name = "Hindi 5.1", language = "hi", isSelected = true)
        val englishSub = SubtitleTrackInfo(id = "sub_1_0", name = "English SRT", language = "en", isSelected = true)
        controller.selectAudioTrack(hindiAudio)
        controller.selectSubtitleTrack(englishSub)
        controller.setPlaybackSpeed(1.25f)

        controller.onSeekBarScrub(0.5f)
        controller.commitInteractiveScrub()
        assertEquals(4_440_000L, controller.displayedPositionMs.value)

        eventOrder.clear()

        // Simulate Media3 fatal error during seek -> fallback to VLC
        controller.onEngineFatalError(
            engineType = EngineType.MEDIA3,
            errorCode = "ERROR_CODE_PARSING_CONTAINER_MALFORMED",
            message = "Malformed MKV Cues",
            isSeekRelated = true
        )

        // Verify strict ordering: MEDIA3:detachSurface and MEDIA3:stop happen BEFORE VLC:prepareMedia
        val detachIndex = eventOrder.indexOf("MEDIA3:detachSurface")
        val stopIndex = eventOrder.indexOf("MEDIA3:stop")
        val vlcPrepareIndex = eventOrder.indexOf("VLC:prepareMedia(4440000)")
        assertTrue("Media3 surface must be detached", detachIndex >= 0)
        assertTrue("Media3 must be stopped", stopIndex > detachIndex)
        assertTrue("VLC prepareMedia must occur after Media3 surface detach", vlcPrepareIndex > stopIndex)

        assertFalse(media3.isSurfaceAttached)
        assertEquals(EngineType.VLC, controller.activeEngineType.value)
        assertEquals("Movie_1080p.mkv", vlc.preparedVideo?.displayName)
        assertEquals(4_440_000L, vlc.lastStartPosMs)
        assertEquals(4_440_000L, controller.displayedPositionMs.value)
        assertEquals(1.25f, vlc.appliedSpeed)
        assertEquals("Hindi 5.1", vlc.selectedAudio?.name)
        assertEquals("English SRT", vlc.selectedSubtitle?.name)

        // Simulate VLC SurfaceView creation & PiP / screen rotation resize
        controller.onVlcSurfaceCreated(null, 1920, 1080)
        assertTrue(vlc.isSurfaceAttached)
        controller.onSurfaceSizeChanged(1080, 1920)
        assertEquals(1080, vlc.lastSurfaceWidth)
        assertEquals(1920, vlc.lastSurfaceHeight)
    }

    @Test
    fun `resize mode cycling and playback speed updates propagate to state`() = runTest {
        val media3 = FakePlaybackEngine(EngineType.MEDIA3)
        val vlc = FakePlaybackEngine(EngineType.VLC)
        val controller = buildController(this, media3, vlc)

        assertEquals(ResizeMode.FIT, controller.resizeMode.value)
        assertEquals(ResizeMode.FILL, controller.cycleResizeMode())
        assertEquals(ResizeMode.STRETCH, controller.cycleResizeMode())

        controller.setPlaybackSpeed(1.5f)
        assertEquals(1.5f, controller.playbackSpeed.value)
    }

    @Test
    fun `vlc fallback does not loop if vlc emits fatal error and next video resets to primary Media3`() = runTest {
        val eventOrder = mutableListOf<String>()
        val media3 = FakePlaybackEngine(EngineType.MEDIA3, eventOrderLog = eventOrder)
        val vlc = FakePlaybackEngine(EngineType.VLC, isAvailable = true, eventOrderLog = eventOrder)
        val controller = buildController(this, media3, vlc)

        val videos = sampleVideos()
        controller.loadPlaylist(videos, startIndex = 0, startPositionMs = 120_000L)
        assertEquals(EngineType.MEDIA3, controller.activeEngineType.value)

        // First fatal error on Media3 switches to VLC
        controller.onEngineFatalError(
            engineType = EngineType.MEDIA3,
            errorCode = "ERROR_CODE_DECODING_FAILED",
            message = "Hardware decoder failed",
            isSeekRelated = false
        )
        assertEquals(EngineType.VLC, controller.activeEngineType.value)
        val vlcPreparesAfterFirstFallback = eventOrder.count { it.startsWith("VLC:prepareMedia") }
        assertEquals(1, vlcPreparesAfterFirstFallback)

        // Subsequent fatal error on VLC or stale Media3 callback must NOT loop or re-prepare VLC
        controller.onEngineFatalError(
            engineType = EngineType.VLC,
            errorCode = "VLC_PLAYBACK_ERROR",
            message = "Stream corrupted",
            isSeekRelated = false
        )
        controller.onEngineFatalError(
            engineType = EngineType.MEDIA3,
            errorCode = "STALE_MEDIA3_ERROR",
            message = "Late callback",
            isSeekRelated = false
        )
        assertEquals(1, eventOrder.count { it.startsWith("VLC:prepareMedia") })
        assertEquals(EngineType.VLC, controller.activeEngineType.value)

        // Navigating to next video cleanly resets to primary Media3 engine
        assertTrue(controller.playNext())
        assertEquals(EngineType.MEDIA3, controller.activeEngineType.value)
        assertEquals("Clip_720p.mp4", media3.preparedVideo?.displayName)
    }

    private fun buildController(
        scope: TestScope,
        primary: PlaybackEngine,
        fallback: PlaybackEngine
    ): PlayerController {
        return PlayerController(
            scope = scope,
            primaryEngine = primary,
            fallbackEngine = fallback,
            preferences = null,
            logger = PlayerDiagnosticLogger(enableLogcat = false)
        )
    }
}
