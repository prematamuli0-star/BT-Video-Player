package com.btplayer.video.player.seek

import com.btplayer.video.core.logging.PlayerDiagnosticLogger
import com.btplayer.video.domain.model.EngineTimelineSnapshot
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.SeekCapability
import com.btplayer.video.domain.model.SeekSource
import com.btplayer.video.domain.model.SeekState
import com.btplayer.video.domain.model.SeekSubmissionResult
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SeekControllerTest {

    private data class DispatchedSeek(val requestId: Long, val targetPositionMs: Long)

    private class TestHarness(
        val scope: TestScope,
        var engineAcceptsSeek: Boolean = true,
        val coalesceWindowMs: Long = 120L,
        val seekTimeoutMs: Long = 3_500L
    ) {
        val logger = PlayerDiagnosticLogger(enableLogcat = false)
        val dispatchedSeeks = mutableListOf<DispatchedSeek>()
        val timeoutFailures = mutableListOf<Triple<Long, Long, String>>()
        var fakeClockMs: Long = 1_000L

        val controller = SeekController(
            scope = scope,
            logger = logger,
            elapsedClockMs = { fakeClockMs },
            doubleTapCoalesceWindowMs = coalesceWindowMs,
            seekTimeoutMs = seekTimeoutMs,
            dispatchSeekToActiveEngine = { reqId, targetMs ->
                if (engineAcceptsSeek) {
                    dispatchedSeeks.add(DispatchedSeek(reqId, targetMs))
                    true
                } else {
                    false
                }
            },
            onSeekTimeoutOrFailure = { reqId, targetMs, reason ->
                timeoutFailures.add(Triple(reqId, targetMs, reason))
            }
        )
    }

    // -------------------------------------------------------------------------
    // 1. Rapid +10s and -10s requests
    // -------------------------------------------------------------------------
    @Test
    fun `test1 rapid +10s and -10s requests coalesce and cancel out accurately`() = runTest {
        val harness = TestHarness(this)
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 50_000L,
                engineDurationMs = 600_000L,
                metadataDurationMs = 600_000L,
                isEngineSeekable = true,
                isTimelineReady = true
            )
        )

        // Rapid +10s, +10s, -10s within the 120ms coalesce window
        val r1 = harness.controller.seekRelative(10_000L, SeekSource.DOUBLE_TAP_FORWARD) as SeekSubmissionResult.Accepted
        assertEquals(60_000L, r1.targetPositionMs)
        assertEquals(10_000L, r1.accumulatedDeltaMs)

        val r2 = harness.controller.seekRelative(10_000L, SeekSource.DOUBLE_TAP_FORWARD) as SeekSubmissionResult.Accepted
        assertEquals(70_000L, r2.targetPositionMs)
        assertEquals(20_000L, r2.accumulatedDeltaMs)

        val r3 = harness.controller.seekRelative(-10_000L, SeekSource.DOUBLE_TAP_BACKWARD) as SeekSubmissionResult.Accepted
        assertEquals(60_000L, r3.targetPositionMs)
        assertEquals(10_000L, r3.accumulatedDeltaMs)

        // Before coalesce window expires, engine should not have been flooded with seeks
        assertTrue(harness.dispatchedSeeks.isEmpty())
        assertEquals(60_000L, harness.controller.displayedPositionMs.value)

        // Advance past 120ms coalesce window -> exactly 1 seek dispatched to engine at 60_000L
        advanceTimeBy(125L)
        runCurrent()

        assertEquals(1, harness.dispatchedSeeks.size)
        assertEquals(r3.requestId, harness.dispatchedSeeks.single().requestId)
        assertEquals(60_000L, harness.dispatchedSeeks.single().targetPositionMs)
    }

    // -------------------------------------------------------------------------
    // 2. Repeated double taps
    // -------------------------------------------------------------------------
    @Test
    fun `test2 repeated double taps accumulate even while previous seek is PendingSeek`() = runTest {
        val harness = TestHarness(this)
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 120_000L,
                engineDurationMs = 1_800_000L,
                metadataDurationMs = 1_800_000L,
                isEngineSeekable = true,
                isTimelineReady = true
            )
        )

        // 4 consecutive +10s double-taps
        repeat(4) {
            harness.controller.seekRelative(10_000L, SeekSource.DOUBLE_TAP_FORWARD)
        }
        assertEquals(160_000L, harness.controller.displayedPositionMs.value)

        // Let first coalesced batch dispatch to engine (at 160_000L)
        advanceTimeBy(130L)
        runCurrent()
        assertEquals(1, harness.dispatchedSeeks.size)
        assertEquals(160_000L, harness.dispatchedSeeks.last().targetPositionMs)

        // While engine is still seeking (hasn't completed 160s yet) and polls old position 120_000L:
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 120_000L, // Stale pre-seek decoder position!
                engineDurationMs = 1_800_000L,
                metadataDurationMs = 1_800_000L,
                isEngineSeekable = true,
                isTimelineReady = true
            )
        )
        // User taps +10s two more times -> must build on 160_000L -> 180_000L, NOT reset to 130_000L
        harness.controller.seekRelative(10_000L, SeekSource.DOUBLE_TAP_FORWARD)
        val finalTap = harness.controller.seekRelative(10_000L, SeekSource.DOUBLE_TAP_FORWARD) as SeekSubmissionResult.Accepted

        assertEquals(180_000L, finalTap.targetPositionMs)
        assertEquals(60_000L, finalTap.accumulatedDeltaMs)
        assertEquals(180_000L, harness.controller.displayedPositionMs.value)

        advanceTimeBy(130L)
        runCurrent()
        assertEquals(2, harness.dispatchedSeeks.size)
        assertEquals(180_000L, harness.dispatchedSeeks.last().targetPositionMs)
    }

    // -------------------------------------------------------------------------
    // 3. Seek bar scrubbing
    // -------------------------------------------------------------------------
    @Test
    fun `test3 seek bar scrubbing updates preview without flooding engine and commits once on release`() = runTest {
        val harness = TestHarness(this)
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 100_000L,
                engineDurationMs = 1_000_000L,
                metadataDurationMs = 1_000_000L,
                isEngineSeekable = true,
                isTimelineReady = true
            )
        )

        // Drag through 25%, 50%, 75%
        harness.controller.updateSeekBarFraction(0.25f)
        assertEquals(250_000L, harness.controller.displayedPositionMs.value)

        // Simulate 250ms polling tick from engine at old position 100_250L during scrub
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 100_250L,
                engineDurationMs = 1_000_000L,
                metadataDurationMs = 1_000_000L,
                isEngineSeekable = true,
                isTimelineReady = true
            )
        )
        // Must remain locked at 250_000L preview, never snapping back to 100_250L
        assertEquals(250_000L, harness.controller.displayedPositionMs.value)

        harness.controller.updateSeekBarFraction(0.50f)
        assertEquals(500_000L, harness.controller.displayedPositionMs.value)

        harness.controller.updateSeekBarFraction(0.75f)
        assertEquals(750_000L, harness.controller.displayedPositionMs.value)

        // Zero engine seeks should have been sent while dragging
        assertTrue(harness.dispatchedSeeks.isEmpty())
        assertTrue(harness.controller.seekState.value is SeekState.Scrubbing)

        // Commit scrub on slider release
        val committed = harness.controller.commitScrub() as SeekSubmissionResult.Accepted
        assertEquals(750_000L, committed.targetPositionMs)
        assertEquals(650_000L, committed.accumulatedDeltaMs)
        assertEquals(1, harness.dispatchedSeeks.size)
        assertEquals(750_000L, harness.dispatchedSeeks.single().targetPositionMs)
    }

    // -------------------------------------------------------------------------
    // 4. Swipe seeking
    // -------------------------------------------------------------------------
    @Test
    fun `test4 horizontal swipe seeking scales proportionally clamps to bounds and supports cancel`() = runTest {
        val harness = TestHarness(this)
        // 20-minute video (1,200,000 ms) -> swipe window is 1,200,000 / 10 = 120,000 ms (120s)
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 300_000L,
                engineDurationMs = 1_200_000L,
                metadataDurationMs = 1_200_000L,
                isEngineSeekable = true,
                isTimelineReady = true
            )
        )

        // Swipe right by 50% of zone width (+60,000 ms)
        val p1 = harness.controller.updateHorizontalSwipe(totalDragPx = 300f, gestureZoneWidthPx = 600f)
            as SeekSubmissionResult.PreviewUpdated
        assertEquals(360_000L, p1.previewPositionMs)
        assertEquals(60_000L, p1.deltaMs)

        // Swipe left past start of video -> clamps to 0L
        val p2 = harness.controller.updateHorizontalSwipe(totalDragPx = -2000f, gestureZoneWidthPx = 600f)
            as SeekSubmissionResult.PreviewUpdated
        assertEquals(0L, p2.previewPositionMs)
        assertEquals(-300_000L, p2.deltaMs)

        // Cancel gesture -> restores original 300_000L without dispatching seek
        harness.controller.cancelScrub()
        assertEquals(SeekState.Idle, harness.controller.seekState.value)
        assertEquals(300_000L, harness.controller.displayedPositionMs.value)
        assertTrue(harness.dispatchedSeeks.isEmpty())
    }

    // -------------------------------------------------------------------------
    // 5. Unknown duration
    // -------------------------------------------------------------------------
    @Test
    fun `test5 unknown duration rejects seek cleanly without clamping to zero`() = runTest {
        val harness = TestHarness(this)
        // Engine reports TIME_UNSET and metadata duration is 0L
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 45_000L,
                engineDurationMs = EngineTimelineSnapshot.TIME_UNSET,
                metadataDurationMs = 0L,
                isEngineSeekable = false,
                isTimelineReady = true,
                isMkvContainer = true
            )
        )

        assertEquals(0L, harness.controller.effectiveDurationMs.value)
        assertEquals(SeekCapability.UNSEEKABLE, harness.controller.seekCapability.value)

        val res = harness.controller.seekRelative(10_000L, SeekSource.DOUBLE_TAP_FORWARD)
        assertTrue(res is SeekSubmissionResult.RejectedUnseekable)
        assertTrue(harness.controller.seekState.value is SeekState.Unseekable)
        assertTrue(harness.dispatchedSeeks.isEmpty())
        // Position must remain at 45_000L and NOT be clamped to 0L!
        assertEquals(45_000L, harness.controller.displayedPositionMs.value)
    }

    // -------------------------------------------------------------------------
    // 6. Non-seekable media
    // -------------------------------------------------------------------------
    @Test
    fun `test6 non-seekable MKV media with prepared timeline is rejected safely`() = runTest {
        val harness = TestHarness(this)
        // MKV file has metadata duration from MediaStore, but extractor reports isEngineSeekable = false after prepare
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 18_500L,
                engineDurationMs = 3_600_000L,
                metadataDurationMs = 3_600_000L,
                isEngineSeekable = false,
                isTimelineReady = true,
                isMkvContainer = true
            )
        )

        assertEquals(SeekCapability.UNSEEKABLE, harness.controller.seekCapability.value)

        val seekBarResult = harness.controller.updateSeekBarFraction(0.5f)
        assertTrue(seekBarResult is SeekSubmissionResult.RejectedUnseekable)
        assertTrue(harness.controller.seekState.value is SeekState.Unseekable)
        assertTrue(harness.dispatchedSeeks.isEmpty())
        assertEquals(18_500L, harness.controller.displayedPositionMs.value)
    }

    // -------------------------------------------------------------------------
    // 7. Long-duration MKV timelines (7.9 GB, 2h 28m = 8,880,000 ms)
    // -------------------------------------------------------------------------
    @Test
    fun `test7 long duration 2h28m 7_9GB MKV timeline seeks and settles on nearest keyframe`() = runTest {
        val harness = TestHarness(this)
        val mkvDurationMs = (2L * 3600L + 28L * 60L) * 1000L // 8,880,000 ms (2h 28m)

        // Initially engine is still parsing MKV header (engineDurationMs = TIME_UNSET),
        // but MediaStore metadataDurationMs = 8,880,000 ms is available.
        harness.controller.resetForNewMedia(
            metadataDurationMs = mkvDurationMs,
            isMkvContainer = true,
            initialResumeMs = 0L
        )
        assertEquals(mkvDurationMs, harness.controller.effectiveDurationMs.value)
        assertEquals(SeekCapability.DURATION_KNOWN_PENDING_INDEX, harness.controller.seekCapability.value)

        // Engine becomes ready
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 1_200_000L, // 20:00
                engineDurationMs = mkvDurationMs,
                metadataDurationMs = mkvDurationMs,
                isEngineSeekable = true,
                isTimelineReady = true,
                isMkvContainer = true
            )
        )

        // Scrub to 85% of 2h 28m (7,548,000 ms = 2:05:48)
        val preview = harness.controller.updateSeekBarFraction(0.85f) as SeekSubmissionResult.PreviewUpdated
        assertEquals(7_548_000L, preview.previewPositionMs)

        val commit = harness.controller.commitScrub() as SeekSubmissionResult.Accepted
        assertEquals(7_548_000L, commit.targetPositionMs)
        assertEquals(1, harness.dispatchedSeeks.size)

        // Simulate CLOSEST_SYNC landing on preceding keyframe 1.42s earlier (7,546_580 ms)
        val landedKeyframeMs = 7_546_580L
        harness.controller.onEngineSeekCompleted(
            engineType = EngineType.MEDIA3,
            requestId = commit.requestId,
            landedPositionMs = landedKeyframeMs
        )

        assertEquals(SeekState.Idle, harness.controller.seekState.value)
        assertEquals(landedKeyframeMs, harness.controller.displayedPositionMs.value)
    }

    // -------------------------------------------------------------------------
    // 8. Engine switching during pending seek
    // -------------------------------------------------------------------------
    @Test
    fun `test8 engine switching during pending seek preserves target position and ignores old engine callback`() = runTest {
        val harness = TestHarness(this)
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 60_000L,
                engineDurationMs = 5_400_000L,
                metadataDurationMs = 5_400_000L,
                isEngineSeekable = true,
                isTimelineReady = true,
                isMkvContainer = true
            )
        )

        // User initiates seek to 2,400,000 ms (40:00) on Media3
        val media3Seek = harness.controller.seekToAbsolute(2_400_000L, SeekSource.SEEK_BAR)
            as SeekSubmissionResult.Accepted
        assertEquals(1, harness.dispatchedSeeks.size)

        // Media3 encounters a codec/extractor error mid-seek -> PlayerController prepares switch to LibVLC
        val preservedPos = harness.controller.prepareForEngineSwitch(EngineType.VLC)
        assertEquals(2_400_000L, preservedPos)
        assertEquals(2_400_000L, harness.controller.displayedPositionMs.value)

        // Late callback arrives from outgoing Media3 engine with old requestId -> must be ignored
        harness.controller.onEngineSeekCompleted(
            engineType = EngineType.MEDIA3,
            requestId = media3Seek.requestId,
            landedPositionMs = 60_000L
        )
        assertEquals(2_400_000L, harness.controller.displayedPositionMs.value)

        // LibVLC engine timeline becomes ready
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.VLC,
                currentPositionMs = 2_400_000L,
                engineDurationMs = 5_400_000L,
                metadataDurationMs = 5_400_000L,
                isEngineSeekable = true,
                isTimelineReady = true,
                isMkvContainer = true
            )
        )

        val vlcRestore = harness.controller.restorePositionAfterEngineSwitch(preservedPos)
            as SeekSubmissionResult.Accepted
        assertEquals(2, harness.dispatchedSeeks.size)
        assertEquals(2_400_000L, harness.dispatchedSeeks.last().targetPositionMs)

        harness.controller.onEngineSeekCompleted(
            engineType = EngineType.VLC,
            requestId = vlcRestore.requestId,
            landedPositionMs = 2_400_000L
        )
        assertEquals(SeekState.Idle, harness.controller.seekState.value)
        assertEquals(2_400_000L, harness.controller.displayedPositionMs.value)
    }

    // -------------------------------------------------------------------------
    // 9. Failed and delayed seek callbacks (stale requestId & watchdog timeout)
    // -------------------------------------------------------------------------
    @Test
    fun `test9 delayed stale callbacks are ignored and hung seek triggers watchdog timeout`() = runTest {
        val harness = TestHarness(this, seekTimeoutMs = 3_500L)
        harness.controller.onEngineTimelineUpdated(
            EngineTimelineSnapshot(
                engineType = EngineType.MEDIA3,
                currentPositionMs = 10_000L,
                engineDurationMs = 900_000L,
                metadataDurationMs = 900_000L,
                isEngineSeekable = true,
                isTimelineReady = true
            )
        )

        // First seek to 200_000L
        val firstSeek = harness.controller.seekToAbsolute(200_000L) as SeekSubmissionResult.Accepted
        // Second seek immediately supersedes first seek -> 500_000L
        val secondSeek = harness.controller.seekToAbsolute(500_000L) as SeekSubmissionResult.Accepted

        // Delayed completion from firstSeek arrives late -> must be ignored!
        harness.controller.onEngineSeekCompleted(
            engineType = EngineType.MEDIA3,
            requestId = firstSeek.requestId,
            landedPositionMs = 200_000L
        )
        assertTrue(harness.controller.seekState.value is SeekState.PendingSeek)
        assertEquals(500_000L, harness.controller.displayedPositionMs.value)

        // Now simulate secondSeek hanging beyond 3,500ms watchdog timeout
        advanceTimeBy(3_600L)
        runCurrent()

        assertEquals(SeekState.Idle, harness.controller.seekState.value)
        assertEquals(1, harness.timeoutFailures.size)
        val (failedReqId, failedTargetMs, _) = harness.timeoutFailures.single()
        assertEquals(secondSeek.requestId, failedReqId)
        assertEquals(500_000L, failedTargetMs)
    }
}
