package com.bt.videoplayer.player.controller

import android.net.Uri
import android.view.SurfaceView
import com.bt.videoplayer.core.logging.DiagnosticCategory
import com.bt.videoplayer.core.logging.PlayerDiagnosticLogger
import com.bt.videoplayer.data.preferences.PlayerPreferences
import com.bt.videoplayer.domain.model.AudioTrackInfo
import com.bt.videoplayer.domain.model.EngineTimelineSnapshot
import com.bt.videoplayer.domain.model.EngineType
import com.bt.videoplayer.domain.model.ResizeMode
import com.bt.videoplayer.domain.model.SeekCapability
import com.bt.videoplayer.domain.model.SeekSource
import com.bt.videoplayer.domain.model.SeekState
import com.bt.videoplayer.domain.model.SeekSubmissionResult
import com.bt.videoplayer.domain.model.SubtitleTrackInfo
import com.bt.videoplayer.domain.model.VideoItem
import com.bt.videoplayer.player.engine.Media3PlaybackEngine
import com.bt.videoplayer.player.engine.PlaybackEngine
import com.bt.videoplayer.player.engine.PlaybackEngineListener
import com.bt.videoplayer.player.seek.SeekController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Central coordinator for BT Video Player 2.0.
 *
 * Coordinates:
 * - Primary engine ([EngineType.MEDIA3]) and optional automatic fallback ([EngineType.VLC])
 * - Safe video output surface handoff (`detachSurface()` on outgoing engine before `attachSurfaceView()`
 *   on incoming engine, plus rotation and Picture-in-Picture `updateSurfaceSize()`)
 * - Centralized [SeekController] for all seek/scrub/skip operations
 * - Preservation of playback position, speed, audio track, and subtitle track across engine switches
 * - Playlist & Next/Previous video navigation (completely isolated from seek state)
 */
class PlayerController(
    private val scope: CoroutineScope,
    private val primaryEngine: PlaybackEngine,
    private val fallbackEngine: PlaybackEngine,
    private val preferences: PlayerPreferences? = null,
    val logger: PlayerDiagnosticLogger = PlayerDiagnosticLogger(enableLogcat = true),
    elapsedClockMs: () -> Long = { System.currentTimeMillis() }
) : PlaybackEngineListener {

    private var activeEngine: PlaybackEngine = primaryEngine

    @Volatile
    private var isSwitchingEngine: Boolean = false

    private var activeVlcSurfaceView: SurfaceView? = null
    private var currentSurfaceWidth: Int = 0
    private var currentSurfaceHeight: Int = 0

    // Preserved track preferences across Media3 -> LibVLC fallback
    private var preferredAudioTrack: AudioTrackInfo? = null
    private var preferredSubtitleTrack: SubtitleTrackInfo? = null
    private var loadedExternalSubtitleUri: Uri? = null

    val media3ExoPlayer: androidx.media3.exoplayer.ExoPlayer?
        get() = (primaryEngine as? Media3PlaybackEngine)?.exoPlayer

    private val _activeEngineType = MutableStateFlow(primaryEngine.engineType)
    val activeEngineType: StateFlow<EngineType> = _activeEngineType.asStateFlow()

    private val _playlist = MutableStateFlow<List<VideoItem>>(emptyList())
    val playlist: StateFlow<List<VideoItem>> = _playlist.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackState = MutableStateFlow(PlaybackEngine.STATE_IDLE)
    val playbackState: StateFlow<Int> = _playbackState.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(preferences?.getPlaybackSpeed() ?: 1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _resizeMode = MutableStateFlow(preferences?.getPreferredResizeMode() ?: ResizeMode.FIT)
    val resizeMode: StateFlow<ResizeMode> = _resizeMode.asStateFlow()

    private val _videoWidth = MutableStateFlow(0)
    val videoWidth: StateFlow<Int> = _videoWidth.asStateFlow()

    private val _videoHeight = MutableStateFlow(0)
    val videoHeight: StateFlow<Int> = _videoHeight.asStateFlow()

    private val _audioTracks = MutableStateFlow<List<AudioTrackInfo>>(emptyList())
    val audioTracks: StateFlow<List<AudioTrackInfo>> = _audioTracks.asStateFlow()

    private val _subtitleTracks = MutableStateFlow<List<SubtitleTrackInfo>>(emptyList())
    val subtitleTracks: StateFlow<List<SubtitleTrackInfo>> = _subtitleTracks.asStateFlow()

    val seekController = SeekController(
        scope = scope,
        logger = logger,
        elapsedClockMs = elapsedClockMs,
        dispatchSeekToActiveEngine = { requestId, targetPositionMs ->
            activeEngine.performEngineSeek(requestId, targetPositionMs)
        },
        onSeekTimeoutOrFailure = { requestId, targetPositionMs, reason ->
            handleSeekFailureOrTimeout(requestId, targetPositionMs, reason)
        }
    )

    val displayedPositionMs: StateFlow<Long> = seekController.displayedPositionMs
    val effectiveDurationMs: StateFlow<Long> = seekController.effectiveDurationMs
    val seekState: StateFlow<SeekState> = seekController.seekState
    val seekCapability: StateFlow<SeekCapability> = seekController.seekCapability

    init {
        primaryEngine.setListener(this)
        fallbackEngine.setListener(this)
    }

    // --- Video Surface Lifecycle Management (Creation, Rotation/PiP Resize, Destruction) ---

    fun onMedia3SurfaceAttached(width: Int, height: Int) {
        if (width > 0 && height > 0) {
            currentSurfaceWidth = width
            currentSurfaceHeight = height
        }
        if (activeEngine.engineType == EngineType.MEDIA3) {
            primaryEngine.attachSurfaceView(null, currentSurfaceWidth, currentSurfaceHeight)
        }
    }

    fun onVlcSurfaceCreated(surfaceView: SurfaceView?, width: Int, height: Int) {
        activeVlcSurfaceView = surfaceView
        if (width > 0 && height > 0) {
            currentSurfaceWidth = width
            currentSurfaceHeight = height
        }
        if (activeEngine.engineType == EngineType.VLC) {
            // Ensure Media3 surface is detached before attaching LibVLC surface
            if (primaryEngine.isSurfaceAttached) {
                primaryEngine.detachSurface()
            }
            fallbackEngine.attachSurfaceView(surfaceView, currentSurfaceWidth, currentSurfaceHeight)
        }
    }

    fun onSurfaceSizeChanged(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        currentSurfaceWidth = width
        currentSurfaceHeight = height
        activeEngine.updateSurfaceSize(width, height)
    }

    fun onSurfaceDestroyed(forEngine: EngineType) {
        when (forEngine) {
            EngineType.MEDIA3 -> {
                if (primaryEngine.isSurfaceAttached) {
                    primaryEngine.detachSurface()
                }
            }
            EngineType.VLC -> {
                activeVlcSurfaceView = null
                if (fallbackEngine.isSurfaceAttached) {
                    fallbackEngine.detachSurface()
                }
            }
        }
    }

    // --- Playlist & Playback Control ---

    fun loadPlaylist(videos: List<VideoItem>, startIndex: Int = 0, startPositionMs: Long? = null) {
        if (videos.isEmpty()) return
        val validIndex = startIndex.coerceIn(0, videos.lastIndex)
        _playlist.value = videos
        _currentIndex.value = validIndex
        val video = videos[validIndex]
        val initialPos = startPositionMs ?: video.lastPositionMs
        startVideoInternal(video, initialPos, EngineType.MEDIA3)
    }

    fun syncPlaylistItems(updatedVideos: List<VideoItem>) {
        if (updatedVideos.isEmpty()) return
        val current = _currentVideo.value
        _playlist.value = updatedVideos
        if (current != null) {
            val idx = updatedVideos.indexOfFirst { it.id == current.id }
            if (idx >= 0) {
                _currentIndex.value = idx
                _currentVideo.value = updatedVideos[idx]
            }
        }
    }

    fun playNext(): Boolean {
        val list = _playlist.value
        if (list.isEmpty()) return false
        persistCurrentProgress()
        val nextIndex = (_currentIndex.value + 1) % list.size
        _currentIndex.value = nextIndex
        val nextVideo = list[nextIndex]
        startVideoInternal(nextVideo, 0L, EngineType.MEDIA3)
        return true
    }

    fun playPrevious(): Boolean {
        val list = _playlist.value
        if (list.isEmpty()) return false
        persistCurrentProgress()
        val prevIndex = if (_currentIndex.value - 1 < 0) list.lastIndex else _currentIndex.value - 1
        _currentIndex.value = prevIndex
        val prevVideo = list[prevIndex]
        startVideoInternal(prevVideo, 0L, EngineType.MEDIA3)
        return true
    }

    fun togglePlayPause() {
        if (_isPlaying.value) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        activeEngine.play()
        _isPlaying.value = true
    }

    fun closeCurrentVideo() {
        persistCurrentProgress()
        activeEngine.stop()
        _isPlaying.value = false
        _currentVideo.value = null
    }

    fun pause() {
        persistCurrentProgress()
        activeEngine.pause()
        _isPlaying.value = false
    }

    // --- Centralized Seek Delegation ---

    fun seekForward10s(): SeekSubmissionResult =
        seekController.seekRelative(+10_000L, SeekSource.DOUBLE_TAP_FORWARD)

    fun seekBackward10s(): SeekSubmissionResult =
        seekController.seekRelative(-10_000L, SeekSource.DOUBLE_TAP_BACKWARD)

    fun seekRelative(deltaMs: Long): SeekSubmissionResult =
        seekController.seekRelative(deltaMs)

    fun onSeekBarScrub(fraction: Float): SeekSubmissionResult =
        seekController.updateSeekBarFraction(fraction)

    fun onHorizontalSwipeScrub(totalDragPx: Float, zoneWidthPx: Float): SeekSubmissionResult =
        seekController.updateHorizontalSwipe(totalDragPx, zoneWidthPx)

    fun commitInteractiveScrub(): SeekSubmissionResult =
        seekController.commitScrub()

    fun cancelInteractiveScrub() {
        seekController.cancelScrub()
    }

    fun seekToAbsolute(positionMs: Long): SeekSubmissionResult =
        seekController.seekToAbsolute(positionMs, SeekSource.PROGRAMMATIC)

    fun pollTimelineSnapshot() {
        val snapshot = activeEngine.captureTimelineSnapshot()
        seekController.onEngineTimelineUpdated(snapshot)
    }

    // --- Speed, Aspect Ratio, Audio & Subtitles ---

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        _playbackSpeed.value = clamped
        preferences?.savePlaybackSpeed(clamped)
        activeEngine.setPlaybackSpeed(clamped)
    }

    fun setResizeMode(mode: ResizeMode) {
        _resizeMode.value = mode
        preferences?.savePreferredResizeMode(mode)
    }

    fun cycleResizeMode(): ResizeMode {
        val next = _resizeMode.value.next()
        setResizeMode(next)
        return next
    }

    fun selectAudioTrack(track: AudioTrackInfo) {
        preferredAudioTrack = track
        activeEngine.selectAudioTrack(track)
    }

    fun selectSubtitleTrack(track: SubtitleTrackInfo) {
        preferredSubtitleTrack = track
        activeEngine.selectSubtitleTrack(track)
    }

    fun loadExternalSubtitle(uri: Uri) {
        loadedExternalSubtitleUri = uri
        activeEngine.loadExternalSubtitle(uri)
    }

    /**
     * Safely switches from the primary engine (Media3) to the fallback engine (LibVLC):
     * 1. Guards against re-entrant or duplicate fallback switches.
     * 2. Captures target playback position from [seekController] and invalidates pending Media3 seek tokens.
     * 3. Explicitly detaches Media3's video surface and stops Media3 BEFORE attaching LibVLC's surface.
     * 4. Prepares LibVLC at the preserved timestamp and restores playback speed, audio track, and subtitles.
     */
    @Synchronized
    fun switchToFallbackEngine(reason: String): Boolean {
        if (isSwitchingEngine || activeEngine.engineType == EngineType.VLC) return false
        if (!fallbackEngine.isAvailable) {
            logger.log(
                category = DiagnosticCategory.FALLBACK,
                message = "Fallback to LibVLC requested ($reason), but LibVLC runtime is unavailable",
                isWarningOrError = true
            )
            return false
        }

        val video = _currentVideo.value ?: return false
        isSwitchingEngine = true
        try {
            val restorePosMs = seekController.prepareForEngineSwitch(EngineType.VLC)
            val wasPlaying = _isPlaying.value
            val savedAudio = preferredAudioTrack ?: _audioTracks.value.firstOrNull { it.isSelected }
            val savedSubtitle = preferredSubtitleTrack ?: _subtitleTracks.value.firstOrNull { it.isSelected }
            val savedExtSubUri = loadedExternalSubtitleUri

            logger.log(
                category = DiagnosticCategory.FALLBACK,
                message = "Switching active engine from MEDIA3 to VLC",
                details = mapOf(
                    "reason" to reason,
                    "video" to video.displayName,
                    "restorePositionMs" to restorePosMs,
                    "savedAudio" to savedAudio?.name,
                    "savedSubtitle" to savedSubtitle?.name
                ),
                isWarningOrError = true
            )

            // Step 1: Detach Media3 surface and stop Media3 decoder first
            primaryEngine.detachSurface()
            primaryEngine.stop()

            // Step 2: Switch active engine reference and attach VLC surface if already created
            activeEngine = fallbackEngine
            _activeEngineType.value = EngineType.VLC
            if (activeVlcSurfaceView != null) {
                fallbackEngine.attachSurfaceView(
                    activeVlcSurfaceView,
                    currentSurfaceWidth,
                    currentSurfaceHeight
                )
            }

            // Step 3: Prepare media at restorePosMs on LibVLC and restore speed, audio, and subtitles
            fallbackEngine.prepareMedia(video, restorePosMs, wasPlaying)
            fallbackEngine.setPlaybackSpeed(_playbackSpeed.value)

            if (savedExtSubUri != null) {
                fallbackEngine.loadExternalSubtitle(savedExtSubUri)
            }
            if (savedAudio != null) {
                fallbackEngine.selectAudioTrack(savedAudio)
            }
            if (savedSubtitle != null) {
                fallbackEngine.selectSubtitleTrack(savedSubtitle)
            }

            seekController.onEngineTimelineUpdated(fallbackEngine.captureTimelineSnapshot())
            return true
        } finally {
            isSwitchingEngine = false
        }
    }

    fun persistCurrentProgress() {
        val video = _currentVideo.value ?: return
        val pos = displayedPositionMs.value
        if (pos > 0L) {
            preferences?.saveLastPosition(video.id, pos)
        }
    }

    fun release() {
        persistCurrentProgress()
        primaryEngine.detachSurface()
        fallbackEngine.detachSurface()
        primaryEngine.release()
        fallbackEngine.release()
    }

    // --- PlaybackEngineListener callbacks ---

    override fun onTimelineSnapshotChanged(snapshot: EngineTimelineSnapshot) {
        if (snapshot.engineType != activeEngine.engineType) return
        seekController.onEngineTimelineUpdated(snapshot)
    }

    override fun onPlaybackStateChanged(isPlaying: Boolean, playbackState: Int) {
        _isPlaying.value = isPlaying
        _playbackState.value = playbackState
    }

    override fun onEngineSeekCompleted(engineType: EngineType, requestId: Long, landedPositionMs: Long) {
        if (engineType != activeEngine.engineType) return
        seekController.onEngineSeekCompleted(engineType, requestId, landedPositionMs)
    }

    override fun onEngineSeekFailed(engineType: EngineType, requestId: Long, reason: String) {
        if (engineType != activeEngine.engineType) return
        seekController.onEngineSeekFailed(engineType, requestId, reason)
    }

    override fun onTracksUpdated(audioTracks: List<AudioTrackInfo>, subtitleTracks: List<SubtitleTrackInfo>) {
        _audioTracks.value = audioTracks
        _subtitleTracks.value = subtitleTracks
    }

    override fun onVideoSizeChanged(engineType: EngineType, width: Int, height: Int) {
        if (engineType != activeEngine.engineType) return
        if (width > 0 && height > 0) {
            _videoWidth.value = width
            _videoHeight.value = height
        }
    }

    override fun onEngineFatalError(
        engineType: EngineType,
        errorCode: String,
        message: String,
        isSeekRelated: Boolean
    ) {
        if (engineType != activeEngine.engineType) return
        if (engineType == EngineType.MEDIA3 && fallbackEngine.isAvailable) {
            switchToFallbackEngine("Media3 error ($errorCode): $message")
        }
    }

    override fun onMediaEnded(engineType: EngineType) {
        if (engineType != activeEngine.engineType) return
        if (_playlist.value.size > 1) {
            playNext()
        } else {
            _isPlaying.value = false
        }
    }

    private fun startVideoInternal(video: VideoItem, startPositionMs: Long, targetEngine: EngineType) {
        _currentVideo.value = video
        _videoWidth.value = video.width
        _videoHeight.value = video.height
        _audioTracks.value = emptyList()
        _subtitleTracks.value = emptyList()
        preferredAudioTrack = null
        preferredSubtitleTrack = null
        loadedExternalSubtitleUri = null

        val chosenEngine = if (targetEngine == EngineType.VLC && fallbackEngine.isAvailable) {
            fallbackEngine
        } else {
            primaryEngine
        }

        if (activeEngine != chosenEngine) {
            activeEngine.detachSurface()
            activeEngine.stop()
            activeEngine = chosenEngine
            _activeEngineType.value = chosenEngine.engineType
        }

        seekController.resetForNewMedia(
            metadataDurationMs = video.durationMs,
            isMkvContainer = video.isMkvContainer,
            initialResumeMs = startPositionMs
        )

        activeEngine.prepareMedia(video, startPositionMs, autoPlay = true)
        activeEngine.setPlaybackSpeed(_playbackSpeed.value)
        seekController.onEngineTimelineUpdated(activeEngine.captureTimelineSnapshot())
    }

    private fun handleSeekFailureOrTimeout(requestId: Long, targetPositionMs: Long, reason: String) {
        logger.log(
            category = DiagnosticCategory.FALLBACK,
            message = "Seek failure/timeout handler invoked",
            details = mapOf(
                "requestId" to requestId,
                "targetPosMs" to targetPositionMs,
                "reason" to reason,
                "activeEngine" to activeEngine.engineType.name,
                "vlcAvailable" to fallbackEngine.isAvailable
            ),
            isWarningOrError = true
        )

        if (activeEngine.engineType == EngineType.MEDIA3 && fallbackEngine.isAvailable) {
            switchToFallbackEngine("Seek failure on Media3 ($reason)")
        } else {
            seekController.onEngineTimelineUpdated(activeEngine.captureTimelineSnapshot())
        }
    }
}
