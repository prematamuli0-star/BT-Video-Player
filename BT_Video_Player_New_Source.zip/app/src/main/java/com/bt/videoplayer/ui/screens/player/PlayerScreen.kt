package com.bt.videoplayer.ui.screens.player

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.util.VLCVideoLayout
import com.bt.videoplayer.data.model.AudioTrack
import com.bt.videoplayer.data.model.SubtitleTrack
import com.bt.videoplayer.player.BTPlayerManager
import com.bt.videoplayer.player.ResizeMode
import com.bt.videoplayer.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot
import java.util.Locale

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    playerManager: BTPlayerManager,
    isInPipMode: Boolean,
    onBackClick: () -> Unit,
    onEnterPip: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current

    val isPlaying by playerManager.isPlaying.collectAsState()
    val isVlcFallback by playerManager.isVlcFallback.collectAsState()
    val currentPosition by playerManager.currentPositionMs.collectAsState()
    val duration by playerManager.durationMs.collectAsState()
    val bufferedPosition by playerManager.bufferedPositionMs.collectAsState()
    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val resizeMode by playerManager.resizeMode.collectAsState()
    val currentVideo by playerManager.currentVideo.collectAsState()
    val availableSubtitles by playerManager.availableSubtitles.collectAsState()
    val availableAudioTracks by playerManager.availableAudioTracks.collectAsState()

    var areControlsVisible by remember { mutableStateOf(true) }
    var isControlsLocked by remember { mutableStateOf(false) }

    // Dialog states
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var showAspectDialog by remember { mutableStateOf(false) }

    // Floating Gesture HUD states (MX Player continuous controls)
    var volumeLevel by remember { mutableStateOf<Int?>(null) }
    var brightnessLevel by remember { mutableStateOf<Float?>(null) }
    var seekDeltaMs by remember { mutableStateOf<Long?>(null) }
    var seekTargetMs by remember { mutableStateOf(0L) }
    var doubleTapFeedback by remember { mutableStateOf<String?>(null) }
    var isTouching by remember { mutableStateOf(false) }
    var isSeekBarDragging by remember { mutableStateOf(false) }
    var seekBarFraction by remember { mutableStateOf(0f) }

    // Gesture internal tracking
    var dragMode by remember { mutableStateOf("none") }
    var dragStartOffset by remember { mutableStateOf(Offset.Zero) }
    var initialSeekPosition by remember { mutableStateOf(0L) }
    var totalDragX by remember { mutableStateOf(0f) }
    var totalDragY by remember { mutableStateOf(0f) }
    var hasGestured by remember { mutableStateOf(false) }
    var initialBrightness by remember { mutableStateOf(0.5f) }
    var initialVolume by remember { mutableStateOf(0) }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    // External Subtitle Picker
    val subtitleFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            playerManager.loadExternalSubtitle(uri)
        }
    }

    // Timer to update playback position
    LaunchedEffect(isPlaying) {
        while (true) {
            playerManager.updatePosition()
            delay(500)
        }
    }

    // Clear the short double-tap feedback so it cannot remain stuck on screen.
    LaunchedEffect(doubleTapFeedback) {
        if (doubleTapFeedback != null) {
            delay(650)
            doubleTapFeedback = null
        }
    }

    // Auto-hide controls after 3.5 seconds (paused while user is touching screen)
    LaunchedEffect(areControlsVisible, isPlaying, isTouching) {
        if (areControlsVisible && isPlaying && !isControlsLocked && !isTouching) {
            delay(3500)
            areControlsVisible = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isControlsLocked) {
                detectTapGestures(
                    onTap = {
                        if (isControlsLocked) {
                            areControlsVisible = true
                        } else if (!hasGestured) {
                            areControlsVisible = !areControlsVisible
                        }
                        hasGestured = false
                    },
                    onDoubleTap = { offset ->
                        if (!isControlsLocked && !hasGestured) {
                            val screenWidth = size.width
                            if (offset.x < screenWidth * 0.38f) {
                                playerManager.seekTo(currentPosition - 10000)
                                doubleTapFeedback = "-10s"
                            } else if (offset.x > screenWidth * 0.62f) {
                                playerManager.seekTo(currentPosition + 10000)
                                doubleTapFeedback = "+10s"
                            } else {
                                playerManager.togglePlayPause()
                            }
                        }
                        hasGestured = false
                    }
                )
            }
            .pointerInput(isControlsLocked) {
                if (!isControlsLocked) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            isTouching = true
                            hasGestured = false
                            dragStartOffset = offset
                            initialSeekPosition = playerManager.currentPositionMs.value
                            initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            initialBrightness = activity?.window?.attributes?.screenBrightness
                                ?.takeIf { it >= 0f } ?: 0.5f
                            dragMode = "none"
                            totalDragX = 0f
                            totalDragY = 0f
                        },
                        onDragEnd = {
                            isTouching = false
                            if (dragMode == "seek" && seekDeltaMs != null) {
                                playerManager.seekTo(seekTargetMs)
                            }
                            dragMode = "none"
                            coroutineScope.launch {
                                delay(700)
                                seekDeltaMs = null
                                volumeLevel = null
                                brightnessLevel = null
                                hasGestured = false
                            }
                        },
                        onDragCancel = {
                            isTouching = false
                            // Commit seek even if gesture receives cancel during quick swipe release
                            if (dragMode == "seek" && seekDeltaMs != null) {
                                playerManager.seekTo(seekTargetMs)
                            }
                            dragMode = "none"
                            coroutineScope.launch {
                                delay(700)
                                seekDeltaMs = null
                                volumeLevel = null
                                brightnessLevel = null
                                hasGestured = false
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            totalDragX += dragAmount.x
                            totalDragY -= dragAmount.y // up is positive

                            val screenWidth = size.width
                            val screenHeight = size.height
                            val absX = abs(totalDragX)
                            val absY = abs(totalDragY)

                            // Initial gesture recognition with threshold to lock axis and prevent conflicts
                            if (dragMode == "none") {
                                if (hypot(totalDragX, totalDragY) > 12f) {
                                    hasGestured = true
                                    val isLeft = dragStartOffset.x < screenWidth * 0.38f
                                    val isRight = dragStartOffset.x > screenWidth * 0.62f

                                    dragMode = when {
                                        absX > absY || (!isLeft && !isRight) -> "seek"
                                        isLeft -> "brightness"
                                        else -> "volume"
                                    }
                                } else {
                                    return@detectDragGestures
                                }
                            }

                            hasGestured = true

                            when (dragMode) {
                                "brightness" -> {
                                    // 1. LEFT SIDE: Continuous brightness adjustment (0-100%)
                                    activity?.window?.let { window ->
                                        val lp = window.attributes
                                        // Use total drag distance from the gesture start, not each
                                        // pointer event, for predictable and slower adjustment.
                                        val newBrightness = (initialBrightness + (totalDragY * 0.0015f))
                                            .coerceIn(0.01f, 1.0f)
                                        lp.screenBrightness = newBrightness
                                        window.attributes = lp
                                        brightnessLevel = newBrightness
                                    }
                                }
                                "volume" -> {
                                    // 2. RIGHT SIDE: Continuous volume adjustment (0-100%)
                                    // About 80 px of vertical travel changes one volume step.
                                    val step = (totalDragY / 80f).toInt()
                                    val newVol = (initialVolume + step).coerceIn(0, maxVolume)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                    volumeLevel = newVol
                                }
                                "seek" -> {
                                    // 3. CENTER: Continuous seek with preview delta (e.g. -00:15 / +00:15)
                                    // Scale scrub range dynamically: at least 90s, up to half the duration or 10 mins max
                                    val scrubRangeMs = if (duration > 0L) {
                                        kotlin.math.max(90000L, kotlin.math.min(duration / 2, 600000L))
                                    } else {
                                        120000L
                                    }
                                    val fraction = totalDragX / (screenWidth * 0.65f)
                                    val delta = (fraction * scrubRangeMs).toLong()
                                    seekDeltaMs = delta
                                    val requestedTarget = (initialSeekPosition + delta).coerceAtLeast(0L)
                                    // Some containers report duration only after the first prepared timeline.
                                    // Never clamp an unknown duration to 0; that restarts the movie on drag seek.
                                    seekTargetMs = if (duration > 0L) {
                                        requestedTarget.coerceAtMost(duration)
                                    } else {
                                        requestedTarget
                                    }
                                }
                            }
                        }
                    )
                }
            }
    ) {
        // Keep the existing Media3 surface as primary; mount VLC only after a Media3 playback error.
        if (isVlcFallback) {
            AndroidView(
                factory = { ctx ->
                    VLCVideoLayout(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        playerManager.attachVlcViews(this)
                    }
                },
                update = { playerManager.attachVlcViews(it) },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = playerManager.exoPlayer
                        useController = false
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        this.resizeMode = playerManager.resizeMode.value.exoMode
                    }
                },
                update = { playerView -> playerView.resizeMode = resizeMode.exoMode },
                modifier = Modifier.fillMaxSize()
            )
        }

        // LEFT EDGE FLOATING BRIGHTNESS BAR (Live percentage & vertical indicator)
        if (brightnessLevel != null) {
            val brightPercent = (brightnessLevel!! * 100).toInt().coerceIn(0, 100)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 24.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xD910121A))
                    .padding(vertical = 18.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.BrightnessMedium,
                        contentDescription = "Brightness",
                        tint = CyanAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    // Vertical Progress Slider Track
                    Box(
                        modifier = Modifier
                            .width(8.dp)
                            .height(100.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF2E3344))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(brightnessLevel!!.coerceIn(0f, 1f))
                                .align(Alignment.BottomCenter)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Brush.verticalGradient(listOf(CyanAccent, BlueAccent)))
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "$brightPercent%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // RIGHT EDGE FLOATING VOLUME BAR (Live percentage & vertical indicator)
        if (volumeLevel != null) {
            val volPercent = ((volumeLevel!!.toFloat() / maxVolume) * 100).toInt().coerceIn(0, 100)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 24.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xD910121A))
                    .padding(vertical = 18.dp, horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (volumeLevel == 0) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Volume",
                        tint = CyanAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    // Vertical Progress Slider Track
                    Box(
                        modifier = Modifier
                            .width(8.dp)
                            .height(100.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF2E3344))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight((volumeLevel!!.toFloat() / maxVolume).coerceIn(0f, 1f))
                                .align(Alignment.BottomCenter)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Brush.verticalGradient(listOf(CyanAccent, BlueAccent)))
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "$volPercent%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // MX PLAYER-STYLE CONTINUOUS SEEK PREVIEW OVERLAY (Central Video Area)
        if (seekDeltaMs != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (seekDeltaMs!! >= 0) Icons.Default.FastForward else Icons.Default.FastRewind,
                            contentDescription = null,
                            tint = if (seekDeltaMs!! >= 0) CyanAccent else OrangeAccent,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = formatDeltaTime(seekDeltaMs!!),
                            color = if (seekDeltaMs!! >= 0) CyanAccent else OrangeAccent,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 24.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${formatTime(seekTargetMs)} / ${formatTime(duration)}",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { if (duration > 0) (seekTargetMs.toFloat() / duration).coerceIn(0f, 1f) else 0f },
                        modifier = Modifier
                            .width(160.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = CyanAccent,
                        trackColor = Color.DarkGray
                    )
                }
            }
        }

        if (doubleTapFeedback != null && seekDeltaMs == null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(20.dp)
            ) {
                Text(
                    text = doubleTapFeedback ?: "",
                    color = CyanAccent,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            }
        }

        // FULLY TRANSPARENT OVERLAY CONTROLS (Only visible when not in PiP mode)
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = areControlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Transparent)
                ) {
                    if (isControlsLocked) {
                        // Unlock button
                        IconButton(
                            onClick = { isControlsLocked = false },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(24.dp)
                                .clip(CircleShape)
                                .background(Color(0x80000000))
                                .size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Unlock Controls",
                                tint = CyanAccent
                            )
                        }
                    } else {
                        // Top Toolbar (Subtly translucent gradient scrim, fully visible video behind)
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                .background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent)))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .statusBarsPadding(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onBackClick) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = currentVideo?.displayName ?: "Playing Video",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${currentVideo?.resolutionLabel ?: "HD"} • ${playbackSpeed}x",
                                    color = CyanAccent,
                                    fontSize = 11.sp
                                )
                            }

                            // AUDIO LANGUAGE / TRACK BUTTON
                            IconButton(onClick = { showAudioDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Audio Language",
                                    tint = if (availableAudioTracks.size > 1) CyanAccent else TextPrimary
                                )
                            }

                            // Subtitle Track Button
                            IconButton(onClick = { showSubtitleDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Subtitles,
                                    contentDescription = "Subtitles",
                                    tint = TextPrimary
                                )
                            }

                            // Playback Speed Button
                            IconButton(onClick = { showSpeedDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = "Speed",
                                    tint = TextPrimary
                                )
                            }

                            // Aspect Ratio Mode Switcher
                            IconButton(onClick = { showAspectDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.AspectRatio,
                                    contentDescription = "Aspect Ratio",
                                    tint = TextPrimary
                                )
                            }

                            // Picture-in-Picture Button
                            IconButton(onClick = onEnterPip) {
                                Icon(
                                    imageVector = Icons.Default.PictureInPictureAlt,
                                    contentDescription = "Picture-in-Picture",
                                    tint = CyanAccent
                                )
                            }

                            // Screen Lock Button
                            IconButton(onClick = { isControlsLocked = true }) {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = "Lock Screen",
                                    tint = TextPrimary
                                )
                            }
                        }

                        // Bottom Toolbar & Controls (Transparent background with subtle gradient scrim)
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0x66000000))))
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .navigationBarsPadding()
                        ) {
                            // Time codes
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = formatTime(currentPosition),
                                    color = CyanAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = formatTime(duration),
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }

                            // Scrubber / Seek Bar
                            Slider(
                                value = if (isSeekBarDragging) seekBarFraction else if (duration > 0) (currentPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                                onValueChange = { fraction ->
                                    if (duration > 0L) {
                                        isSeekBarDragging = true
                                        seekBarFraction = fraction
                                    }
                                },
                                onValueChangeFinished = {
                                    if (isSeekBarDragging && duration > 0L) {
                                        playerManager.seekTo((seekBarFraction * duration).toLong())
                                    }
                                    isSeekBarDragging = false
                                },
                                enabled = duration > 0L,
                                colors = SliderDefaults.colors(
                                    thumbColor = CyanAccent,
                                    activeTrackColor = CyanAccent,
                                    inactiveTrackColor = Color(0x66FFFFFF)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Controls Row: Previous, Play/Pause and Next perfectly aligned horizontally
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Left aspect ratio quick indicator
                                TextButton(
                                    onClick = { playerManager.cycleResizeMode() },
                                    colors = ButtonDefaults.textButtonColors(contentColor = TextPrimary)
                                ) {
                                    Text(
                                        text = resizeMode.label.take(4).uppercase(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanAccent
                                    )
                                }

                                // Center Three Buttons (Previous, Play/Pause, Next) evenly arranged
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(28.dp, Alignment.CenterHorizontally),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Previous Video
                                    IconButton(
                                        onClick = { playerManager.playPrevious() },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SkipPrevious,
                                            contentDescription = "Previous Video",
                                            tint = TextPrimary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }

                                    // Play / Pause Button
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(CyanAccent)
                                            .clickable { playerManager.togglePlayPause() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlaying) "Pause" else "Play",
                                            tint = Color.Black,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }

                                    // Next Video
                                    IconButton(
                                        onClick = { playerManager.playNext() },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.SkipNext,
                                            contentDescription = "Next Video",
                                            tint = TextPrimary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }

                                // Right Orientation Toggle Button
                                IconButton(
                                    onClick = {
                                        activity?.let {
                                            val currentOrientation = it.requestedOrientation
                                            it.requestedOrientation = if (currentOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            } else {
                                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ScreenRotation,
                                        contentDescription = "Rotate Screen",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Audio Language / Track Selector Dialog
    if (showAudioDialog) {
        AlertDialog(
            onDismissRequest = { showAudioDialog = false },
            containerColor = DarkCard,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = CyanAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Audio Track / Language", color = TextPrimary)
                }
            },
            text = {
                Column {
                    if (availableAudioTracks.isEmpty()) {
                        Text(
                            text = "No alternate audio tracks available for this video.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        availableAudioTracks.forEach { track ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        playerManager.selectAudioTrack(track)
                                        showAudioDialog = false
                                    }
                                    .padding(vertical = 10.dp, horizontal = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = track.name,
                                        color = if (track.isSelected) CyanAccent else TextPrimary,
                                        fontWeight = if (track.isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                    if (track.language != null) {
                                        Text(
                                            text = "Language: ${formatLanguageName(track.language)} (${track.channels} channels)",
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                if (track.isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAudioDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // Playback Speed Dialog
    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            containerColor = DarkCard,
            title = { Text("Playback Speed", color = TextPrimary) },
            text = {
                Column {
                    speeds.forEach { speed ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.setSpeed(speed)
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${speed}x ${if (speed == 1.0f) "(Normal)" else ""}",
                                color = if (playbackSpeed == speed) CyanAccent else TextPrimary,
                                fontWeight = if (playbackSpeed == speed) FontWeight.Bold else FontWeight.Normal
                            )
                            if (playbackSpeed == speed) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // Aspect Ratio Dialog
    if (showAspectDialog) {
        AlertDialog(
            onDismissRequest = { showAspectDialog = false },
            containerColor = DarkCard,
            title = { Text("Aspect Ratio & Fit Mode", color = TextPrimary) },
            text = {
                Column {
                    ResizeMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.setResizeMode(mode)
                                    showAspectDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mode.label,
                                color = if (resizeMode == mode) CyanAccent else TextPrimary,
                                fontWeight = if (resizeMode == mode) FontWeight.Bold else FontWeight.Normal
                            )
                            if (resizeMode == mode) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAspectDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // Subtitles Dialog
    if (showSubtitleDialog) {
        AlertDialog(
            onDismissRequest = { showSubtitleDialog = false },
            containerColor = DarkCard,
            title = { Text("Subtitles", color = TextPrimary) },
            text = {
                Column {
                    Text("Select Subtitle Track:", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    availableSubtitles.forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.selectSubtitleTrack(track)
                                    showSubtitleDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = track.name,
                                color = if (track.isSelected) CyanAccent else TextPrimary
                            )
                            if (track.isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            subtitleFilePicker.launch("*/*")
                            showSubtitleDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Load External Subtitle (.srt / .vtt)")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSubtitleDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

private fun formatLanguageName(languageCode: String?): String {
    if (languageCode.isNullOrBlank()) return "Unknown"

    val normalized = languageCode.trim().replace('_', '-')
    val locale = Locale.forLanguageTag(normalized)
    val englishName = locale.getDisplayLanguage(Locale.ENGLISH)
    val nativeName = locale.getDisplayLanguage(locale)

    if (englishName.isBlank() || englishName.equals(normalized, ignoreCase = true)) {
        return languageCode
    }
    return if (nativeName.isNotBlank() && !nativeName.equals(englishName, ignoreCase = true)) {
        "$englishName - $nativeName"
    } else {
        englishName
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

fun formatDeltaTime(deltaMs: Long): String {
    val totalSeconds = (kotlin.math.abs(deltaMs) / 1000).coerceAtLeast(0)
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val sign = if (deltaMs >= 0) "+" else "-"
    return String.format("%s%02d:%02d", sign, minutes, seconds)
}
