package com.bt.videoplayer.data.model

import android.net.Uri

data class SubtitleTrack(
    val id: String,
    val name: String,
    val language: String? = null,
    val uri: Uri? = null,
    val isExternal: Boolean = false,
    val isSelected: Boolean = false,
    val groupIndex: Int = -1,
    val trackIndex: Int = -1
)
