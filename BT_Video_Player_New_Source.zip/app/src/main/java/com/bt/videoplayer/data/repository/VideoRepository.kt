package com.bt.videoplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.bt.videoplayer.data.model.FolderItem
import com.bt.videoplayer.data.model.VideoItem
import com.bt.videoplayer.data.preferences.PlayerPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class VideoRepository(
    private val context: Context,
    private val preferences: PlayerPreferences
) {
    suspend fun getAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        // VOLUME_EXTERNAL is the aggregate external-storage collection on Android 10+.
        // Keep EXTERNAL_CONTENT_URI as a fallback for device/provider compatibility.
        val candidateUris = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            listOf(
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL),
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            ).distinct()
        } else {
            listOf(MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        }

        for (collectionUri in candidateUris) {
            val result = queryVideos(collectionUri, includeOptionalColumns = true)
            if (result.isNotEmpty()) return@withContext result
        }

        // Some OEM MediaStore providers reject optional/deprecated columns.
        // Retry with only stable columns rather than silently returning an empty library.
        for (collectionUri in candidateUris) {
            val result = queryVideos(collectionUri, includeOptionalColumns = false)
            if (result.isNotEmpty()) return@withContext result
        }

        emptyList()
    }

    private fun queryVideos(
        collectionUri: Uri,
        includeOptionalColumns: Boolean
    ): List<VideoItem> {
        val projection = if (includeOptionalColumns) {
            buildList {
                add(MediaStore.Video.Media._ID)
                add(MediaStore.Video.Media.TITLE)
                add(MediaStore.Video.Media.DISPLAY_NAME)
                add(MediaStore.Video.Media.DURATION)
                add(MediaStore.Video.Media.SIZE)
                add(MediaStore.Video.Media.DATE_ADDED)
                add(MediaStore.Video.Media.DATA)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    add(MediaStore.Video.Media.RELATIVE_PATH)
                }
                add(MediaStore.Video.Media.WIDTH)
                add(MediaStore.Video.Media.HEIGHT)
            }.toTypedArray()
        } else {
            arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_ADDED
            )
        }

        val videos = mutableListOf<VideoItem>()
        return try {
            context.contentResolver.query(
                collectionUri,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Video.Media.TITLE)
                val displayCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val durationCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val dataCol = cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                val relativePathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                } else -1
                val widthCol = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)

                if (idCol < 0) return@use videos

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.stringOrEmpty(displayCol)
                    val rawTitle = cursor.stringOrEmpty(titleCol)
                        .ifBlank { displayName.ifBlank { "Untitled Video" } }
                    val path = cursor.stringOrEmpty(dataCol)
                    val relativePath = cursor.stringOrEmpty(relativePathCol)
                    val folderName = relativePath.trimEnd('/')
                        .substringAfterLast('/', "")
                        .ifBlank {
                            File(path).parentFile?.name?.takeIf { it.isNotBlank() } ?: "Videos"
                        }

                    videos.add(
                        VideoItem(
                            id = id,
                            title = rawTitle,
                            displayName = displayName.ifBlank { rawTitle },
                            uri = ContentUris.withAppendedId(collectionUri, id),
                            path = path,
                            durationMs = cursor.longOrZero(durationCol),
                            sizeBytes = cursor.longOrZero(sizeCol),
                            dateAdded = cursor.longOrZero(dateCol),
                            folderName = folderName,
                            width = cursor.intOrZero(widthCol),
                            height = cursor.intOrZero(heightCol),
                            isFavorite = preferences.isFavorite(id),
                            lastPositionMs = preferences.getLastPosition(id)
                        )
                    )
                }
                videos
            } ?: emptyList()
        } catch (e: Exception) {
            android.util.Log.e("BTVideoPlayer", "MediaStore query failed for $collectionUri", e)
            emptyList()
        }
    }

    private fun android.database.Cursor.stringOrEmpty(index: Int): String =
        if (index >= 0 && !isNull(index)) getString(index).orEmpty() else ""

    private fun android.database.Cursor.longOrZero(index: Int): Long =
        if (index >= 0 && !isNull(index)) getLong(index) else 0L

    private fun android.database.Cursor.intOrZero(index: Int): Int =
        if (index >= 0 && !isNull(index)) getInt(index) else 0

    suspend fun getFolders(videos: List<VideoItem>): List<FolderItem> =
        withContext(Dispatchers.Default) {
            videos.groupBy { it.folderName.ifBlank { "Videos" } }
                .map { (name, videoGroup) ->
                    val samplePath = videoGroup.firstOrNull()?.path.orEmpty()
                    val folderPath = try {
                        File(samplePath).parent ?: name
                    } catch (_: Exception) {
                        name
                    }
                    FolderItem(
                        name = name,
                        path = folderPath,
                        videoCount = videoGroup.size,
                        totalSizeBytes = videoGroup.sumOf { it.sizeBytes },
                        latestVideoDate = videoGroup.maxOfOrNull { it.dateAdded } ?: 0L
                    )
                }
                .sortedByDescending { it.videoCount }
        }

    fun toggleFavorite(videoId: Long): Boolean = preferences.toggleFavorite(videoId)

    fun saveResumePosition(videoId: Long, posMs: Long) {
        preferences.saveLastPosition(videoId, posMs)
    }
}
