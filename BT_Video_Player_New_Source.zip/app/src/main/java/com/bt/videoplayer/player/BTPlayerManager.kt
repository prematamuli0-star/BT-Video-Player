package com.bt.videoplayer.player

import android.content.Context
import android.net.Uri
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.bt.videoplayer.data.model.AudioTrack
import com.bt.videoplayer.data.model.SubtitleTrack
import com.bt.videoplayer.data.model.VideoItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

@OptIn(UnstableApi::class)
class BTPlayerManager(private val context: Context) {

    private val trackSelector = DefaultTrackSelector(context)
    private val libVlc: LibVLC by lazy { LibVLC(context, arrayListOf("--no-drop-late-frames", "--no-skip-frames")) }
    private val vlcPlayer: MediaPlayer by lazy { MediaPlayer(libVlc) }
    private var vlcViewsAttached = false
    private var pendingVlcStart = false
    // VLC can ignore an initial seek issued before playback reaches Playing.
    private var pendingVlcSeekMs: Long? = null
    private var vlcPlaybackStarted = false
    private var fallbackAttemptedForCurrentItem = false

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context)
        .setTrackSelector(trackSelector)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            /* handleAudioFocus = */ true
        )
        .build()

    private val _isVlcFallback = MutableStateFlow(false)
    val isVlcFallback: StateFlow<Boolean> = _isVlcFallback.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _bufferedPositionMs = MutableStateFlow(0L)
    val bufferedPositionMs: StateFlow<Long> = _bufferedPositionMs.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _resizeMode = MutableStateFlow(ResizeMode.FIT)
    val resizeMode: StateFlow<ResizeMode> = _resizeMode.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _availableSubtitles = MutableStateFlow<List<SubtitleTrack>>(emptyList())
    val availableSubtitles: StateFlow<List<SubtitleTrack>> = _availableSubtitles.asStateFlow()

    private val _availableAudioTracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    val availableAudioTracks: StateFlow<List<AudioTrack>> = _availableAudioTracks.asStateFlow()

    private var playlist: List<VideoItem> = emptyList()
    private var currentIndex: Int = -1

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!_isVlcFallback.value) _isPlaying.value = isPlaying
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                // Attempt VLC exactly once for this item to avoid engine-switch loops.
                if (!fallbackAttemptedForCurrentItem) {
                    fallbackAttemptedForCurrentItem = true
                    startVlcFallback(exoPlayer.currentPosition)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(0L)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                extractSubtitleTracks(tracks)
                extractAudioTracks(tracks)
            }
        })
    }

    fun setPlaylist(videos: List<VideoItem>, startIndex: Int, startPositionMs: Long = 0L) {
        playlist = videos
        currentIndex = startIndex.coerceIn(0, (videos.size - 1).coerceAtLeast(0))
        if (videos.isNotEmpty() && currentIndex in videos.indices) {
            playVideo(videos[currentIndex], startPositionMs)
        }
    }

    fun playVideo(video: VideoItem, startPositionMs: Long = 0L) {
        fallbackAttemptedForCurrentItem = false
        pendingVlcSeekMs = null
        if (_isVlcFallback.value) {
            stopVlcFallback()
        }
        _currentVideo.value = video
        val mediaItem = MediaItem.fromUri(video.uri)
        // Set the requested start position as part of the media item. This avoids
        // issuing a seek against an unprepared/unknown timeline (which can resolve to 0).
        exoPlayer.setMediaItem(mediaItem, startPositionMs.coerceAtLeast(0L))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    fun play() {
        if (_isVlcFallback.value) vlcPlayer.play() else exoPlayer.play()
    }

    fun pause() {
        if (_isVlcFallback.value) vlcPlayer.pause() else exoPlayer.pause()
    }

    fun togglePlayPause() {
        if (_isVlcFallback.value) {
            if (vlcPlayer.isPlaying) pause() else play()
        } else if (exoPlayer.isPlaying) pause() else play()
    }

    /** Called by the VLC surface hosted by PlayerScreen. */
    fun attachVlcViews(layout: VLCVideoLayout) {
        if (!vlcViewsAttached) {
            vlcPlayer.attachViews(layout, null, false, false)
            vlcViewsAttached = true
        }
        if (pendingVlcStart) startPendingVlcMedia()
    }

    fun detachVlcViews() {
        if (vlcViewsAttached) {
            vlcPlayer.detachViews()
            vlcViewsAttached = false
        }
    }

    private fun startVlcFallback(positionMs: Long) {
        val video = _currentVideo.value ?: return
        _currentPositionMs.value = positionMs.coerceAtLeast(0L)
        pendingVlcSeekMs = positionMs.coerceAtLeast(0L)
        _isVlcFallback.value = true
        _isPlaying.value = false
        exoPlayer.pause()
        pendingVlcStart = true
        vlcPlaybackStarted = false
        if (vlcViewsAttached) startPendingVlcMedia()
    }

    private fun startPendingVlcMedia() {
        val video = _currentVideo.value ?: return
        pendingVlcStart = false
        vlcPlaybackStarted = false
        try {
            val media = Media(libVlc, video.uri)
            vlcPlayer.media = media
            media.release()
            vlcPlayer.setEventListener { event ->
                when (event.type) {
                    MediaPlayer.Event.Playing -> {
                        vlcPlaybackStarted = true
                        _isPlaying.value = true
                        // Apply the saved position only after VLC has actually started.
                        pendingVlcSeekMs?.let { target ->
                            pendingVlcSeekMs = null
                            vlcPlayer.setTime(target)
                        }
                    }
                    MediaPlayer.Event.Paused -> _isPlaying.value = false
                    MediaPlayer.Event.Stopped -> {
                        _isPlaying.value = false
                        vlcPlaybackStarted = false
                    }
                    MediaPlayer.Event.TimeChanged -> {
                        _currentPositionMs.value = vlcPlayer.time.coerceAtLeast(0L)
                        _durationMs.value = vlcPlayer.length.coerceAtLeast(0L)
                    }
                    MediaPlayer.Event.EncounteredError -> {
                        _isPlaying.value = false
                        _durationMs.value = 0L
                    }
                }
            }
            vlcPlayer.play()
        } catch (_: Exception) {
            _isPlaying.value = false
        }
    }

    private fun stopVlcFallback() {
        try { vlcPlayer.stop() } catch (_: Exception) { }
        vlcPlaybackStarted = false
        pendingVlcSeekMs = null
        _isVlcFallback.value = false
        _isPlaying.value = false
    }

    fun seekTo(positionMs: Long) {
        val requestedPosition = positionMs.coerceAtLeast(0L)
        if (_isVlcFallback.value) {
            val length = vlcPlayer.length
            val target = if (length > 0L) requestedPosition.coerceAtMost(length) else requestedPosition
            _currentPositionMs.value = target
            if (vlcPlaybackStarted) {
                // VLC accepts setTime while paused as well as while playing.
                vlcPlayer.setTime(target)
                pendingVlcSeekMs = null
            } else {
                // Keep the target until VLC is ready/playing; do not lose early seeks.
                pendingVlcSeekMs = target
            }
            return
        }
        val mediaDuration = exoPlayer.duration

        // C.TIME_UNSET / 0 means duration is not known yet. Do not clamp to 0:
        // that made seek gestures on some files jump back to the beginning.
        val targetPosition = if (mediaDuration != C.TIME_UNSET && mediaDuration > 0L) {
            requestedPosition.coerceAtMost(mediaDuration)
        } else {
            requestedPosition
        }

        // EXACT seeks avoid landing at a distant keyframe in long-GOP/high-bitrate
        // MKV/MP4 files. This applies consistently to buttons, gestures and the scrubber.
        exoPlayer.setSeekParameters(SeekParameters.EXACT)
        exoPlayer.seekTo(targetPosition)
        _currentPositionMs.value = targetPosition
        updatePosition()
    }

    fun playNext(): Boolean {
        if (playlist.isNotEmpty() && currentIndex < playlist.size - 1) {
            currentIndex++
            playVideo(playlist[currentIndex])
            return true
        }
        return false
    }

    fun playPrevious(): Boolean {
        if (playlist.isNotEmpty() && currentIndex > 0) {
            currentIndex--
            playVideo(playlist[currentIndex])
            return true
        } else {
            // Reset whichever engine is active, including VLC fallback.
            seekTo(0L)
            return false
        }
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        _playbackSpeed.value = clamped
        if (_isVlcFallback.value) vlcPlayer.setRate(clamped) else exoPlayer.playbackParameters = PlaybackParameters(clamped)
    }

    fun setResizeMode(mode: ResizeMode) {
        _resizeMode.value = mode
    }

    fun cycleResizeMode() {
        val modes = ResizeMode.values()
        val nextIndex = (modes.indexOf(_resizeMode.value) + 1) % modes.size
        _resizeMode.value = modes[nextIndex]
    }

    fun loadExternalSubtitle(uri: Uri, mimeType: String = MimeTypes.APPLICATION_SUBRIP) {
        val current = _currentVideo.value ?: return
        val currentPos = exoPlayer.currentPosition

        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mimeType)
            .setLanguage("custom")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(current.uri)
            .setSubtitleConfigurations(listOf(subtitleConfig))
            .build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.seekTo(currentPos)
        exoPlayer.playWhenReady = true
    }

    private fun extractSubtitleTracks(tracks: Tracks) {
        val subs = mutableListOf<SubtitleTrack>()
        val textGroups = tracks.groups.withIndex()
            .filter { it.value.type == C.TRACK_TYPE_TEXT }
        val hasSelectedSubtitle = textGroups.any { indexedGroup ->
            (0 until indexedGroup.value.length).any { indexedGroup.value.isTrackSelected(it) }
        }

        // "Off" is selected only when no text track is currently active.
        subs.add(SubtitleTrack("none", "Off (None)", isSelected = !hasSelectedSubtitle))

        textGroups.forEach { indexedGroup ->
            val groupIndex = indexedGroup.index
            val group = indexedGroup.value
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val label = format.label ?: format.language ?: "Track ${subs.size}"
                subs.add(
                    SubtitleTrack(
                        id = format.id ?: "$groupIndex-$i",
                        name = label,
                        language = format.language,
                        isSelected = group.isTrackSelected(i),
                        groupIndex = groupIndex,
                        trackIndex = i
                    )
                )
            }
        }
        _availableSubtitles.value = subs
    }

    private fun extractAudioTracks(tracks: Tracks) {
        val audioList = mutableListOf<AudioTrack>()
        var audioGroupIdx = 0
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val lang = format.language
                    val langName = if (!lang.isNullOrBlank()) {
                        try {
                            val loc = Locale(lang)
                            loc.displayLanguage.ifBlank { lang }
                        } catch (e: Exception) {
                            lang
                        }
                    } else null

                    val label = format.label ?: langName ?: "Audio Track ${audioList.size + 1}"
                    val isSelected = group.isTrackSelected(i)
                    audioList.add(
                        AudioTrack(
                            id = format.id ?: "$audioGroupIdx-$i",
                            name = label,
                            language = lang,
                            channels = format.channelCount,
                            sampleRate = format.sampleRate,
                            isSelected = isSelected,
                            groupIndex = audioGroupIdx,
                            trackIndex = i
                        )
                    )
                }
                audioGroupIdx++
            }
        }
        _availableAudioTracks.value = audioList
    }

    fun selectSubtitleTrack(track: SubtitleTrack) {
        val parameters = trackSelector.buildUponParameters()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)

        if (track.id == "none") {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            val selectedGroup = exoPlayer.currentTracks.groups
                .getOrNull(track.groupIndex)
                ?.takeIf { it.type == C.TRACK_TYPE_TEXT }

            if (selectedGroup != null && track.trackIndex in 0 until selectedGroup.length) {
                // Select this exact track, not merely the preferred language.
                parameters.addOverride(
                    TrackSelectionOverride(
                        selectedGroup.mediaTrackGroup,
                        track.trackIndex
                    )
                )
            } else if (track.language != null) {
                // Fallback for a track whose group is no longer present.
                parameters.setPreferredTextLanguage(track.language)
            }
        }
        trackSelector.setParameters(parameters)
    }

    fun selectAudioTrack(track: AudioTrack) {
        val parameters = trackSelector.buildUponParameters()
        if (track.language != null) {
            parameters.setPreferredAudioLanguage(track.language)
        }
        trackSelector.setParameters(parameters)
    }

    fun updatePosition() {
        if (_isVlcFallback.value) {
            _currentPositionMs.value = vlcPlayer.time.coerceAtLeast(0L)
            _durationMs.value = vlcPlayer.length.coerceAtLeast(0L)
            _bufferedPositionMs.value = _currentPositionMs.value
        } else {
            _currentPositionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
            _bufferedPositionMs.value = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            _durationMs.value = exoPlayer.duration.coerceAtLeast(0L)
        }
    }

    fun release() {
        try { vlcPlayer.stop() } catch (_: Exception) { }
        if (vlcViewsAttached) detachVlcViews()
        try { vlcPlayer.release() } catch (_: Exception) { }
        try { libVlc.release() } catch (_: Exception) { }
        exoPlayer.release()
    }
}
