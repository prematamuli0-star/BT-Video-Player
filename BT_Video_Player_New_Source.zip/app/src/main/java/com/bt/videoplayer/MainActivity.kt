package com.bt.videoplayer

import android.Manifest
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.bt.videoplayer.data.model.FolderItem
import com.bt.videoplayer.data.model.VideoItem
import com.bt.videoplayer.data.preferences.PlayerPreferences
import com.bt.videoplayer.data.repository.VideoRepository
import com.bt.videoplayer.player.BTPlayerManager
import com.bt.videoplayer.ui.screens.home.HomeScreen
import com.bt.videoplayer.ui.screens.player.PlayerScreen
import com.bt.videoplayer.ui.theme.BTVideoPlayerTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var preferences: PlayerPreferences
    private lateinit var repository: VideoRepository
    private lateinit var playerManager: BTPlayerManager

    private val videosState = MutableStateFlow<List<VideoItem>>(emptyList())
    private val foldersState = MutableStateFlow<List<FolderItem>>(emptyList())
    private val isPlayerActive = MutableStateFlow(false)
    private val isInPipState = MutableStateFlow(false)

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.any { it }
        if (granted) {
            loadVideos()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable edge-to-edge layout & cutout mode
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.attributes.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES

        preferences = PlayerPreferences(this)
        repository = VideoRepository(this, preferences)
        playerManager = BTPlayerManager(this)

        setContent {
            BTVideoPlayerTheme {
                // Collect StateFlows so Compose redraws when media scanning finishes.
                // Reading StateFlow.value directly does not subscribe to updates.
                val videos = videosState.collectAsState().value
                val folders = foldersState.collectAsState().value
                val showPlayer = isPlayerActive.collectAsState().value
                val inPip = isInPipState.collectAsState().value

                if (showPlayer) {
                    PlayerScreen(
                        playerManager = playerManager,
                        isInPipMode = inPip,
                        onBackClick = {
                            saveCurrentPosition()
                            playerManager.pause()
                            isPlayerActive.value = false
                            showSystemUi()
                        },
                        onEnterPip = {
                            enterPipMode()
                        }
                    )
                } else {
                    HomeScreen(
                        videos = videos,
                        folders = folders,
                        onVideoClick = { video, playlist ->
                            val index = playlist.indexOfFirst { it.id == video.id }.coerceAtLeast(0)
                            playerManager.setPlaylist(playlist, index, video.lastPositionMs)
                            isPlayerActive.value = true
                            hideSystemUi()
                        },
                        onToggleFavorite = { video ->
                            val isFav = repository.toggleFavorite(video.id)
                            videosState.value = videosState.value.map {
                                if (it.id == video.id) it.copy(isFavorite = isFav) else it
                            }
                        },
                        onRefresh = {
                            loadVideos()
                        }
                    )
                }
            }
        }

        checkAndRequestPermissions()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        // File managers may send the selected item as data (ACTION_VIEW) or
        // as EXTRA_STREAM (ACTION_SEND). Keep the provider's read grant intact.
        val sharedUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        val uri: Uri? = intent.data ?: sharedUri ?: intent.clipData?.getItemAt(0)?.uri
        if (uri != null) {
            if (intent.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) {
                    // Most file managers grant temporary access only; that is
                    // sufficient while the incoming intent is being handled.
                } catch (_: IllegalArgumentException) {
                    // The provider did not offer persistable URI permissions.
                }
            }
            val externalVideo = VideoItem(
                id = System.currentTimeMillis(),
                title = uri.lastPathSegment ?: "External Video",
                displayName = uri.lastPathSegment ?: "External Video",
                uri = uri,
                path = uri.toString(),
                durationMs = 0L,
                sizeBytes = 0L,
                dateAdded = System.currentTimeMillis() / 1000,
                folderName = "External"
            )
            playerManager.setPlaylist(listOf(externalVideo), 0)
            isPlayerActive.value = true
            hideSystemUi()
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            )
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
                arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        // Full video access OR Android 14's selected-video access is sufficient
        // to query the videos the user has allowed this app to see.
        val hasVideoAccess =
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_MEDIA_VIDEO
            ) == PackageManager.PERMISSION_GRANTED ||
            (Build.VERSION.SDK_INT >= 34 &&
                ContextCompat.checkSelfPermission(
                    this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
                ) == PackageManager.PERMISSION_GRANTED) ||
            (Build.VERSION.SDK_INT <= 32 &&
                ContextCompat.checkSelfPermission(
                    this, Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED)

        if (hasVideoAccess) {
            loadVideos()
        } else {
            storagePermissionLauncher.launch(permissions)
        }
    }

    private fun loadVideos() {
        lifecycleScope.launch {
            val list = repository.getAllVideos()
            videosState.value = list
            foldersState.value = repository.getFolders(list)
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val aspectRatio = Rational(16, 9)
                val paramsBuilder = PictureInPictureParams.Builder()
                    .setAspectRatio(aspectRatio)

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    paramsBuilder.setAutoEnterEnabled(true)
                    paramsBuilder.setSeamlessResizeEnabled(true)
                }

                enterPictureInPictureMode(paramsBuilder.build())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Continue playback in PiP mode when returning to Home Screen (Android 8.0+)
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isPlayerActive.value && playerManager.isPlaying.value) {
            enterPipMode()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipState.value = isInPictureInPictureMode
        if (!isInPictureInPictureMode && !isPlayerActive.value) {
            showSystemUi()
        }
    }

    private fun hideSystemUi() {
        val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemUi() {
        val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    private fun saveCurrentPosition() {
        val video = playerManager.currentVideo.value
        if (video != null) {
            val pos = playerManager.currentPositionMs.value
            repository.saveResumePosition(video.id, pos)
        }
    }

    override fun onPause() {
        super.onPause()
        saveCurrentPosition()
        if (!isInPictureInPictureMode) {
            playerManager.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        saveCurrentPosition()
        playerManager.release()
    }
}
