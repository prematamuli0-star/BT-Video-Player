package com.bt.videoplayer

import android.Manifest
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.bt.videoplayer.ads.ConsentAndAdsManager
import com.bt.videoplayer.ads.UmpConsentDialogHost
import com.bt.videoplayer.core.logging.PlayerDiagnosticLogger
import com.bt.videoplayer.data.preferences.PlayerPreferences
import com.bt.videoplayer.data.repository.MediaStoreVideoRepository
import com.bt.videoplayer.data.repository.SafVideoResolver
import com.bt.videoplayer.domain.model.FolderItem
import com.bt.videoplayer.domain.model.VideoItem
import com.bt.videoplayer.player.controller.PlayerController
import com.bt.videoplayer.player.engine.Media3PlaybackEngine
import com.bt.videoplayer.player.engine.VlcPlaybackEngine
import com.bt.videoplayer.ui.screens.home.HomeScreen
import com.bt.videoplayer.ui.screens.player.PlayerScreen
import com.bt.videoplayer.ui.theme.BTVideoPlayerTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var preferences: PlayerPreferences
    private lateinit var videoRepository: MediaStoreVideoRepository
    private lateinit var safVideoResolver: SafVideoResolver
    private lateinit var consentAndAdsManager: ConsentAndAdsManager
    private lateinit var playerController: PlayerController

    private val videosState = MutableStateFlow<List<VideoItem>>(emptyList())
    private val foldersState = MutableStateFlow<List<FolderItem>>(emptyList())
    private val isFullScreenPlayerOpen = MutableStateFlow(false)
    private val isInPipState = MutableStateFlow(false)

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.any { it }) {
            scanMediaLibrary()
        }
    }

    private val safDocumentPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            openExternalOrSafUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val diagnosticLogger = PlayerDiagnosticLogger(enableLogcat = true)
        preferences = PlayerPreferences(this)
        videoRepository = MediaStoreVideoRepository(this, preferences)
        safVideoResolver = SafVideoResolver(this, preferences)
        consentAndAdsManager = ConsentAndAdsManager(this, preferences)

        // Single Media3 primary engine and optional LibVLC fallback engine owned by PlayerController
        val media3Engine = Media3PlaybackEngine(this, diagnosticLogger)
        val vlcEngine = VlcPlaybackEngine(this, diagnosticLogger)

        playerController = PlayerController(
            scope = lifecycleScope,
            primaryEngine = media3Engine,
            fallbackEngine = vlcEngine,
            preferences = preferences,
            logger = diagnosticLogger
        )

        setContent {
            BTVideoPlayerTheme {
                val videos by videosState.collectAsState()
                val folders by foldersState.collectAsState()
                val showPlayer by isFullScreenPlayerOpen.collectAsState()
                val inPip by isInPipState.collectAsState()

                UmpConsentDialogHost(consentManager = consentAndAdsManager)

                if (showPlayer) {
                    PlayerScreen(
                        playerController = playerController,
                        isInPipMode = inPip,
                        onBackClick = {
                            playerController.persistCurrentProgress()
                            refreshResumePositionsInList()
                            isFullScreenPlayerOpen.value = false
                            requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            showSystemUi()
                        },
                        onEnterPip = {
                            enterPipMode()
                        }
                    )
                } else {
                    HomeScreen(
                        videos = videos,
                        folders = folders,
                        playerController = playerController,
                        consentManager = consentAndAdsManager,
                        onVideoClick = { video, playlist ->
                            val activePlaylist = playlist.ifEmpty {
                                videos.ifEmpty { listOf(video) }
                            }
                            val index = activePlaylist.indexOfFirst { it.id == video.id }.coerceAtLeast(0)
                            playerController.loadPlaylist(activePlaylist, index, video.lastPositionMs)
                            isFullScreenPlayerOpen.value = true
                            hideSystemUi()
                        },
                        onResumeFullScreenPlayer = {
                            isFullScreenPlayerOpen.value = true
                            hideSystemUi()
                        },
                        onOpenSafVideoPicker = {
                            safDocumentPickerLauncher.launch(arrayOf("video/*"))
                        },
                        onToggleFavorite = { video ->
                            val isFav = videoRepository.toggleFavorite(video.id)
                            val updated = videosState.value.map {
                                if (it.id == video.id) it.copy(isFavorite = isFav) else it
                            }
                            videosState.value = updated
                            playerController.syncPlaylistItems(updated)
                        },
                        onRefresh = {
                            scanMediaLibrary()
                        }
                    )
                }
            }
        }

        consentAndAdsManager.requestConsentIfNeeded(this)
        checkAndRequestPermissions()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val uri: Uri = intent?.data ?: return
        openExternalOrSafUri(uri)
    }

    private fun openExternalOrSafUri(uri: Uri) {
        lifecycleScope.launch {
            val resolvedVideo = safVideoResolver.resolveUri(uri)
            val combinedPlaylist = listOf(resolvedVideo) + videosState.value.filter { it.id != resolvedVideo.id }
            videosState.value = combinedPlaylist
            playerController.loadPlaylist(combinedPlaylist, 0, resolvedVideo.lastPositionMs)
            isFullScreenPlayerOpen.value = true
            hideSystemUi()
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }

        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) {
            scanMediaLibrary()
        } else {
            storagePermissionLauncher.launch(permissions)
        }
    }

    private fun scanMediaLibrary() {
        lifecycleScope.launch {
            val scanned = videoRepository.scanAllVideos()
            videosState.value = scanned
            foldersState.value = videoRepository.groupFolders(scanned)
            if (scanned.isNotEmpty()) {
                playerController.syncPlaylistItems(scanned)
            }
        }
    }

    private fun refreshResumePositionsInList() {
        val current = playerController.currentVideo.value ?: return
        val savedPos = preferences.getLastPosition(current.id)
        videosState.value = videosState.value.map {
            if (it.id == current.id) it.copy(lastPositionMs = savedPos) else it
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val aspectRatio = Rational(16, 9)
                val paramsBuilder = PictureInPictureParams.Builder()
                    .setAspectRatio(aspectRatio)


                enterPictureInPictureMode(paramsBuilder.build())
            } catch (_: Exception) {
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Intentionally do not enter Android system Picture-in-Picture automatically.
        // The app uses its own in-app floating mini-player on the Folder/Video List screen.
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipState.value = isInPictureInPictureMode
        if (!isInPictureInPictureMode && !isFullScreenPlayerOpen.value) {
            showSystemUi()
        }
    }

    private fun hideSystemUi() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemUi() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onPause() {
        super.onPause()
        playerController.persistCurrentProgress()
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode
        if (!inPip) {
            playerController.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        playerController.release()
    }
}
