package com.btplayer.video.domain.model

/**
 * Active playback engine identifier.
 */
enum class EngineType {
    MEDIA3,
    VLC
}

/**
 * Origin of a seek request so diagnostics and coalescing policies know how it was triggered.
 */
enum class SeekSource {
    DOUBLE_TAP_FORWARD,
    DOUBLE_TAP_BACKWARD,
    SWIPE_GESTURE,
    SEEK_BAR,
    INITIAL_RESUME,
    ENGINE_SWITCH_RESTORE,
    PROGRAMMATIC
}

/**
 * Capability of the current media item and active engine to perform seeking.
 */
enum class SeekCapability {
    /** Timeline has a known finite duration and index/cues or CBR byte-seeking is active. */
    EXACT_OR_KEYFRAME_SEEKABLE,
    /** Engine has not yet reported timeline readiness, but metadata provides a known finite duration. */
    DURATION_KNOWN_PENDING_INDEX,
    /** Duration is unknown/unset (e.g. <= 0 or TIME_UNSET) or engine explicitly reports unseekable without fallback. */
    UNSEEKABLE
}

/**
 * Immutable snapshot of the active playback engine's timeline and position state.
 */
data class EngineTimelineSnapshot(
    val engineType: EngineType = EngineType.MEDIA3,
    val currentPositionMs: Long = 0L,
    val bufferedPositionMs: Long = 0L,
    val engineDurationMs: Long = TIME_UNSET,
    val metadataDurationMs: Long = 0L,
    val isEngineSeekable: Boolean = false,
    val isTimelineReady: Boolean = false,
    val isMkvContainer: Boolean = false
) {
    /**
     * Resolves the authoritative finite duration in milliseconds, or 0L if unknown.
     * Never returns negative or Long.MIN_VALUE (C.TIME_UNSET).
     */
    val resolvedDurationMs: Long
        get() = when {
            engineDurationMs > 0L && engineDurationMs != TIME_UNSET -> engineDurationMs
            metadataDurationMs > 0L && metadataDurationMs != TIME_UNSET -> metadataDurationMs
            else -> 0L
        }

    val hasValidDuration: Boolean
        get() = resolvedDurationMs > 0L

    /**
     * Determines whether seeking can be safely attempted on this media item.
     * Critically, we do NOT assume every MKV file is seekable:
     * - If the engine timeline is ready, we require `isEngineSeekable == true` AND `hasValidDuration`.
     * - If the engine timeline is still preparing, we allow queuing a seek only if metadata duration > 0
     *   AND the engine has not explicitly marked a prepared timeline as unseekable.
     */
    val seekCapability: SeekCapability
        get() = when {
            !hasValidDuration -> SeekCapability.UNSEEKABLE
            isTimelineReady && isEngineSeekable -> SeekCapability.EXACT_OR_KEYFRAME_SEEKABLE
            isTimelineReady && !isEngineSeekable -> SeekCapability.UNSEEKABLE
            else -> SeekCapability.DURATION_KNOWN_PENDING_INDEX
        }

    companion object {
        const val TIME_UNSET: Long = Long.MIN_VALUE + 1L
    }
}

/**
 * Centralized SeekController state machine representation.
 */
sealed class SeekState {
    /** Normal playback; displayedPositionMs mirrors verified engine position. */
    data object Idle : SeekState()

    /** User is actively dragging the seek bar or performing a horizontal swipe gesture. */
    data class Scrubbing(
        val source: SeekSource,
        val startPositionMs: Long,
        val previewPositionMs: Long,
        val deltaMs: Long
    ) : SeekState()

    /**
     * A seek command has been issued (or is accumulating rapid double-taps) and is awaiting
     * asynchronous engine completion. Stale position polling updates are blocked while in this state.
     */
    data class PendingSeek(
        val requestId: Long,
        val source: SeekSource,
        val startPositionMs: Long,
        val targetPositionMs: Long,
        val accumulatedDeltaMs: Long,
        val issuedAtElapsedMs: Long,
        val dispatchedToEngine: Boolean
    ) : SeekState()

    /** Media item cannot be seeked (e.g., corrupted MKV without cues/duration or live stream). */
    data class Unseekable(
        val reason: String
    ) : SeekState()
}

/**
 * Result of a seek request submission.
 */
sealed class SeekSubmissionResult {
    data class Accepted(
        val requestId: Long,
        val targetPositionMs: Long,
        val accumulatedDeltaMs: Long
    ) : SeekSubmissionResult()

    data class PreviewUpdated(
        val previewPositionMs: Long,
        val deltaMs: Long
    ) : SeekSubmissionResult()

    data class RejectedUnseekable(
        val reason: String
    ) : SeekSubmissionResult()
}
