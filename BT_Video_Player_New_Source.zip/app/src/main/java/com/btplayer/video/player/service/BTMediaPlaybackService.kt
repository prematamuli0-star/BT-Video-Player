package com.btplayer.video.player.service

import android.content.Intent
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * AndroidX Media3 [MediaSessionService] providing background playback and system media
 * notification controls (Play/Pause, Seek, Next, Previous) for BT Video Player 2.0.
 */
@OptIn(UnstableApi::class)
class BTMediaPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val basePlayer = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        // ForwardingPlayer ensures system notification seek & transport controls respect seekability
        val forwardingPlayer = object : ForwardingPlayer(basePlayer) {
            override fun seekTo(positionMs: Long) {
                if (isCurrentMediaItemSeekable || duration > 0L) {
                    super.seekTo(positionMs.coerceAtLeast(0L))
                }
            }

            override fun seekForward() {
                val target = (currentPosition + 10_000L).let {
                    if (duration > 0L) it.coerceAtMost(duration) else it
                }
                seekTo(target)
            }

            override fun seekBack() {
                val target = (currentPosition - 10_000L).coerceAtLeast(0L)
                seekTo(target)
            }
        }

        mediaSession = MediaSession.Builder(this, forwardingPlayer).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 || player.playbackState == Player.STATE_ENDED) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
