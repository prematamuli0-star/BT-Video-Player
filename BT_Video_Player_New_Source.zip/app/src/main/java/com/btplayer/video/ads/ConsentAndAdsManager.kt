package com.btplayer.video.ads

import android.app.Activity
import android.content.Context
import android.view.View
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.btplayer.video.data.preferences.PlayerPreferences
import com.btplayer.video.ui.theme.CyanAccent
import com.btplayer.video.ui.theme.DarkBg
import com.btplayer.video.ui.theme.DarkCard
import com.btplayer.video.ui.theme.DarkCardBorder
import com.btplayer.video.ui.theme.DarkSurface
import com.btplayer.video.ui.theme.TextMuted
import com.btplayer.video.ui.theme.TextPrimary
import com.btplayer.video.ui.theme.TextSecondary
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Strongly-typed Google User Messaging Platform (`com.google.android.ump:user-messaging-platform:2.2.0`)
 * and Google Mobile Ads (`com.google.android.gms:play-services-ads:23.0.0`) manager.
 */
class ConsentAndAdsManager(
    private val context: Context,
    private val preferences: PlayerPreferences
) {
    private val isMobileAdsInitialized = AtomicBoolean(false)

    private val _consentGranted = MutableStateFlow(preferences.isUmpConsentCompleted())
    val consentGranted: StateFlow<Boolean> = _consentGranted.asStateFlow()

    private val _showConsentDialog = MutableStateFlow(false)
    val showConsentDialog: StateFlow<Boolean> = _showConsentDialog.asStateFlow()

    private val _adsInitialized = MutableStateFlow(false)
    val adsInitialized: StateFlow<Boolean> = _adsInitialized.asStateFlow()

    fun requestConsentIfNeeded(activity: Activity) {
        try {
            val params = ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false)
                .build()

            val consentInformation: ConsentInformation =
                UserMessagingPlatform.getConsentInformation(activity)

            consentInformation.requestConsentInfoUpdate(
                activity,
                params,
                {
                    UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                        if (consentInformation.canRequestAds()) {
                            preferences.saveUmpConsentCompleted(true)
                            _consentGranted.value = true
                            initializeMobileAds()
                        }
                    }
                },
                { _ ->
                    // Offline or non-GMS fallback: honor saved preference or show local UMP disclosure
                    if (consentInformation.canRequestAds() || _consentGranted.value) {
                        preferences.saveUmpConsentCompleted(true)
                        _consentGranted.value = true
                        initializeMobileAds()
                    } else {
                        _showConsentDialog.value = true
                    }
                }
            )

            if (consentInformation.canRequestAds()) {
                preferences.saveUmpConsentCompleted(true)
                _consentGranted.value = true
                initializeMobileAds()
            }
        } catch (_: Throwable) {
            if (!_consentGranted.value) {
                _showConsentDialog.value = true
            } else {
                initializeMobileAds()
            }
        }
    }

    fun acceptConsent() {
        preferences.saveUmpConsentCompleted(true)
        _consentGranted.value = true
        _showConsentDialog.value = false
        initializeMobileAds()
    }

    fun manageOrRevokeConsent() {
        _showConsentDialog.value = true
    }

    fun dismissConsentDialog() {
        preferences.saveUmpConsentCompleted(true)
        _consentGranted.value = true
        _showConsentDialog.value = false
        initializeMobileAds()
    }

    private fun initializeMobileAds() {
        if (!isMobileAdsInitialized.compareAndSet(false, true)) return
        try {
            MobileAds.initialize(context) {
                _adsInitialized.value = true
            }
        } catch (_: Throwable) {
            _adsInitialized.value = true
        }
    }

    fun createBannerAdView(ctx: Context, adUnitId: String = DEFAULT_TEST_BANNER_AD_UNIT_ID): View {
        return try {
            AdView(ctx).apply {
                setAdSize(AdSize.BANNER)
                this.adUnitId = adUnitId
                loadAd(AdRequest.Builder().build())
            }
        } catch (_: Throwable) {
            View(ctx)
        }
    }

    companion object {
        const val DEFAULT_TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    }
}

@Composable
fun UmpConsentDialogHost(consentManager: ConsentAndAdsManager) {
    val showDialog by consentManager.showConsentDialog.collectAsState()
    if (!showDialog) return

    AlertDialog(
        onDismissRequest = { consentManager.dismissConsentDialog() },
        containerColor = DarkCard,
        title = {
            Text(
                text = "Privacy & Ad Consent (UMP)",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        },
        text = {
            Text(
                text = "BT Video Player uses Google AdMob & User Messaging Platform (UMP) to keep the player free. " +
                    "Ads are shown only on the Home library screen and never interrupt video playback or gestures.",
                color = TextSecondary,
                fontSize = 13.sp
            )
        },
        confirmButton = {
            Button(
                onClick = { consentManager.acceptConsent() },
                colors = ButtonDefaults.buttonColors(containerColor = CyanAccent)
            ) {
                Text("Consent & Continue", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = { consentManager.dismissConsentDialog() }) {
                Text("Non-Personalized Only", color = TextSecondary)
            }
        }
    )
}

@Composable
fun HomeAdMobBannerBar(
    consentManager: ConsentAndAdsManager,
    modifier: Modifier = Modifier
) {
    val consentGranted by consentManager.consentGranted.collectAsState()
    if (!consentGranted) return

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurface)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(DarkCard)
                .border(1.dp, DarkCardBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyanAccent.copy(alpha = 0.18f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "AD",
                        color = CyanAccent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "AdMob Banner • UMP Consent Active",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            AndroidView(
                factory = { ctx -> consentManager.createBannerAdView(ctx) }
            )

            TextButton(onClick = { consentManager.manageOrRevokeConsent() }) {
                Text(
                    text = "Privacy",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }
    }
}
