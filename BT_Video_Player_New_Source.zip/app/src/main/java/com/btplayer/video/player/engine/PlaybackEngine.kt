package com.btplayer.video.player.engine

import android.net.Uri
import android.view.SurfaceView
import com.btplayer.video.domain.model.AudioTrackInfo
import com.btplayer.video.domain.model.EngineTimelineSnapshot
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.SubtitleTrackInfo
import com.btplayer.video.domain.model.VideoItem

/**
 * Callback interface emitted by a concrete [PlaybackEngine] to [com.btplayer.video.player.controller.PlayerController]
 * and [com.btplayer.video.player.seek.SeekController].
 */
interface PlaybackEngineListener {
    fun onTimelineSnapshotChanged(snapshot: EngineTimelineSnapshot)
    fun onPlaybackStateChanged(isPlaying: Boolean, playbackState: Int)
    fun onEngineSeekCompleted(engineType: EngineType, requestId: Long, landedPositionMs: Long)
    fun onEngineSeekFailed(engineType: EngineType, requestId: Long, reason: String)
    fun onTracksUpdated(audioTracks: List<AudioTrackInfo>, subtitleTracks: List<SubtitleTrackInfo>)
    fun onVideoSizeChanged(engineType: EngineType, width: Int, height: Int)
    fun onEngineFatalError(engineType: EngineType, errorCode: String, message: String, isSeekRelated: Boolean)
    fun onMediaEnded(engineType: EngineType)
}

/**
 * Unified abstraction over AndroidX Media3 (primary) and LibVLC (optional automatic fallback).
 * Includes explicit video surface lifecycle management so switching between Media3 and LibVLC
 * detaches the outgoing engine's surface before attaching the incoming engine's surface,
 * preventing black screens or audio-only fallback.
 */
interface PlaybackEngine {
    val engineType: EngineType
    val isAvailable: Boolean
    val isSurfaceAttached: Boolean

    fun setListener(listener: PlaybackEngineListener?)
    fun prepareMedia(video: VideoItem, startPositionMs: Long, autoPlay: Boolean)
    fun play()
    fun pause()
    fun stop()
    fun release()

    /**
     * Attaches a [SurfaceView] for hardware/software video rendering.
     */
    fun attachSurfaceView(surfaceView: SurfaceView?, width: Int, height: Int)

    /**
     * Updates the video output surface dimensions on screen rotation, fullscreen, or PiP resize.
     */
    fun updateSurfaceSize(width: Int, height: Int)

    /**
     * Explicitly detaches any currently bound video output surface so another engine can bind safely.
     */
    fun detachSurface()

    /**
     * Dispatches an asynchronous seek to the underlying native player.
     * Must only be invoked by [com.btplayer.video.player.seek.SeekController].
     */
    fun performEngineSeek(requestId: Long, positionMs: Long): Boolean

    fun setPlaybackSpeed(speed: Float)
    fun selectAudioTrack(track: AudioTrackInfo)
    fun selectSubtitleTrack(track: SubtitleTrackInfo)
    fun loadExternalSubtitle(uri: Uri)

    /**
     * Queries a fresh immutable snapshot of the engine's current timeline, duration, and seekability.
     */
    fun captureTimelineSnapshot(): EngineTimelineSnapshot

    companion object {
        const val STATE_IDLE = 1
        const val STATE_BUFFERING = 2
        const val STATE_READY = 3
        const val STATE_ENDED = 4
    }
}
