package com.btplayer.video.player.engine

import android.content.Context
import android.net.Uri
import android.view.SurfaceView
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import com.btplayer.video.core.logging.DiagnosticCategory
import com.btplayer.video.core.logging.PlayerDiagnosticLogger
import com.btplayer.video.domain.model.AudioTrackInfo
import com.btplayer.video.domain.model.EngineTimelineSnapshot
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.SubtitleTrackInfo
import com.btplayer.video.domain.model.VideoItem

/**
 * Primary playback engine powered by AndroidX Media3 ExoPlayer.
 * Includes explicit surface attachment and detachment (`clearVideoSurface()`) so switching
 * to LibVLC releases the hardware decoder surface cleanly without black screens.
 */
@OptIn(UnstableApi::class)
class Media3PlaybackEngine(
    private val context: Context,
    private val logger: PlayerDiagnosticLogger
) : PlaybackEngine {

    override val engineType: EngineType = EngineType.MEDIA3
    override val isAvailable: Boolean = true

    @Volatile
    override var isSurfaceAttached: Boolean = false
        private set

    private var listener: PlaybackEngineListener? = null
    private var currentVideo: VideoItem? = null
    private var boundSurfaceView: SurfaceView? = null
    private val externalSubtitles = mutableListOf<SubtitleTrackInfo>()

    @Volatile
    private var activeSeekRequestId: Long = 0L

    val exoPlayer: ExoPlayer by lazy {
        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)

        // Enable CBR seeking only when the extractor can identify a valid constant-bitrate
        // stream. Do NOT force it for every file: forcing CBR byte seeking on variable-bitrate
        // MP4/MKV files can calculate invalid byte offsets and make a seek jump to the start.
        val extractorsFactory = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setMatroskaExtractorFlags(0)

        val mediaSourceFactory = DefaultMediaSourceFactory(context, extractorsFactory)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setSeekParameters(SeekParameters.EXACT)
            .build()
            .apply {
                addListener(playerListener)
            }
    }

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            val snapshot = captureTimelineSnapshot()
            listener?.onTimelineSnapshotChanged(snapshot)
            listener?.onPlaybackStateChanged(exoPlayer.isPlaying, mapState(playbackState))

            // A READY state is not proof that a seek completed: it can be emitted for the
            // pre-seek position. Seek completion is acknowledged only by the explicit
            // DISCONTINUITY_REASON_SEEK callback below.
            if (playbackState == Player.STATE_ENDED) {
                listener?.onMediaEnded(EngineType.MEDIA3)
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            listener?.onPlaybackStateChanged(isPlaying, mapState(exoPlayer.playbackState))
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                listener?.onVideoSizeChanged(EngineType.MEDIA3, videoSize.width, videoSize.height)
            }
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            val snapshot = captureTimelineSnapshot()
            logger.log(
                category = DiagnosticCategory.TIMELINE,
                message = "Media3 timeline updated",
                details = mapOf(
                    "reason" to reason,
                    "engineDurationMs" to snapshot.engineDurationMs,
                    "resolvedDurationMs" to snapshot.resolvedDurationMs,
                    "isSeekable" to snapshot.isEngineSeekable,
                    "capability" to snapshot.seekCapability.name
                )
            )
            listener?.onTimelineSnapshotChanged(snapshot)
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int
        ) {
            if (reason == Player.DISCONTINUITY_REASON_SEEK ||
                reason == Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT
            ) {
                val reqId = activeSeekRequestId
                val landed = newPosition.positionMs.coerceAtLeast(0L)
                logger.log(
                    category = DiagnosticCategory.SEEK,
                    message = "Media3 position discontinuity on seek",
                    details = mapOf(
                        "requestId" to reqId,
                        "oldPosMs" to oldPosition.positionMs,
                        "newPosMs" to landed,
                        "reason" to reason
                    )
                )
                if (reqId != 0L) {
                    activeSeekRequestId = 0L
                    listener?.onEngineSeekCompleted(EngineType.MEDIA3, reqId, landed)
                }
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            val (audioList, subtitleList) = extractTracks(tracks)
            listener?.onTracksUpdated(audioList, subtitleList)
        }

        override fun onPlayerError(error: PlaybackException) {
            val isSeekError = activeSeekRequestId != 0L
            val failedReqId = activeSeekRequestId
            activeSeekRequestId = 0L

            logger.log(
                category = DiagnosticCategory.ENGINE,
                message = "Media3 playback error",
                details = mapOf(
                    "errorCode" to error.errorCodeName,
                    "message" to error.message,
                    "isSeekError" to isSeekError
                ),
                isWarningOrError = true
            )

            if (isSeekError && failedReqId != 0L) {
                listener?.onEngineSeekFailed(
                    EngineType.MEDIA3,
                    failedReqId,
                    "${error.errorCodeName}: ${error.message}"
                )
            }

            listener?.onEngineFatalError(
                engineType = EngineType.MEDIA3,
                errorCode = error.errorCodeName,
                message = error.message ?: "Unknown Media3 playback error",
                isSeekRelated = isSeekError
            )
        }
    }

    override fun setListener(listener: PlaybackEngineListener?) {
        this.listener = listener
    }

    override fun attachSurfaceView(surfaceView: SurfaceView?, width: Int, height: Int) {
        boundSurfaceView = surfaceView
        if (surfaceView != null) {
            exoPlayer.setVideoSurfaceView(surfaceView)
        }
        isSurfaceAttached = true
        logger.log(
            category = DiagnosticCategory.ENGINE,
            message = "Media3 video surface attached",
            details = mapOf("width" to width, "height" to height, "hasDirectSurfaceView" to (surfaceView != null))
        )
    }

    override fun updateSurfaceSize(width: Int, height: Int) {
        if (width > 0 && height > 0) {
            logger.log(
                category = DiagnosticCategory.ENGINE,
                message = "Media3 surface size updated",
                details = mapOf("width" to width, "height" to height)
            )
        }
    }

    override fun detachSurface() {
        try {
            val sv = boundSurfaceView
            if (sv != null) {
                exoPlayer.clearVideoSurfaceView(sv)
            } else {
                exoPlayer.clearVideoSurface()
            }
        } catch (_: Throwable) {
        } finally {
            boundSurfaceView = null
            isSurfaceAttached = false
            logger.log(
                category = DiagnosticCategory.ENGINE,
                message = "Media3 video surface detached"
            )
        }
    }

    override fun prepareMedia(video: VideoItem, startPositionMs: Long, autoPlay: Boolean) {
        currentVideo = video
        activeSeekRequestId = 0L
        externalSubtitles.clear()

        val mediaItem = buildMediaItem(video, emptyList())
        val safeStartMs = startPositionMs.coerceAtLeast(0L)

        logger.log(
            category = DiagnosticCategory.ENGINE,
            message = "Media3 preparing media",
            details = mapOf(
                "title" to video.displayName,
                "isMkv" to video.isMkvContainer,
                "metadataDurationMs" to video.durationMs,
                "startPositionMs" to safeStartMs
            )
        )

        if (safeStartMs > 0L) {
            exoPlayer.setMediaItem(mediaItem, safeStartMs)
        } else {
            exoPlayer.setMediaItem(mediaItem)
        }
        exoPlayer.prepare()
        exoPlayer.playWhenReady = autoPlay
    }

    override fun play() {
        exoPlayer.play()
    }

    override fun pause() {
        exoPlayer.pause()
    }

    override fun stop() {
        activeSeekRequestId = 0L
        exoPlayer.stop()
    }

    override fun release() {
        activeSeekRequestId = 0L
        detachSurface()
        exoPlayer.removeListener(playerListener)
        exoPlayer.release()
    }

    override fun performEngineSeek(requestId: Long, positionMs: Long): Boolean {
        val state = exoPlayer.playbackState
        if (state == Player.STATE_IDLE) {
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "Media3 rejected seek: player is STATE_IDLE",
                details = mapOf("requestId" to requestId, "positionMs" to positionMs),
                isWarningOrError = true
            )
            return false
        }

        // Media3 may still accept a queued seek while buffering/preparing. Only reject
        // after READY when the prepared timeline explicitly reports no seekable window.
        if (state == Player.STATE_READY && !exoPlayer.isCurrentMediaItemSeekable) {
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "Media3 rejected seek: media item is unseekable and has no finite duration",
                details = mapOf("requestId" to requestId, "positionMs" to positionMs),
                isWarningOrError = true
            )
            return false
        }

        activeSeekRequestId = requestId
        val targetMs = positionMs.coerceAtLeast(0L)
        logger.log(
            category = DiagnosticCategory.SEEK,
            message = "Media3 dispatching seekTo",
            details = mapOf(
                "requestId" to requestId,
                "targetMs" to targetMs,
                "isCurrentMediaItemSeekable" to exoPlayer.isCurrentMediaItemSeekable,
                "exoDurationMs" to exoPlayer.duration
            )
        )
        exoPlayer.seekTo(targetMs)
        return true
    }

    override fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        exoPlayer.playbackParameters = PlaybackParameters(clamped)
    }

    override fun selectAudioTrack(track: AudioTrackInfo) {
        val groups = exoPlayer.currentTracks.groups
        if (track.groupIndex in 0 until groups.size) {
            val group = groups[track.groupIndex]
            val override = TrackSelectionOverride(group.mediaTrackGroup, track.trackIndex)
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setOverrideForType(override)
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                .build()
        } else if (track.language != null) {
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setPreferredAudioLanguage(track.language)
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                .build()
        }
    }

    override fun selectSubtitleTrack(track: SubtitleTrackInfo) {
        if (track.id == "off") {
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            return
        }

        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .apply {
                val groups = exoPlayer.currentTracks.groups
                if (track.groupIndex in 0 until groups.size && track.trackIndex >= 0) {
                    val group = groups[track.groupIndex]
                    setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, track.trackIndex))
                } else if (track.language != null) {
                    setPreferredTextLanguage(track.language)
                }
            }
            .build()
    }

    override fun loadExternalSubtitle(uri: Uri) {
        val video = currentVideo ?: return
        val name = uri.lastPathSegment ?: "External Subtitle"
        val mimeType = when {
            name.endsWith(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
            name.endsWith(".ass", ignoreCase = true) || name.endsWith(".ssa", ignoreCase = true) -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }

        val newSub = SubtitleTrackInfo(
            id = "ext_${externalSubtitles.size + 1}",
            name = name,
            language = "ext",
            uri = uri,
            mimeType = mimeType,
            isExternal = true,
            isSelected = true
        )
        externalSubtitles.add(newSub)

        val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val wasPlaying = exoPlayer.playWhenReady
        val rebuiltItem = buildMediaItem(video, externalSubtitles)

        exoPlayer.setMediaItem(rebuiltItem, currentPos)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = wasPlaying
    }

    override fun captureTimelineSnapshot(): EngineTimelineSnapshot {
        val rawDuration = exoPlayer.duration
        val engineDuration = if (rawDuration == C.TIME_UNSET || rawDuration <= 0L) {
            EngineTimelineSnapshot.TIME_UNSET
        } else {
            rawDuration
        }
        val state = exoPlayer.playbackState
        // Buffering is not a prepared timeline, and a finite metadata duration does not
        // prove that the actual container has a usable seek index.
        val isReady = state == Player.STATE_READY
        val metadataDur = currentVideo?.durationMs ?: 0L
        val isSeekable = exoPlayer.isCurrentMediaItemSeekable

        return EngineTimelineSnapshot(
            engineType = EngineType.MEDIA3,
            currentPositionMs = exoPlayer.currentPosition.coerceAtLeast(0L),
            bufferedPositionMs = exoPlayer.bufferedPosition.coerceAtLeast(0L),
            engineDurationMs = engineDuration,
            metadataDurationMs = metadataDur,
            isEngineSeekable = isSeekable,
            isTimelineReady = isReady,
            isMkvContainer = currentVideo?.isMkvContainer == true
        )
    }

    private fun buildMediaItem(video: VideoItem, subtitles: List<SubtitleTrackInfo>): MediaItem {
        val subConfigs = subtitles.mapNotNull { sub ->
            val subUri = sub.uri ?: return@mapNotNull null
            MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType(sub.mimeType ?: MimeTypes.APPLICATION_SUBRIP)
                .setLanguage(sub.language ?: "en")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .setLabel(sub.name)
                .build()
        }

        val metadata = MediaMetadata.Builder()
            .setTitle(video.displayName)
            .setDisplayTitle(video.displayName)
            .build()

        return MediaItem.Builder()
            .setMediaId(video.id.toString())
            .setUri(video.uri)
            .setMediaMetadata(metadata)
            .setSubtitleConfigurations(subConfigs)
            .build()
    }

    private fun extractTracks(tracks: Tracks): Pair<List<AudioTrackInfo>, List<SubtitleTrackInfo>> {
        val audioList = mutableListOf<AudioTrackInfo>()
        val subtitleList = mutableListOf<SubtitleTrackInfo>()

        var anyTextSelected = false
        for (groupIdx in 0 until tracks.groups.size) {
            val group = tracks.groups[groupIdx]
            when (group.type) {
                C.TRACK_TYPE_AUDIO -> {
                    for (trackIdx in 0 until group.length) {
                        val format = group.getTrackFormat(trackIdx)
                        val isSelected = group.isTrackSelected(trackIdx)
                        val lang = format.language ?: "und"
                        val label = format.label ?: "Audio Track ${audioList.size + 1} (${lang.uppercase()})"
                        audioList.add(
                            AudioTrackInfo(
                                id = "audio_${groupIdx}_$trackIdx",
                                name = label,
                                language = format.language,
                                codec = format.sampleMimeType,
                                channels = if (format.channelCount != C.INDEX_UNSET) format.channelCount else 2,
                                sampleRate = if (format.sampleRate != C.INDEX_UNSET) format.sampleRate else 48000,
                                isSelected = isSelected,
                                groupIndex = groupIdx,
                                trackIndex = trackIdx
                            )
                        )
                    }
                }
                C.TRACK_TYPE_TEXT -> {
                    for (trackIdx in 0 until group.length) {
                        val format = group.getTrackFormat(trackIdx)
                        val isSelected = group.isTrackSelected(trackIdx)
                        if (isSelected) anyTextSelected = true
                        val lang = format.language ?: "und"
                        val label = format.label ?: "Subtitle ${subtitleList.size + 1} (${lang.uppercase()})"
                        subtitleList.add(
                            SubtitleTrackInfo(
                                id = "sub_${groupIdx}_$trackIdx",
                                name = label,
                                language = format.language,
                                isExternal = false,
                                isSelected = isSelected,
                                groupIndex = groupIdx,
                                trackIndex = trackIdx
                            )
                        )
                    }
                }
            }
        }

        val finalSubtitles = buildList {
            add(
                SubtitleTrackInfo(
                    id = "off",
                    name = "Disable Subtitles",
                    isSelected = !anyTextSelected
                )
            )
            addAll(subtitleList)
        }

        return audioList to finalSubtitles
    }

    private fun mapState(exoState: Int): Int = when (exoState) {
        Player.STATE_IDLE -> PlaybackEngine.STATE_IDLE
        Player.STATE_BUFFERING -> PlaybackEngine.STATE_BUFFERING
        Player.STATE_READY -> PlaybackEngine.STATE_READY
        Player.STATE_ENDED -> PlaybackEngine.STATE_ENDED
        else -> PlaybackEngine.STATE_IDLE
    }
}
