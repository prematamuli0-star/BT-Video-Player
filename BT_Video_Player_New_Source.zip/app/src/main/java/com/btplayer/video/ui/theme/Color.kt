package com.btplayer.video.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF0D0E12)
val DarkSurface = Color(0xFF16181F)
val DarkCard = Color(0xFF1E222D)
val DarkCardBorder = Color(0xFF2E3344)

val CyanAccent = Color(0xFF00E5FF)
val BlueAccent = Color(0xFF2979FF)
val OrangeAccent = Color(0xFFFF9100)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val OverlayBlack = Color(0xCC000000)
val OverlayBlackLight = Color(0x66000000)
val GestureHUDBackground = Color(0xD910121A)
