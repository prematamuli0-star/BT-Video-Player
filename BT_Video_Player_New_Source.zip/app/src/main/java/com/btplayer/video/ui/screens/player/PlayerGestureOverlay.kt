package com.btplayer.video.ui.screens.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btplayer.video.domain.model.VideoItem
import com.btplayer.video.ui.icons.BTPlayerIcons
import com.btplayer.video.ui.theme.BlueAccent
import com.btplayer.video.ui.theme.CyanAccent
import com.btplayer.video.ui.theme.GestureHUDBackground
import com.btplayer.video.ui.theme.OrangeAccent
import com.btplayer.video.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.abs

@Composable
fun BoxScope.PlayerGestureHudOverlay(
    brightnessLevel: Float?,
    volumeLevel: Int?,
    maxVolume: Int,
    swipeSeekDeltaMs: Long?,
    displayedPositionMs: Long,
    effectiveDurationMs: Long,
    doubleTapFeedback: String?,
    unseekableWarning: String?
) {
    // 1. LEFT EDGE FLOATING BRIGHTNESS BAR
    if (brightnessLevel != null) {
        val brightPercent = (brightnessLevel * 100f).toInt().coerceIn(0, 100)
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 24.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(GestureHUDBackground)
                .padding(vertical = 18.dp, horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = BTPlayerIcons.BrightnessMedium,
                    contentDescription = "Brightness",
                    tint = CyanAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .width(8.dp)
                        .height(100.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF2E3344))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(brightnessLevel.coerceIn(0f, 1f))
                            .align(Alignment.BottomCenter)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Brush.verticalGradient(listOf(CyanAccent, BlueAccent)))
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "$brightPercent%",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }

    // 2. RIGHT EDGE FLOATING VOLUME BAR
    if (volumeLevel != null) {
        val safeMax = maxVolume.coerceAtLeast(1)
        val volFraction = (volumeLevel.toFloat() / safeMax.toFloat()).coerceIn(0f, 1f)
        val volPercent = (volFraction * 100f).toInt().coerceIn(0, 100)
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(GestureHUDBackground)
                .padding(vertical = 18.dp, horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (volumeLevel == 0) {
                        BTPlayerIcons.VolumeOff
                    } else {
                        BTPlayerIcons.VolumeUp
                    },
                    contentDescription = "Volume",
                    tint = CyanAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .width(8.dp)
                        .height(100.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF2E3344))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(volFraction)
                            .align(Alignment.BottomCenter)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Brush.verticalGradient(listOf(CyanAccent, BlueAccent)))
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "$volPercent%",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }

    // 3. CENTER CONTINUOUS SEEK PREVIEW OVERLAY
    if (swipeSeekDeltaMs != null) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .clip(RoundedCornerShape(16.dp))
                .background(GestureHUDBackground)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (swipeSeekDeltaMs >= 0L) BTPlayerIcons.FastForward else BTPlayerIcons.FastRewind,
                        contentDescription = null,
                        tint = if (swipeSeekDeltaMs >= 0L) CyanAccent else OrangeAccent,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatSignedDeltaMs(swipeSeekDeltaMs),
                        color = if (swipeSeekDeltaMs >= 0L) CyanAccent else OrangeAccent,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 24.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${VideoItem.formatTimestampMs(displayedPositionMs)} / ${VideoItem.formatTimestampMs(effectiveDurationMs)}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = {
                        if (effectiveDurationMs > 0L) {
                            (displayedPositionMs.toFloat() / effectiveDurationMs.toFloat()).coerceIn(0f, 1f)
                        } else {
                            0f
                        }
                    },
                    modifier = Modifier
                        .width(160.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = CyanAccent,
                    trackColor = Color.DarkGray
                )
            }
        }
    }

    // 4. DOUBLE-TAP FEEDBACK OVERLAY (-10s / +10s)
    if (doubleTapFeedback != null && swipeSeekDeltaMs == null) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .clip(CircleShape)
                .background(Color(0x99000000))
                .padding(20.dp)
        ) {
            Text(
                text = doubleTapFeedback,
                color = CyanAccent,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp
            )
        }
    }

    // 5. UNSEEKABLE STREAM / CORRUPTED MKV INDEX NOTICE
    if (unseekableWarning != null && swipeSeekDeltaMs == null && doubleTapFeedback == null) {
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 76.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(GestureHUDBackground)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = unseekableWarning,
                color = OrangeAccent,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )
        }
    }
}

fun formatSignedDeltaMs(deltaMs: Long): String {
    val totalSeconds = (abs(deltaMs) / 1000L).coerceAtLeast(0L)
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    val sign = if (deltaMs >= 0L) "+" else "-"
    return String.format(Locale.US, "%s%02d:%02d", sign, minutes, seconds)
}
