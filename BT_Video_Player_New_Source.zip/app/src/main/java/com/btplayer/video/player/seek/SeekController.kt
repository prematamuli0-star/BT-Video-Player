package com.btplayer.video.player.seek

import com.btplayer.video.core.logging.DiagnosticCategory
import com.btplayer.video.core.logging.PlayerDiagnosticLogger
import com.btplayer.video.domain.model.EngineTimelineSnapshot
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.SeekCapability
import com.btplayer.video.domain.model.SeekSource
import com.btplayer.video.domain.model.SeekState
import com.btplayer.video.domain.model.SeekSubmissionResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max
import kotlin.math.min

/**
 * Centralized SeekController for BT Video Player 2.0.
 *
 * All double-tap (+10s / -10s), horizontal swipe gestures, seek-bar scrubbing,
 * initial resume positioning, and engine-fallback position restorations MUST go through
 * this controller.
 *
 * Key responsibilities:
 * 1. Single source of truth for [displayedPositionMs], [effectiveDurationMs], [seekState],
 *    and [seekCapability].
 * 2. Coalescing & accumulation of rapid double-tap / relative seek requests so consecutive
 *    taps build on the in-flight target position rather than the stale decoder position.
 * 3. Decoupled scrubbing preview state for SeekBar and Horizontal Swipe so dragging never
 *    floods the MKV extractor with intermediate seeks or snaps back on polling ticks.
 * 4. Strict duration and seekability checks: never assumes every MKV is seekable, and never
 *    clamps a seek to 00:00 because of C.TIME_UNSET.
 * 5. Monotonic [requestId] token validation so delayed/stale callbacks from previous seeks
 *    or previous engines are safely ignored.
 * 6. Asynchronous timeout watchdog (`seekTimeoutMs`) that detects hung MKV seeks and notifies
 *    [onSeekTimeoutOrFailure] so `PlayerController` can switch engines or recover cleanly.
 */
class SeekController(
    private val scope: CoroutineScope,
    private val logger: PlayerDiagnosticLogger,
    private val elapsedClockMs: () -> Long = { System.currentTimeMillis() },
    private val doubleTapCoalesceWindowMs: Long = 120L,
    private val seekTimeoutMs: Long = 3_500L,
    private val dispatchSeekToActiveEngine: (requestId: Long, targetPositionMs: Long) -> Boolean,
    private val onSeekTimeoutOrFailure: (requestId: Long, targetPositionMs: Long, reason: String) -> Unit = { _, _, _ -> }
) {
    private val requestIdGenerator = AtomicLong(1000L)

    private val _timelineSnapshot = MutableStateFlow(EngineTimelineSnapshot())
    val timelineSnapshot: StateFlow<EngineTimelineSnapshot> = _timelineSnapshot.asStateFlow()

    private val _seekState = MutableStateFlow<SeekState>(SeekState.Idle)
    val seekState: StateFlow<SeekState> = _seekState.asStateFlow()

    private val _displayedPositionMs = MutableStateFlow(0L)
    val displayedPositionMs: StateFlow<Long> = _displayedPositionMs.asStateFlow()

    private val _effectiveDurationMs = MutableStateFlow(0L)
    val effectiveDurationMs: StateFlow<Long> = _effectiveDurationMs.asStateFlow()

    private val _seekCapability = MutableStateFlow(SeekCapability.UNSEEKABLE)
    val seekCapability: StateFlow<SeekCapability> = _seekCapability.asStateFlow()

    private var coalesceJob: Job? = null
    private var watchdogJob: Job? = null

    /**
     * Resets the seek state machine when loading a new video or switching playlist tracks
     * (Next / Previous), ensuring track navigation is 100% independent of any prior seek state.
     */
    @Synchronized
    fun resetForNewMedia(metadataDurationMs: Long, isMkvContainer: Boolean, initialResumeMs: Long = 0L) {
        cancelTimers()
        // Advance generator so any late callbacks from previous track are rejected
        requestIdGenerator.addAndGet(100L)

        val safeDuration = metadataDurationMs.coerceAtLeast(0L)
        val safeResume = if (safeDuration > 0L) {
            initialResumeMs.coerceIn(0L, safeDuration)
        } else {
            initialResumeMs.coerceAtLeast(0L)
        }

        val initialSnapshot = EngineTimelineSnapshot(
            engineType = _timelineSnapshot.value.engineType,
            currentPositionMs = safeResume,
            bufferedPositionMs = safeResume,
            engineDurationMs = EngineTimelineSnapshot.TIME_UNSET,
            metadataDurationMs = safeDuration,
            isEngineSeekable = false,
            isTimelineReady = false,
            isMkvContainer = isMkvContainer
        )

        _timelineSnapshot.value = initialSnapshot
        _effectiveDurationMs.value = initialSnapshot.resolvedDurationMs
        _seekCapability.value = initialSnapshot.seekCapability
        _displayedPositionMs.value = safeResume
        _seekState.value = SeekState.Idle

        logger.log(
            category = DiagnosticCategory.SEEK,
            message = "SeekController reset for new media",
            details = mapOf(
                "metadataDurationMs" to safeDuration,
                "isMkvContainer" to isMkvContainer,
                "initialResumeMs" to safeResume,
                "capability" to initialSnapshot.seekCapability.name
            )
        )
    }

    /**
     * Updates the controller with a fresh timeline/position snapshot from the active engine.
     * Critically blocks stale engine position updates while the user is scrubbing or while
     * an asynchronous seek is still pending.
     */
    @Synchronized
    fun onEngineTimelineUpdated(snapshot: EngineTimelineSnapshot) {
        _timelineSnapshot.value = snapshot
        val resolvedDuration = snapshot.resolvedDurationMs
        _effectiveDurationMs.value = resolvedDuration
        val capability = snapshot.seekCapability
        _seekCapability.value = capability

        when (val state = _seekState.value) {
            is SeekState.Scrubbing -> {
                // Keep displayedPositionMs locked to the user's scrub preview; clamp if duration just became known
                if (resolvedDuration > 0L && state.previewPositionMs > resolvedDuration) {
                    val clampedPreview = state.previewPositionMs.coerceIn(0L, resolvedDuration)
                    _seekState.value = state.copy(
                        previewPositionMs = clampedPreview,
                        deltaMs = clampedPreview - state.startPositionMs
                    )
                    _displayedPositionMs.value = clampedPreview
                }
            }

            is SeekState.PendingSeek -> {
                // If timeline became ready and revealed the media is strictly unseekable, abort pending seek
                if (capability == SeekCapability.UNSEEKABLE && snapshot.isTimelineReady) {
                    cancelTimers()
                    val reason = "Timeline ready but media reported unseekable (isMkv=${snapshot.isMkvContainer})"
                    _seekState.value = SeekState.Unseekable(reason)
                    _displayedPositionMs.value = snapshot.currentPositionMs.coerceAtLeast(0L)
                    logger.log(
                        category = DiagnosticCategory.SEEK,
                        message = "Aborted pending seek because prepared timeline is unseekable",
                        details = mapOf("requestId" to state.requestId, "reason" to reason),
                        isWarningOrError = true
                    )
                    return
                }
                // Otherwise, DO NOT overwrite displayedPositionMs with stale pre-seek engine position!
                _displayedPositionMs.value = state.targetPositionMs
            }

            is SeekState.Unseekable -> {
                // Recover to Idle if engine timeline subsequently resolved seekability (e.g. cues finished loading)
                if (capability != SeekCapability.UNSEEKABLE) {
                    _seekState.value = SeekState.Idle
                }
                _displayedPositionMs.value = snapshot.currentPositionMs.coerceAtLeast(0L)
            }

            is SeekState.Idle -> {
                _displayedPositionMs.value = if (resolvedDuration > 0L) {
                    snapshot.currentPositionMs.coerceIn(0L, resolvedDuration)
                } else {
                    snapshot.currentPositionMs.coerceAtLeast(0L)
                }
            }
        }
    }

    /**
     * Submits a relative seek request (e.g. Double-Tap +10s / -10s).
     * Accumulates onto any active PendingSeek or Scrubbing target so rapid consecutive taps
     * never read a stale decoder timestamp.
     */
    @Synchronized
    fun seekRelative(
        deltaMs: Long,
        source: SeekSource = if (deltaMs >= 0L) SeekSource.DOUBLE_TAP_FORWARD else SeekSource.DOUBLE_TAP_BACKWARD
    ): SeekSubmissionResult {
        val validationError = validateSeekability(source)
        if (validationError != null) {
            return validationError
        }

        val currentState = _seekState.value
        val basePositionMs = when (currentState) {
            is SeekState.PendingSeek -> currentState.targetPositionMs
            is SeekState.Scrubbing -> currentState.previewPositionMs
            else -> _displayedPositionMs.value
        }
        val startOriginMs = when (currentState) {
            is SeekState.PendingSeek -> currentState.startPositionMs
            is SeekState.Scrubbing -> currentState.startPositionMs
            else -> _displayedPositionMs.value
        }

        val duration = _effectiveDurationMs.value
        val unclampedTarget = basePositionMs + deltaMs
        val targetPositionMs = clampPosition(unclampedTarget, duration)
        val totalAccumulatedDelta = targetPositionMs - startOriginMs

        val requestId = requestIdGenerator.incrementAndGet()
        val nowMs = elapsedClockMs()

        val pendingState = SeekState.PendingSeek(
            requestId = requestId,
            source = source,
            startPositionMs = startOriginMs,
            targetPositionMs = targetPositionMs,
            accumulatedDeltaMs = totalAccumulatedDelta,
            issuedAtElapsedMs = nowMs,
            dispatchedToEngine = false
        )
        _seekState.value = pendingState
        _displayedPositionMs.value = targetPositionMs

        logger.log(
            category = DiagnosticCategory.SEEK,
            message = "Relative seek queued",
            details = mapOf(
                "requestId" to requestId,
                "source" to source.name,
                "deltaMs" to deltaMs,
                "basePosMs" to basePositionMs,
                "targetPosMs" to targetPositionMs,
                "accumulatedDeltaMs" to totalAccumulatedDelta,
                "durationMs" to duration
            )
        )

        scheduleCoalescedDispatch(requestId, targetPositionMs)

        return SeekSubmissionResult.Accepted(
            requestId = requestId,
            targetPositionMs = targetPositionMs,
            accumulatedDeltaMs = totalAccumulatedDelta
        )
    }

    /**
     * Submits an immediate absolute seek request (e.g. programmatic jump or direct timestamp selection).
     */
    @Synchronized
    fun seekToAbsolute(
        positionMs: Long,
        source: SeekSource = SeekSource.PROGRAMMATIC
    ): SeekSubmissionResult {
        val validationError = validateSeekability(source)
        if (validationError != null) {
            return validationError
        }

        cancelTimers()
        val duration = _effectiveDurationMs.value
        val startOriginMs = _displayedPositionMs.value
        val targetPositionMs = clampPosition(positionMs, duration)
        val deltaMs = targetPositionMs - startOriginMs
        val requestId = requestIdGenerator.incrementAndGet()

        val pendingState = SeekState.PendingSeek(
            requestId = requestId,
            source = source,
            startPositionMs = startOriginMs,
            targetPositionMs = targetPositionMs,
            accumulatedDeltaMs = deltaMs,
            issuedAtElapsedMs = elapsedClockMs(),
            dispatchedToEngine = true
        )
        _seekState.value = pendingState
        _displayedPositionMs.value = targetPositionMs

        dispatchNow(requestId, targetPositionMs)

        return SeekSubmissionResult.Accepted(
            requestId = requestId,
            targetPositionMs = targetPositionMs,
            accumulatedDeltaMs = deltaMs
        )
    }

    /**
     * Begins or updates an interactive seek-bar scrub preview without dispatching intermediate
     * seeks to the underlying decoder.
     */
    @Synchronized
    fun updateSeekBarFraction(fraction: Float): SeekSubmissionResult {
        val validationError = validateSeekability(SeekSource.SEEK_BAR)
        if (validationError != null) {
            return validationError
        }

        val duration = _effectiveDurationMs.value
        val clampedFraction = fraction.coerceIn(0f, 1f)
        val previewMs = ((clampedFraction.toDouble()) * duration.toDouble()).toLong().coerceIn(0L, duration)

        val startPos = when (val s = _seekState.value) {
            is SeekState.Scrubbing -> s.startPositionMs
            is SeekState.PendingSeek -> s.targetPositionMs
            else -> _displayedPositionMs.value
        }
        val deltaMs = previewMs - startPos

        _seekState.value = SeekState.Scrubbing(
            source = SeekSource.SEEK_BAR,
            startPositionMs = startPos,
            previewPositionMs = previewMs,
            deltaMs = deltaMs
        )
        _displayedPositionMs.value = previewMs

        return SeekSubmissionResult.PreviewUpdated(
            previewPositionMs = previewMs,
            deltaMs = deltaMs
        )
    }

    /**
     * Begins or updates a horizontal swipe gesture seek preview.
     * Calculates a proportional scrub window (60s..300s) based on video duration.
     */
    @Synchronized
    fun updateHorizontalSwipe(
        totalDragPx: Float,
         gestureZoneWidthPx: Float
    ): SeekSubmissionResult {
        val validationError = validateSeekability(SeekSource.SWIPE_GESTURE)
        if (validationError != null) {
            return validationError
        }

        val duration = _effectiveDurationMs.value
        val startPos = when (val s = _seekState.value) {
            is SeekState.Scrubbing -> s.startPositionMs
            is SeekState.PendingSeek -> s.targetPositionMs
            else -> _displayedPositionMs.value
        }

        val scrubWindowMs = calculateSwipeWindowMs(duration)
        val safeWidth = gestureZoneWidthPx.coerceAtLeast(1f)
        val normalizedDrag = totalDragPx / safeWidth
        val rawDeltaMs = (normalizedDrag.toDouble() * scrubWindowMs.toDouble()).toLong()
        val previewMs = clampPosition(startPos + rawDeltaMs, duration)
        val effectiveDeltaMs = previewMs - startPos

        _seekState.value = SeekState.Scrubbing(
            source = SeekSource.SWIPE_GESTURE,
            startPositionMs = startPos,
            previewPositionMs = previewMs,
            deltaMs = effectiveDeltaMs
        )
        _displayedPositionMs.value = previewMs

        return SeekSubmissionResult.PreviewUpdated(
            previewPositionMs = previewMs,
            deltaMs = effectiveDeltaMs
        )
    }

    /**
     * Commits the current [SeekState.Scrubbing] preview position (when user releases the SeekBar
     * thumb or lifts their finger after a horizontal swipe).
     */
    @Synchronized
    fun commitScrub(): SeekSubmissionResult {
        val current = _seekState.value
        if (current !is SeekState.Scrubbing) {
            return SeekSubmissionResult.RejectedUnseekable("No active scrub session to commit")
        }

        val validationError = validateSeekability(current.source)
        if (validationError != null) {
            return validationError
        }

        cancelTimers()
        val duration = _effectiveDurationMs.value
        val targetMs = clampPosition(current.previewPositionMs, duration)
        val requestId = requestIdGenerator.incrementAndGet()

        val pendingState = SeekState.PendingSeek(
            requestId = requestId,
            source = current.source,
            startPositionMs = current.startPositionMs,
            targetPositionMs = targetMs,
            accumulatedDeltaMs = targetMs - current.startPositionMs,
            issuedAtElapsedMs = elapsedClockMs(),
            dispatchedToEngine = true
        )
        _seekState.value = pendingState
        _displayedPositionMs.value = targetMs

        logger.log(
            category = DiagnosticCategory.SEEK,
            message = "Scrub committed to engine",
            details = mapOf(
                "requestId" to requestId,
                "source" to current.source.name,
                "startPosMs" to current.startPositionMs,
                "targetPosMs" to targetMs,
                "deltaMs" to (targetMs - current.startPositionMs)
            )
        )

        dispatchNow(requestId, targetMs)

        return SeekSubmissionResult.Accepted(
            requestId = requestId,
            targetPositionMs = targetMs,
            accumulatedDeltaMs = targetMs - current.startPositionMs
        )
    }

    /**
     * Cancels an active scrub gesture without seeking, restoring the pre-scrub playback position.
     */
    @Synchronized
    fun cancelScrub() {
        val current = _seekState.value
        if (current is SeekState.Scrubbing) {
            _seekState.value = SeekState.Idle
            _displayedPositionMs.value = _timelineSnapshot.value.currentPositionMs.coerceAtLeast(0L)
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "Scrub gesture cancelled",
                details = mapOf("restoredPosMs" to _displayedPositionMs.value)
            )
        }
    }

    /**
     * Invoked when the active playback engine finishes seeking.
     * Validates [requestId] so delayed/stale callbacks from earlier seeks or old engines are ignored.
     */
    @Synchronized
    fun onEngineSeekCompleted(engineType: EngineType, requestId: Long, landedPositionMs: Long) {
        if (engineType != _timelineSnapshot.value.engineType) {
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "Ignored seek completion from inactive engine",
                details = mapOf("callbackEngine" to engineType.name, "activeEngine" to _timelineSnapshot.value.engineType.name)
            )
            return
        }
        val current = _seekState.value
        if (current !is SeekState.PendingSeek) {
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "Ignored seek completion callback while not in PendingSeek",
                details = mapOf(
                    "engine" to engineType.name,
                    "callbackRequestId" to requestId,
                    "landedPosMs" to landedPositionMs,
                    "currentState" to current::class.simpleName
                )
            )
            return
        }

        if (requestId != 0L && requestId != current.requestId) {
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = "Ignored stale seek completion callback with mismatched requestId",
                details = mapOf(
                    "engine" to engineType.name,
                    "callbackRequestId" to requestId,
                    "activeRequestId" to current.requestId,
                    "landedPosMs" to landedPositionMs
                ),
                isWarningOrError = true
            )
            return
        }

        cancelTimers()
        val duration = _effectiveDurationMs.value
        val settledPos = clampPosition(landedPositionMs, duration)
        _seekState.value = SeekState.Idle
        _displayedPositionMs.value = settledPos
        _timelineSnapshot.value = _timelineSnapshot.value.copy(currentPositionMs = settledPos)

        logger.log(
            category = DiagnosticCategory.SEEK,
            message = "Seek completed and settled",
            details = mapOf(
                "engine" to engineType.name,
                "requestId" to current.requestId,
                "targetPosMs" to current.targetPositionMs,
                "settledPosMs" to settledPos,
                "keyframeDriftMs" to (settledPos - current.targetPositionMs)
            )
        )
    }

    /**
     * Invoked when the active playback engine reports a seek failure.
     */
    @Synchronized
    fun onEngineSeekFailed(engineType: EngineType, requestId: Long, reason: String) {
        if (engineType != _timelineSnapshot.value.engineType) return
        val current = _seekState.value
        if (current !is SeekState.PendingSeek) return
        if (requestId != 0L && requestId != current.requestId) return

        cancelTimers()
        val targetToRecover = current.targetPositionMs
        _seekState.value = SeekState.Idle

        logger.log(
            category = DiagnosticCategory.SEEK,
            message = "Engine seek failed",
            details = mapOf(
                "engine" to engineType.name,
                "requestId" to current.requestId,
                "targetPosMs" to targetToRecover,
                "reason" to reason
            ),
            isWarningOrError = true
        )

        onSeekTimeoutOrFailure(current.requestId, targetToRecover, reason)
    }

    /**
     * Captures the desired playback position before switching from Media3 to LibVLC (or vice versa),
     * invalidating any in-flight requestId from the outgoing engine.
     */
    @Synchronized
    fun prepareForEngineSwitch(newEngineType: EngineType): Long {
        cancelTimers()
        val desiredPositionMs = when (val s = _seekState.value) {
            is SeekState.PendingSeek -> s.targetPositionMs
            is SeekState.Scrubbing -> s.previewPositionMs
            else -> _displayedPositionMs.value
        }

        // Bump requestId generator so any late callback from outgoing engine is rejected
        requestIdGenerator.addAndGet(50L)

        _timelineSnapshot.value = _timelineSnapshot.value.copy(
            engineType = newEngineType,
            currentPositionMs = desiredPositionMs
        )
        _seekState.value = SeekState.Idle
        _displayedPositionMs.value = desiredPositionMs

        logger.log(
            category = DiagnosticCategory.FALLBACK,
            message = "Prepared SeekController for engine switch",
            details = mapOf(
                "newEngine" to newEngineType.name,
                "preservedPositionMs" to desiredPositionMs
            )
        )
        return desiredPositionMs
    }

    /**
     * Issues a post-switch seek restoration on the newly activated fallback engine once its
     * timeline is ready.
     */
    @Synchronized
    fun restorePositionAfterEngineSwitch(targetPositionMs: Long): SeekSubmissionResult {
        return seekToAbsolute(targetPositionMs, SeekSource.ENGINE_SWITCH_RESTORE)
    }

    private fun validateSeekability(source: SeekSource): SeekSubmissionResult.RejectedUnseekable? {
        val snapshot = _timelineSnapshot.value
        val capability = snapshot.seekCapability

        if (!snapshot.hasValidDuration) {
            val reason = "Cannot seek ($source): media duration is unknown or unset"
            _seekState.value = SeekState.Unseekable(reason)
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = reason,
                details = mapOf(
                    "engineDurationMs" to snapshot.engineDurationMs,
                    "metadataDurationMs" to snapshot.metadataDurationMs,
                    "isMkv" to snapshot.isMkvContainer
                ),
                isWarningOrError = true
            )
            return SeekSubmissionResult.RejectedUnseekable(reason)
        }

        if (capability == SeekCapability.UNSEEKABLE) {
            val reason = "Cannot seek ($source): active engine (${snapshot.engineType}) reports media is not seekable"
            _seekState.value = SeekState.Unseekable(reason)
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = reason,
                details = mapOf(
                    "engine" to snapshot.engineType.name,
                    "isMkv" to snapshot.isMkvContainer,
                    "resolvedDurationMs" to snapshot.resolvedDurationMs
                ),
                isWarningOrError = true
            )
            return SeekSubmissionResult.RejectedUnseekable(reason)
        }

        return null
    }

    private fun scheduleCoalescedDispatch(requestId: Long, targetPositionMs: Long) {
        coalesceJob?.cancel()
        if (doubleTapCoalesceWindowMs <= 0L) {
            dispatchNow(requestId, targetPositionMs)
            return
        }

        coalesceJob = scope.launch {
            delay(doubleTapCoalesceWindowMs)
            synchronized(this@SeekController) {
                val state = _seekState.value
                if (state is SeekState.PendingSeek && state.requestId == requestId) {
                    _seekState.value = state.copy(dispatchedToEngine = true)
                    dispatchNow(requestId, state.targetPositionMs)
                }
            }
        }
    }

    private fun dispatchNow(requestId: Long, targetPositionMs: Long) {
        val accepted = dispatchSeekToActiveEngine(requestId, targetPositionMs)
        if (!accepted) {
            val reason = "Active engine rejected performEngineSeek(requestId=$requestId, target=$targetPositionMs)"
            _seekState.value = SeekState.Idle
            logger.log(
                category = DiagnosticCategory.SEEK,
                message = reason,
                isWarningOrError = true
            )
            onSeekTimeoutOrFailure(requestId, targetPositionMs, reason)
            return
        }

        startWatchdog(requestId, targetPositionMs)
    }

    private fun startWatchdog(requestId: Long, targetPositionMs: Long) {
        watchdogJob?.cancel()
        if (seekTimeoutMs <= 0L) return

        watchdogJob = scope.launch {
            delay(seekTimeoutMs)
            var timedOut = false
            synchronized(this@SeekController) {
                val state = _seekState.value
                if (state is SeekState.PendingSeek && state.requestId == requestId) {
                    _seekState.value = SeekState.Idle
                    timedOut = true
                    logger.log(
                        category = DiagnosticCategory.SEEK,
                        message = "Seek watchdog timed out waiting for engine completion",
                        details = mapOf(
                            "requestId" to requestId,
                            "targetPosMs" to targetPositionMs,
                            "timeoutMs" to seekTimeoutMs
                        ),
                        isWarningOrError = true
                    )
                }
            }
            if (timedOut) {
                onSeekTimeoutOrFailure(
                    requestId,
                    targetPositionMs,
                    "Seek timed out after ${seekTimeoutMs}ms"
                )
            }
        }
    }

    private fun cancelTimers() {
        coalesceJob?.cancel()
        coalesceJob = null
        watchdogJob?.cancel()
        watchdogJob = null
    }

    companion object {
        fun clampPosition(targetMs: Long, durationMs: Long): Long {
            return if (durationMs > 0L) {
                targetMs.coerceIn(0L, durationMs)
            } else {
                targetMs.coerceAtLeast(0L)
            }
        }

        fun calculateSwipeWindowMs(durationMs: Long): Long {
            return if (durationMs > 0L) {
                min(max(60_000L, durationMs / 10L), 300_000L)
            } else {
                120_000L
            }
        }
    }
}
