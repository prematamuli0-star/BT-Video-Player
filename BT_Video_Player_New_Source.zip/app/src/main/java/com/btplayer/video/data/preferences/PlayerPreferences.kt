package com.btplayer.video.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.ResizeMode

class PlayerPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isFavorite(videoId: Long): Boolean {
        val set = prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
        return set.contains(videoId.toString())
    }

    fun toggleFavorite(videoId: Long): Boolean {
        val current = prefs.getStringSet(KEY_FAVORITES, emptySet())?.toMutableSet() ?: mutableSetOf()
        val key = videoId.toString()
        val added = if (current.contains(key)) {
            current.remove(key)
            false
        } else {
            current.add(key)
            true
        }
        prefs.edit().putStringSet(KEY_FAVORITES, current).apply()
        return added
    }

    fun saveLastPosition(videoId: Long, positionMs: Long) {
        prefs.edit()
            .putLong("$KEY_POS_PREFIX$videoId", positionMs.coerceAtLeast(0L))
            .putLong("$KEY_HISTORY_TS_PREFIX$videoId", System.currentTimeMillis())
            .apply()
    }

    fun getLastPosition(videoId: Long): Long {
        return prefs.getLong("$KEY_POS_PREFIX$videoId", 0L).coerceAtLeast(0L)
    }

    fun savePlaybackSpeed(speed: Float) {
        prefs.edit().putFloat(KEY_PLAYBACK_SPEED, speed.coerceIn(0.5f, 2.0f)).apply()
    }

    fun getPlaybackSpeed(): Float {
        return prefs.getFloat(KEY_PLAYBACK_SPEED, 1.0f).coerceIn(0.5f, 2.0f)
    }

    fun savePreferredResizeMode(mode: ResizeMode) {
        prefs.edit().putString(KEY_RESIZE_MODE, mode.name).apply()
    }

    fun getPreferredResizeMode(): ResizeMode {
        val raw = prefs.getString(KEY_RESIZE_MODE, ResizeMode.FIT.name) ?: ResizeMode.FIT.name
        return ResizeMode.entries.firstOrNull { it.name == raw } ?: ResizeMode.FIT
    }

    fun savePreferredEngine(engineType: EngineType) {
        prefs.edit().putString(KEY_PREFERRED_ENGINE, engineType.name).apply()
    }

    fun getPreferredEngine(): EngineType {
        val raw = prefs.getString(KEY_PREFERRED_ENGINE, EngineType.MEDIA3.name) ?: EngineType.MEDIA3.name
        return EngineType.entries.firstOrNull { it.name == raw } ?: EngineType.MEDIA3
    }

    fun saveUmpConsentCompleted(completed: Boolean) {
        prefs.edit().putBoolean(KEY_UMP_CONSENT, completed).apply()
    }

    fun isUmpConsentCompleted(): Boolean {
        return prefs.getBoolean(KEY_UMP_CONSENT, false)
    }

    companion object {
        private const val PREFS_NAME = "bt_video_player_v2_prefs"
        private const val KEY_FAVORITES = "favorite_video_ids"
        private const val KEY_POS_PREFIX = "resume_pos_"
        private const val KEY_HISTORY_TS_PREFIX = "history_ts_"
        private const val KEY_PLAYBACK_SPEED = "playback_speed"
        private const val KEY_RESIZE_MODE = "resize_mode"
        private const val KEY_PREFERRED_ENGINE = "preferred_engine"
        private const val KEY_UMP_CONSENT = "ump_consent_completed"
    }
}
