package com.btplayer.video

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.btplayer.video.ads.ConsentAndAdsManager
import com.btplayer.video.ads.UmpConsentDialogHost
import com.btplayer.video.core.logging.PlayerDiagnosticLogger
import com.btplayer.video.data.preferences.PlayerPreferences
import com.btplayer.video.data.repository.MediaStoreVideoRepository
import com.btplayer.video.data.repository.SafVideoResolver
import com.btplayer.video.domain.model.FolderItem
import com.btplayer.video.domain.model.VideoItem
import com.btplayer.video.player.controller.PlayerController
import com.btplayer.video.player.engine.Media3PlaybackEngine
import com.btplayer.video.player.engine.VlcPlaybackEngine
import com.btplayer.video.ui.screens.home.HomeScreen
import com.btplayer.video.ui.screens.player.PlayerScreen
import com.btplayer.video.ui.theme.BTVideoPlayerTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var preferences: PlayerPreferences
    private lateinit var videoRepository: MediaStoreVideoRepository
    private lateinit var safVideoResolver: SafVideoResolver
    private lateinit var consentAndAdsManager: ConsentAndAdsManager
    private lateinit var playerController: PlayerController

    private val videosState = MutableStateFlow<List<VideoItem>>(emptyList())
    private val foldersState = MutableStateFlow<List<FolderItem>>(emptyList())
    private val isFullScreenPlayerOpen = MutableStateFlow(false)

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.any { it }) {
            scanMediaLibrary()
        }
    }

    private val safDocumentPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            openExternalOrSafUri(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val diagnosticLogger = PlayerDiagnosticLogger(enableLogcat = true)
        preferences = PlayerPreferences(this)
        videoRepository = MediaStoreVideoRepository(this, preferences)
        safVideoResolver = SafVideoResolver(this, preferences)
        consentAndAdsManager = ConsentAndAdsManager(this, preferences)

        // Single Media3 primary engine and optional LibVLC fallback engine owned by PlayerController
        val media3Engine = Media3PlaybackEngine(this, diagnosticLogger)
        val vlcEngine = VlcPlaybackEngine(this, diagnosticLogger)

        playerController = PlayerController(
            scope = lifecycleScope,
            primaryEngine = media3Engine,
            fallbackEngine = vlcEngine,
            preferences = preferences,
            logger = diagnosticLogger
        )

        setContent {
            BTVideoPlayerTheme {
                val videos by videosState.collectAsState()
                val folders by foldersState.collectAsState()
                val showPlayer by isFullScreenPlayerOpen.collectAsState()

                UmpConsentDialogHost(consentManager = consentAndAdsManager)

                if (showPlayer) {
                    PlayerScreen(
                        playerController = playerController,
                        isInPipMode = false,
                        onBackClick = {
                            playerController.persistCurrentProgress()
                            refreshResumePositionsInList()
                            isFullScreenPlayerOpen.value = false
                            showSystemUi()
                        },
                        onEnterPip = {
                            // System PiP is intentionally disabled; the app uses its in-app mini-player.
                        }
                    )
                } else {
                    HomeScreen(
                        videos = videos,
                        folders = folders,
                        playerController = playerController,
                        consentManager = consentAndAdsManager,
                        onVideoClick = { video, playlist ->
                            val activePlaylist = playlist.ifEmpty {
                                videos.ifEmpty { listOf(video) }
                            }
                            val index = activePlaylist.indexOfFirst { it.id == video.id }.coerceAtLeast(0)
                            playerController.loadPlaylist(activePlaylist, index, video.lastPositionMs)
                            isFullScreenPlayerOpen.value = true
                            hideSystemUi()
                        },
                        onResumeFullScreenPlayer = {
                            isFullScreenPlayerOpen.value = true
                            hideSystemUi()
                        },
                        onOpenSafVideoPicker = {
                            safDocumentPickerLauncher.launch(arrayOf("video/*"))
                        },
                        onToggleFavorite = { video ->
                            val isFav = videoRepository.toggleFavorite(video.id)
                            val updated = videosState.value.map {
                                if (it.id == video.id) it.copy(isFavorite = isFav) else it
                            }
                            videosState.value = updated
                            playerController.syncPlaylistItems(updated)
                        },
                        onRefresh = {
                            scanMediaLibrary()
                        }
                    )
                }
            }
        }

        consentAndAdsManager.requestConsentIfNeeded(this)
        checkAndRequestPermissions()
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val uri: Uri = intent?.data ?: return
        openExternalOrSafUri(uri)
    }

    private fun openExternalOrSafUri(uri: Uri) {
        lifecycleScope.launch {
            val resolvedVideo = safVideoResolver.resolveUri(uri)
            val combinedPlaylist = listOf(resolvedVideo) + videosState.value.filter { it.id != resolvedVideo.id }
            videosState.value = combinedPlaylist
            playerController.loadPlaylist(combinedPlaylist, 0, resolvedVideo.lastPositionMs)
            isFullScreenPlayerOpen.value = true
            hideSystemUi()
        }
    }

    private fun checkAndRequestPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
        }

        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (allGranted) {
            scanMediaLibrary()
        } else {
            storagePermissionLauncher.launch(permissions)
        }
    }

    private fun scanMediaLibrary() {
        lifecycleScope.launch {
            val scanned = videoRepository.scanAllVideos()
            videosState.value = scanned
            foldersState.value = videoRepository.groupFolders(scanned)
            if (scanned.isNotEmpty()) {
                playerController.syncPlaylistItems(scanned)
            }
        }
    }

    private fun refreshResumePositionsInList() {
        val current = playerController.currentVideo.value ?: return
        val savedPos = preferences.getLastPosition(current.id)
        videosState.value = videosState.value.map {
            if (it.id == current.id) it.copy(lastPositionMs = savedPos) else it
        }
    }

    private fun hideSystemUi() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemUi() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onPause() {
        super.onPause()
        playerController.persistCurrentProgress()
        playerController.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        playerController.release()
    }
}
