#!/usr/bin/env bash
set -euo pipefail

echo "Building BT Video Player debug APK..."
if [ -x ./gradlew ] && [ -f ./gradle/wrapper/gradle-wrapper.jar ]; then
  ./gradlew --no-daemon assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon assembleDebug
else
  echo "No usable Gradle wrapper or system Gradle found." >&2
  echo "Open the project in Android Studio and run Gradle Sync, then Build > Build APK(s)." >&2
  exit 1
fi

echo "Debug APK: app/build/outputs/apk/debug/app-debug.apk"
echo "For a signed release, use Android Studio > Build > Generate Signed Bundle / APK."
