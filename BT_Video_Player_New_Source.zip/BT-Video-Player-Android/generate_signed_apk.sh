#!/usr/bin/env bash
# ==============================================================================
# BT Video Player - Signed APK Build Automation Script
# ==============================================================================
set -e

KEYSTORE_FILE="bt_release.jks"
KEY_ALIAS="btkey"
STORE_PASS="btplayer123"
KEY_PASS="btplayer123"

echo "=========================================================="
echo "  BT Video Player - Signed Release APK Generator"
echo "=========================================================="

# Check for Java
if ! command -v keytool &> /dev/null; then
    echo "❌ Error: 'keytool' not found. Please install JDK 17+."
    exit 1
fi

# 1. Generate Keystore if not present
if [ ! -f "$KEYSTORE_FILE" ]; then
    echo "🔑 Generating release keystore: $KEYSTORE_FILE ..."
    keytool -genkeypair \
        -v \
        -keystore "$KEYSTORE_FILE" \
        -alias "$KEY_ALIAS" \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -storepass "$STORE_PASS" \
        -keypass "$KEY_PASS" \
        -dname "CN=BT Video Player, OU=Mobile, O=BT, L=Seoul, ST=Seoul, C=KR"
    echo "✅ Keystore created successfully."
else
    echo "ℹ️ Using existing keystore: $KEYSTORE_FILE"
fi

# 2. Build Release APK using Gradle
echo "📦 Building Release APK with Gradle..."
if [ -f "./gradlew" ]; then
    chmod +x ./gradlew
    ./gradlew assembleRelease \
        -Pandroid.injected.signing.store.file="$(pwd)/$KEYSTORE_FILE" \
        -Pandroid.injected.signing.store.password="$STORE_PASS" \
        -Pandroid.injected.signing.key.alias="$KEY_ALIAS" \
        -Pandroid.injected.signing.key.password="$KEY_PASS"
else
    echo "⚠️ gradlew wrapper not found, attempting to invoke system gradle..."
    gradle assembleRelease
fi

RELEASE_APK="app/build/outputs/apk/release/app-release.apk"
if [ -f "$RELEASE_APK" ]; then
    echo "=========================================================="
    echo "🎉 SUCCESS: Signed APK Generated at:"
    echo "   $RELEASE_APK"
    echo "=========================================================="
else
    echo "Build finished. Check app/build/outputs/apk/ for outputs."
fi
