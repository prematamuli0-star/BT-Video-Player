package com.bt.videoplayer.player

import androidx.media3.ui.AspectRatioFrameLayout

enum class ResizeMode(val label: String, val exoMode: Int) {
    FIT("Fit to Screen", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill (Crop)", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH("Stretch", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    FIXED_WIDTH("Fit Width", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
    FIXED_HEIGHT("Fit Height", AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT),
    ORIGINAL_100("100% Original", AspectRatioFrameLayout.RESIZE_MODE_FIT)
}
