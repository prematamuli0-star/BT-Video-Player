package com.bt.videoplayer.data.preferences

import android.content.Context
import android.content.SharedPreferences

class PlayerPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bt_player_preferences", Context.MODE_PRIVATE)

    fun isFavorite(videoId: Long): Boolean {
        val favorites = prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
        return favorites.contains(videoId.toString())
    }

    fun toggleFavorite(videoId: Long): Boolean {
        val current = prefs.getStringSet(KEY_FAVORITES, emptySet())?.toMutableSet() ?: mutableSetOf()
        val idStr = videoId.toString()
        val newState = if (current.contains(idStr)) {
            current.remove(idStr)
            false
        } else {
            current.add(idStr)
            true
        }
        prefs.edit().putStringSet(KEY_FAVORITES, current).apply()
        return newState
    }

    fun saveLastPosition(videoId: Long, positionMs: Long) {
        prefs.edit().putLong("pos_$videoId", positionMs).apply()
    }

    fun getLastPosition(videoId: Long): Long {
        return prefs.getLong("pos_$videoId", 0L)
    }

    fun savePlaybackSpeed(speed: Float) {
        prefs.edit().putFloat(KEY_PLAYBACK_SPEED, speed).apply()
    }

    fun getPlaybackSpeed(): Float {
        return prefs.getFloat(KEY_PLAYBACK_SPEED, 1.0f)
    }

    companion object {
        private const val KEY_FAVORITES = "user_favorite_video_ids"
        private const val KEY_PLAYBACK_SPEED = "user_playback_speed"
    }
}
