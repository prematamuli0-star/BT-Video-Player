package com.bt.videoplayer.data.model

data class AudioTrack(
    val id: String,
    val name: String,
    val language: String? = null,
    val channels: Int = 2,
    val sampleRate: Int = 44100,
    val isSelected: Boolean = false,
    val groupIndex: Int = -1,
    val trackIndex: Int = -1
)
