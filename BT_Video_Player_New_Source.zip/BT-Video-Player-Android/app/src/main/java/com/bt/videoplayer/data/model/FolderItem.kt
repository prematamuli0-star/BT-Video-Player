package com.bt.videoplayer.data.model

data class FolderItem(
    val name: String,
    val path: String,
    val videoCount: Int,
    val totalSizeBytes: Long,
    val latestVideoDate: Long
)
