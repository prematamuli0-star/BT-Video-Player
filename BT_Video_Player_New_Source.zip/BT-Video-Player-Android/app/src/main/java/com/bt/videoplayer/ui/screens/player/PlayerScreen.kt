package com.bt.videoplayer.ui.screens.player

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.bt.videoplayer.data.model.SubtitleTrack
import com.bt.videoplayer.player.BTPlayerManager
import com.bt.videoplayer.player.ResizeMode
import com.bt.videoplayer.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    playerManager: BTPlayerManager,
    isInPipMode: Boolean,
    onBackClick: () -> Unit,
    onEnterPip: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current

    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentPosition by playerManager.currentPositionMs.collectAsState()
    val duration by playerManager.durationMs.collectAsState()
    val bufferedPosition by playerManager.bufferedPositionMs.collectAsState()
    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val resizeMode by playerManager.resizeMode.collectAsState()
    val currentVideo by playerManager.currentVideo.collectAsState()
    val availableSubtitles by playerManager.availableSubtitles.collectAsState()

    var areControlsVisible by remember { mutableStateOf(true) }
    var isControlsLocked by remember { mutableStateOf(false) }

    // Dialog states
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var showAspectDialog by remember { mutableStateOf(false) }

    // Gesture feedback HUD states
    var volumeLevel by remember { mutableStateOf<Int?>(null) }
    var brightnessLevel by remember { mutableStateOf<Float?>(null) }
    var doubleTapFeedback by remember { mutableStateOf<String?>(null) }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    // External Subtitle Picker
    val subtitleFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            playerManager.loadExternalSubtitle(uri)
        }
    }

    // Timer to update playback position
    LaunchedEffect(isPlaying) {
        while (true) {
            playerManager.updatePosition()
            delay(500)
        }
    }

    // Auto-hide controls after 3.5 seconds
    LaunchedEffect(areControlsVisible, isPlaying) {
        if (areControlsVisible && isPlaying && !isControlsLocked) {
            delay(3500)
            areControlsVisible = false
        }
    }

    // Clear gesture feedback HUDs after 1 second
    LaunchedEffect(volumeLevel, brightnessLevel, doubleTapFeedback) {
        if (volumeLevel != null || brightnessLevel != null || doubleTapFeedback != null) {
            delay(1200)
            volumeLevel = null
            brightnessLevel = null
            doubleTapFeedback = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isControlsLocked) {
                detectTapGestures(
                    onTap = {
                        if (isControlsLocked) {
                            // Only allow unlocking
                            areControlsVisible = true
                        } else {
                            areControlsVisible = !areControlsVisible
                        }
                    },
                    onDoubleTap = { offset ->
                        if (!isControlsLocked) {
                            val screenWidth = size.width
                            if (offset.x < screenWidth * 0.4f) {
                                // Rewind 10s
                                playerManager.seekTo(currentPosition - 10000)
                                doubleTapFeedback = "-10s"
                            } else if (offset.x > screenWidth * 0.6f) {
                                // Fast Forward 10s
                                playerManager.seekTo(currentPosition + 10000)
                                doubleTapFeedback = "+10s"
                            } else {
                                playerManager.togglePlayPause()
                            }
                        }
                    }
                )
            }
            .pointerInput(isControlsLocked) {
                if (!isControlsLocked) {
                    detectVerticalDragGestures(
                        onDragStart = {},
                        onDragEnd = {},
                        onDragCancel = {},
                        onVerticalDrag = { change, dragAmount ->
                            val screenWidth = size.width
                            val xPos = change.position.x
                            val delta = -dragAmount / 400f

                            if (xPos < screenWidth * 0.5f) {
                                // Left side: Brightness
                                activity?.window?.let { window ->
                                    val lp = window.attributes
                                    val currentBrightness = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                                    val newBrightness = (currentBrightness + delta).coerceIn(0.01f, 1.0f)
                                    lp.screenBrightness = newBrightness
                                    window.attributes = lp
                                    brightnessLevel = newBrightness
                                }
                            } else {
                                // Right side: Volume
                                val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                val step = if (dragAmount < 0) 1 else -1
                                val newVol = (currentVol + step).coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                volumeLevel = newVol
                            }
                        }
                    )
                }
            }
    ) {
        // ExoPlayer View
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = playerManager.exoPlayer
                    useController = false
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    this.setResizeMode(playerManager.resizeMode.value.exoMode)
                }
            },
            update = { playerView ->
                playerView.resizeMode = resizeMode.exoMode
            },
            modifier = Modifier.fillMaxSize()
        )

        // Gesture feedback indicators (HUD)
        if (volumeLevel != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(GestureHUDBackground)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = if (volumeLevel == 0) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Volume",
                        tint = CyanAccent,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${((volumeLevel!!.toFloat() / maxVolume) * 100).toInt()}%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        if (brightnessLevel != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(GestureHUDBackground)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.BrightnessMedium,
                        contentDescription = "Brightness",
                        tint = CyanAccent,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${(brightnessLevel!! * 100).toInt()}%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        if (doubleTapFeedback != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(OverlayBlack)
                    .padding(20.dp)
            ) {
                Text(
                    text = doubleTapFeedback ?: "",
                    color = CyanAccent,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            }
        }

        // Overlay Controls (only visible when not in PiP mode)
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = areControlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(OverlayBlackLight)
                ) {
                    if (isControlsLocked) {
                        // Show ONLY the unlock button when screen is locked
                        IconButton(
                            onClick = {
                                isControlsLocked = false
                            },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(24.dp)
                                .clip(CircleShape)
                                .background(OverlayBlack)
                                .size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Unlock Controls",
                                tint = CyanAccent
                            )
                        }
                    } else {
                        // Top Toolbar
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                .background(OverlayBlack)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .statusBarsPadding(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onBackClick) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = currentVideo?.displayName ?: "Playing Video",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${currentVideo?.resolutionLabel ?: "HD"} • ${playbackSpeed}x",
                                    color = CyanAccent,
                                    fontSize = 11.sp
                                )
                            }

                            // Subtitle Track Button
                            IconButton(onClick = { showSubtitleDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Subtitles,
                                    contentDescription = "Subtitles",
                                    tint = TextPrimary
                                )
                            }

                            // Speed Selector Button
                            IconButton(onClick = { showSpeedDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = "Speed",
                                    tint = TextPrimary
                                )
                            }

                            // Aspect Ratio Mode Switcher
                            IconButton(onClick = { showAspectDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.AspectRatio,
                                    contentDescription = "Aspect Ratio",
                                    tint = TextPrimary
                                )
                            }

                            // Picture-in-Picture Button
                            IconButton(onClick = onEnterPip) {
                                Icon(
                                    imageVector = Icons.Default.PictureInPictureAlt,
                                    contentDescription = "Picture-in-Picture",
                                    tint = CyanAccent
                                )
                            }

                            // Screen Lock Button
                            IconButton(onClick = { isControlsLocked = true }) {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = "Lock Screen",
                                    tint = TextPrimary
                                )
                            }
                        }

                        // Bottom Toolbar & Scrub Bar
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(OverlayBlack)
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .navigationBarsPadding()
                        ) {
                            // Time codes
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = formatTime(currentPosition),
                                    color = CyanAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = formatTime(duration),
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }

                            // Scrubber / Seek Bar
                            Slider(
                                value = if (duration > 0) (currentPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                                onValueChange = { fraction ->
                                    val targetMs = (fraction * duration).toLong()
                                    playerManager.seekTo(targetMs)
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = CyanAccent,
                                    activeTrackColor = CyanAccent,
                                    inactiveTrackColor = Color.DarkGray
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Controls Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Rewind 5s
                                IconButton(onClick = { playerManager.rewind5Seconds() }) {
                                    Icon(
                                        imageVector = Icons.Default.Replay5,
                                        contentDescription = "Rewind 5s",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                // Previous Video
                                IconButton(onClick = { playerManager.playPrevious() }) {
                                    Icon(
                                        imageVector = Icons.Default.SkipPrevious,
                                        contentDescription = "Previous Video",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }

                                // Play / Pause
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(CyanAccent)
                                        .clickable { playerManager.togglePlayPause() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = DarkBg,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                // Next Video
                                IconButton(onClick = { playerManager.playNext() }) {
                                    Icon(
                                        imageVector = Icons.Default.SkipNext,
                                        contentDescription = "Next Video",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }

                                // Forward 15s
                                IconButton(onClick = { playerManager.forward15Seconds() }) {
                                    Icon(
                                        imageVector = Icons.Default.FastForward,
                                        contentDescription = "Forward 15s",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                // Screen Orientation Toggle
                                IconButton(
                                    onClick = {
                                        activity?.let {
                                            val currentOrientation = it.requestedOrientation
                                            it.requestedOrientation = if (currentOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                                                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                            } else {
                                                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ScreenRotation,
                                        contentDescription = "Rotate Screen",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Playback Speed Dialog
    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            containerColor = DarkCard,
            title = { Text("Playback Speed", color = TextPrimary) },
            text = {
                Column {
                    speeds.forEach { speed ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.setSpeed(speed)
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${speed}x ${if (speed == 1.0f) "(Normal)" else ""}",
                                color = if (playbackSpeed == speed) CyanAccent else TextPrimary,
                                fontWeight = if (playbackSpeed == speed) FontWeight.Bold else FontWeight.Normal
                            )
                            if (playbackSpeed == speed) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // Aspect Ratio Dialog
    if (showAspectDialog) {
        AlertDialog(
            onDismissRequest = { showAspectDialog = false },
            containerColor = DarkCard,
            title = { Text("Aspect Ratio & Fit Mode", color = TextPrimary) },
            text = {
                Column {
                    ResizeMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.setResizeMode(mode)
                                    showAspectDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mode.label,
                                color = if (resizeMode == mode) CyanAccent else TextPrimary,
                                fontWeight = if (resizeMode == mode) FontWeight.Bold else FontWeight.Normal
                            )
                            if (resizeMode == mode) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAspectDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // Subtitles Dialog
    if (showSubtitleDialog) {
        AlertDialog(
            onDismissRequest = { showSubtitleDialog = false },
            containerColor = DarkCard,
            title = { Text("Subtitles & Audio", color = TextPrimary) },
            text = {
                Column {
                    Text("Select Track:", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    availableSubtitles.forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.selectSubtitleTrack(track)
                                    showSubtitleDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = track.name,
                                color = if (track.isSelected) CyanAccent else TextPrimary
                            )
                            if (track.isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            subtitleFilePicker.launch("*/*")
                            showSubtitleDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Load External Subtitle (.srt / .vtt)")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSubtitleDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
