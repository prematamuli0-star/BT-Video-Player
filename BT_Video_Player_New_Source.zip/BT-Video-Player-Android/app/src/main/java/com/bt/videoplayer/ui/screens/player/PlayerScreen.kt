package com.bt.videoplayer.ui.screens.player

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import kotlin.math.abs
import kotlin.math.hypot
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.bt.videoplayer.data.model.SubtitleTrack
import com.bt.videoplayer.player.BTPlayerManager
import com.bt.videoplayer.player.ResizeMode
import com.bt.videoplayer.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    playerManager: BTPlayerManager,
    isInPipMode: Boolean,
    onBackClick: () -> Unit,
    onEnterPip: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current

    val isPlaying by playerManager.isPlaying.collectAsState()
    val currentPosition by playerManager.currentPositionMs.collectAsState()
    val duration by playerManager.durationMs.collectAsState()
    val bufferedPosition by playerManager.bufferedPositionMs.collectAsState()
    val playbackSpeed by playerManager.playbackSpeed.collectAsState()
    val resizeMode by playerManager.resizeMode.collectAsState()
    val currentVideo by playerManager.currentVideo.collectAsState()
    val availableSubtitles by playerManager.availableSubtitles.collectAsState()
    val availableAudioTracks by playerManager.availableAudioTracks.collectAsState()

    var areControlsVisible by remember { mutableStateOf(true) }
    var isControlsLocked by remember { mutableStateOf(false) }

    // Dialog states
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var showAspectDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }

    // Gesture feedback HUD states
    var volumeLevel by remember { mutableStateOf<Int?>(null) }
    var brightnessLevel by remember { mutableStateOf<Float?>(null) }
    var seekDeltaMs by remember { mutableStateOf<Long?>(null) }
    var seekTargetMs by remember { mutableStateOf(0L) }
    var doubleTapFeedback by remember { mutableStateOf<String?>(null) }
    var isTouching by remember { mutableStateOf(false) }

    var dragMode by remember { mutableStateOf("none") }
    var dragStartOffset by remember { mutableStateOf(Offset.Zero) }
    var initialSeekPosition by remember { mutableStateOf(0L) }
    var totalDragX by remember { mutableStateOf(0f) }
    var totalDragY by remember { mutableStateOf(0f) }
    var hasGestured by remember { mutableStateOf(false) }

    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }

    // External Subtitle Picker
    val subtitleFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            playerManager.loadExternalSubtitle(uri)
        }
    }

    // Timer to update playback position
    LaunchedEffect(isPlaying) {
        while (true) {
            playerManager.updatePosition()
            delay(500)
        }
    }

    // Auto-hide controls after 3.5 seconds (paused while user is touching screen)
    LaunchedEffect(areControlsVisible, isPlaying, isTouching) {
        if (areControlsVisible && isPlaying && !isControlsLocked && !isTouching) {
            delay(3500)
            areControlsVisible = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isControlsLocked) {
                detectTapGestures(
                    onTap = {
                        if (isControlsLocked) {
                            areControlsVisible = true
                        } else if (!hasGestured) {
                            areControlsVisible = !areControlsVisible
                        }
                        hasGestured = false
                    },
                    onDoubleTap = { offset ->
                        if (!isControlsLocked && !hasGestured) {
                            val screenWidth = size.width
                            if (offset.x < screenWidth * 0.38f) {
                                playerManager.seekTo(currentPosition - 10000)
                                doubleTapFeedback = "-10s"
                            } else if (offset.x > screenWidth * 0.62f) {
                                playerManager.seekTo(currentPosition + 10000)
                                doubleTapFeedback = "+10s"
                            } else {
                                playerManager.togglePlayPause()
                            }
                        }
                        hasGestured = false
                    }
                )
            }
            .pointerInput(isControlsLocked) {
                if (!isControlsLocked) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { offset ->
                            isTouching = true
                            hasGestured = false
                            dragStartOffset = offset
                            initialSeekPosition = playerManager.currentPositionMs.value
                            dragMode = "none"
                            totalDragX = 0f
                            totalDragY = 0f
                        },
                        onDragEnd = {
                            isTouching = false
                            if (dragMode == "seek" && seekDeltaMs != null) {
                                playerManager.seekTo(seekTargetMs)
                            }
                            dragMode = "none"
                            coroutineScope.launch {
                                delay(700)
                                seekDeltaMs = null
                                volumeLevel = null
                                brightnessLevel = null
                            }
                        },
                        onDragCancel = {
                            isTouching = false
                            dragMode = "none"
                            seekDeltaMs = null
                            volumeLevel = null
                            brightnessLevel = null
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            totalDragX += dragAmount.x
                            totalDragY -= dragAmount.y // up is positive

                            val screenWidth = size.width
                            val screenHeight = size.height
                            val absX = abs(totalDragX)
                            val absY = abs(totalDragY)

                            // Initial gesture recognition with threshold to prevent conflicts
                            if (dragMode == "none") {
                                if (hypot(totalDragX, totalDragY) > 12f) {
                                    hasGestured = true
                                    val isLeft = dragStartOffset.x < screenWidth * 0.38f
                                    val isRight = dragStartOffset.x > screenWidth * 0.62f

                                    dragMode = when {
                                        absX > absY -> "seek"
                                        isLeft -> "brightness"
                                        isRight -> "volume"
                                        else -> "none"
                                    }
                                } else {
                                    return@detectDragGesturesAfterLongPress
                                }
                            }

                            hasGestured = true

                            when (dragMode) {
                                "brightness" -> {
                                    // 1. LEFT SIDE: Continuous brightness adjustment
                                    activity?.window?.let { window ->
                                        val lp = window.attributes
                                        val base = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                                        val newBrightness = (base + (dragAmount.y * -0.005f)).coerceIn(0.01f, 1.0f)
                                        lp.screenBrightness = newBrightness
                                        window.attributes = lp
                                        brightnessLevel = newBrightness
                                    }
                                }
                                "volume" -> {
                                    // 2. RIGHT SIDE: Continuous volume adjustment
                                    val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                    val step = if (dragAmount.y < 0) 1 else -1
                                    val newVol = (currentVol + step).coerceIn(0, maxVolume)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                    volumeLevel = newVol
                                }
                                "seek" -> {
                                    // 3. CENTER: Continuous seek with preview delta
                                    val scrubRangeMs = kotlin.math.min(kotlin.math.max(60000L, duration * 2 / 5), 180000L)
                                    val fraction = totalDragX / (screenWidth * 0.65f)
                                    val delta = (fraction * scrubRangeMs).toLong()
                                    seekDeltaMs = delta
                                    seekTargetMs = (initialSeekPosition + delta).coerceIn(0L, duration.coerceAtLeast(0L))
                                }
                            }
                        }
                    )
                }
            }
    ) {
        // ExoPlayer View
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = playerManager.exoPlayer
                    useController = false
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setResizeMode(playerManager.resizeMode.value.exoMode)
                }
            },
            update = { playerView ->
                playerView.setResizeMode(resizeMode.exoMode)
            },
            modifier = Modifier.fillMaxSize()
        )

        // Floating live volume bar at the right edge
        if (volumeLevel != null) {
            val volumeFraction = (volumeLevel!!.toFloat() / maxVolume.coerceAtLeast(1)).coerceIn(0f, 1f)
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 18.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xCC101A2A))
                    .padding(horizontal = 12.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.VolumeUp, contentDescription = "Volume", tint = CyanAccent, modifier = Modifier.size(24.dp))
                Spacer(Modifier.height(10.dp))
                Box(Modifier.width(6.dp).height(104.dp).clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth().fillMaxHeight(volumeFraction).clip(RoundedCornerShape(8.dp)).background(CyanAccent))
                }
                Spacer(Modifier.height(8.dp))
                Text("${(volumeFraction * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Floating live brightness bar at the left edge
        if (brightnessLevel != null) {
            val brightnessFraction = brightnessLevel!!.coerceIn(0.01f, 1f)
            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 18.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xCC101A2A))
                    .padding(horizontal = 12.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.BrightnessMedium, contentDescription = "Brightness", tint = CyanAccent, modifier = Modifier.size(24.dp))
                Spacer(Modifier.height(10.dp))
                Box(Modifier.width(6.dp).height(104.dp).clip(RoundedCornerShape(8.dp)).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth().fillMaxHeight(brightnessFraction).clip(RoundedCornerShape(8.dp)).background(CyanAccent))
                }
                Spacer(Modifier.height(8.dp))
                Text("${(brightnessFraction * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Continuous Seek Gesture HUD (MX Player style)
        if (seekDeltaMs != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(16.dp))
                    .background(GestureHUDBackground)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (seekDeltaMs!! >= 0) Icons.Default.FastForward else Icons.Default.FastRewind,
                            contentDescription = null,
                            tint = if (seekDeltaMs!! >= 0) CyanAccent else OrangeAccent,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = formatDeltaTime(seekDeltaMs!!),
                            color = if (seekDeltaMs!! >= 0) CyanAccent else OrangeAccent,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 24.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${formatTime(seekTargetMs)} / ${formatTime(duration)}",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { if (duration > 0) (seekTargetMs.toFloat() / duration).coerceIn(0f, 1f) else 0f },
                        modifier = Modifier
                            .width(160.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = CyanAccent,
                        trackColor = Color.DarkGray
                    )
                }
            }
        }

        if (doubleTapFeedback != null && seekDeltaMs == null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(CircleShape)
                                        .padding(20.dp)
            ) {
                Text(
                    text = doubleTapFeedback ?: "",
                    color = CyanAccent,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            }
        }

        // Overlay Controls (only visible when not in PiP mode)
        if (!isInPipMode) {
            AnimatedVisibility(
                visible = areControlsVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                                        ) {
                    if (isControlsLocked) {
                        // Show ONLY the unlock button when screen is locked
                        IconButton(
                            onClick = {
                                isControlsLocked = false
                            },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(24.dp)
                                .clip(CircleShape)
                                                                .size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Unlock Controls",
                                tint = CyanAccent
                            )
                        }
                    } else {
                        // Top Toolbar
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .statusBarsPadding(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = onBackClick) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = currentVideo?.displayName ?: "Playing Video",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${currentVideo?.resolutionLabel ?: "HD"} • ${playbackSpeed}x",
                                    color = CyanAccent,
                                    fontSize = 11.sp
                                )
                            }

                            // Audio language / track selector
                            IconButton(onClick = { showAudioDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Audio Language",
                                    tint = CyanAccent
                                )
                            }

                            // Subtitle Track Button
                            IconButton(onClick = { showSubtitleDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Subtitles,
                                    contentDescription = "Subtitles",
                                    tint = TextPrimary
                                )
                            }

                            // Speed Selector Button
                            IconButton(onClick = { showSpeedDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.Speed,
                                    contentDescription = "Speed",
                                    tint = TextPrimary
                                )
                            }

                            // Aspect Ratio Mode Switcher
                            IconButton(onClick = { showAspectDialog = true }) {
                                Icon(
                                    imageVector = Icons.Default.AspectRatio,
                                    contentDescription = "Aspect Ratio",
                                    tint = TextPrimary
                                )
                            }

                            // Picture-in-Picture Button
                            IconButton(onClick = onEnterPip) {
                                Icon(
                                    imageVector = Icons.Default.PictureInPictureAlt,
                                    contentDescription = "Picture-in-Picture",
                                    tint = CyanAccent
                                )
                            }

                            // Screen Lock Button
                            IconButton(onClick = { isControlsLocked = true }) {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = "Lock Screen",
                                    tint = TextPrimary
                                )
                            }
                        }

                        // Bottom Toolbar & Scrub Bar
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                                                .padding(horizontal = 16.dp, vertical = 12.dp)
                                .navigationBarsPadding()
                        ) {
                            // Time codes
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = formatTime(currentPosition),
                                    color = CyanAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = formatTime(duration),
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }

                            // Scrubber / Seek Bar
                            Slider(
                                value = if (duration > 0) (currentPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                                onValueChange = { fraction ->
                                    val targetMs = (fraction * duration).toLong()
                                    playerManager.seekTo(targetMs)
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = CyanAccent,
                                    activeTrackColor = CyanAccent,
                                    inactiveTrackColor = Color.DarkGray
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Centered transport controls: Previous, Play/Pause, Next
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { playerManager.playPrevious() }, modifier = Modifier.size(56.dp)) {
                                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous Video", tint = TextPrimary, modifier = Modifier.size(34.dp))
                                }
                                Spacer(Modifier.width(34.dp))
                                IconButton(onClick = { playerManager.togglePlayPause() }, modifier = Modifier.size(64.dp)) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = if (isPlaying) "Pause" else "Play",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(48.dp)
                                    )
                                }
                                Spacer(Modifier.width(34.dp))
                                IconButton(onClick = { playerManager.playNext() }, modifier = Modifier.size(56.dp)) {
                                    Icon(Icons.Default.SkipNext, contentDescription = "Next Video", tint = TextPrimary, modifier = Modifier.size(34.dp))
                                }
                            }
                            }
                        }
                    }
                }
            }
        }

    // Real Media3 audio track selector
    if (showAudioDialog) {
        AlertDialog(
            onDismissRequest = { showAudioDialog = false },
            containerColor = DarkCard,
            title = { Text("Audio Language", color = TextPrimary) },
            text = {
                if (availableAudioTracks.isEmpty()) {
                    Text("No alternate audio tracks available in this media stream", color = TextSecondary)
                } else {
                    Column {
                        availableAudioTracks.forEach { track ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        playerManager.selectAudioTrack(track)
                                        showAudioDialog = false
                                    }
                                    .padding(vertical = 12.dp, horizontal = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(track.label, color = if (track.isSelected) CyanAccent else TextPrimary)
                                    track.language?.let { Text(it, color = TextSecondary, fontSize = 11.sp) }
                                }
                                if (track.isSelected) Icon(Icons.Default.Check, contentDescription = "Selected", tint = CyanAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAudioDialog = false }) { Text("Close", color = CyanAccent) }
            }
        )
    }

    // Playback Speed Dialog
    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            containerColor = DarkCard,
            title = { Text("Playback Speed", color = TextPrimary) },
            text = {
                Column {
                    speeds.forEach { speed ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.setSpeed(speed)
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${speed}x ${if (speed == 1.0f) "(Normal)" else ""}",
                                color = if (playbackSpeed == speed) CyanAccent else TextPrimary,
                                fontWeight = if (playbackSpeed == speed) FontWeight.Bold else FontWeight.Normal
                            )
                            if (playbackSpeed == speed) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // Aspect Ratio Dialog
    if (showAspectDialog) {
        AlertDialog(
            onDismissRequest = { showAspectDialog = false },
            containerColor = DarkCard,
            title = { Text("Aspect Ratio & Fit Mode", color = TextPrimary) },
            text = {
                Column {
                    ResizeMode.values().forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.setResizeMode(mode)
                                    showAspectDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mode.label,
                                color = if (resizeMode == mode) CyanAccent else TextPrimary,
                                fontWeight = if (resizeMode == mode) FontWeight.Bold else FontWeight.Normal
                            )
                            if (resizeMode == mode) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAspectDialog = false }) {
                    Text("Close", color = CyanAccent)
                }
            }
        )
    }

    // Subtitles Dialog
    if (showSubtitleDialog) {
        AlertDialog(
            onDismissRequest = { showSubtitleDialog = false },
            containerColor = DarkCard,
            title = { Text("Subtitles & Audio", color = TextPrimary) },
            text = {
                Column {
                    Text("Select Track:", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    availableSubtitles.forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    playerManager.selectSubtitleTrack(track)
                                    showSubtitleDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = track.name,
                                color = if (track.isSelected) CyanAccent else TextPrimary
                            )
                            if (track.isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = CyanAccent)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            subtitleFilePicker.launch("*/*")
                            showSubtitleDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Load External Subtitle (.srt / .vtt)")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSubtitleDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

fun formatDeltaTime(deltaMs: Long): String {
    val totalSeconds = (kotlin.math.abs(deltaMs) / 1000).coerceAtLeast(0)
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    val sign = if (deltaMs >= 0) "+" else "-"
    return String.format("%s%02d:%02d", sign, minutes, seconds)
}
