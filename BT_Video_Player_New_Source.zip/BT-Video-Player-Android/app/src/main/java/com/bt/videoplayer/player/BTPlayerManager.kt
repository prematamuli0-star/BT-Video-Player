package com.bt.videoplayer.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.bt.videoplayer.data.model.AudioTrack
import com.bt.videoplayer.data.model.SubtitleTrack
import com.bt.videoplayer.data.model.VideoItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

@OptIn(UnstableApi::class)
class BTPlayerManager(private val context: Context) {

    private val trackSelector = DefaultTrackSelector(context)

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context)
        .setTrackSelector(trackSelector)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            /* handleAudioFocus = */ true
        )
        .build()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _bufferedPositionMs = MutableStateFlow(0L)
    val bufferedPositionMs: StateFlow<Long> = _bufferedPositionMs.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _resizeMode = MutableStateFlow(ResizeMode.FIT)
    val resizeMode: StateFlow<ResizeMode> = _resizeMode.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _availableSubtitles = MutableStateFlow<List<SubtitleTrack>>(emptyList())
    val availableSubtitles: StateFlow<List<SubtitleTrack>> = _availableSubtitles.asStateFlow()

    private val _availableAudioTracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    val availableAudioTracks: StateFlow<List<AudioTrack>> = _availableAudioTracks.asStateFlow()

    private var playlist: List<VideoItem> = emptyList()
    private var currentIndex: Int = -1

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(0L)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                extractSubtitleTracks(tracks)
                extractAudioTracks(tracks)
            }
        })
    }

    fun setPlaylist(videos: List<VideoItem>, startIndex: Int, startPositionMs: Long = 0L) {
        playlist = videos
        currentIndex = startIndex.coerceIn(0, (videos.size - 1).coerceAtLeast(0))
        if (videos.isNotEmpty() && currentIndex in videos.indices) {
            playVideo(videos[currentIndex], startPositionMs)
        }
    }

    fun playVideo(video: VideoItem, startPositionMs: Long = 0L) {
        _currentVideo.value = video
        val mediaItem = MediaItem.fromUri(video.uri)
        // Set the requested start position as part of the media item. This avoids
        // issuing a seek against an unprepared/unknown timeline (which can resolve to 0).
        exoPlayer.setMediaItem(mediaItem, startPositionMs.coerceAtLeast(0L))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    fun play() {
        exoPlayer.play()
    }

    fun pause() {
        exoPlayer.pause()
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun seekTo(positionMs: Long) {
        val requestedPosition = positionMs.coerceAtLeast(0L)
        val mediaDuration = exoPlayer.duration

        // C.TIME_UNSET / 0 means duration is not known yet. Do not clamp to 0:
        // that made seek gestures on some files jump back to the beginning.
        val targetPosition = if (mediaDuration != C.TIME_UNSET && mediaDuration > 0L) {
            requestedPosition.coerceAtMost(mediaDuration)
        } else {
            requestedPosition
        }

        exoPlayer.seekTo(targetPosition)
        updatePosition()
    }

    fun playNext(): Boolean {
        if (playlist.isNotEmpty() && currentIndex < playlist.size - 1) {
            currentIndex++
            playVideo(playlist[currentIndex])
            return true
        }
        return false
    }

    fun playPrevious(): Boolean {
        if (playlist.isNotEmpty() && currentIndex > 0) {
            currentIndex--
            playVideo(playlist[currentIndex])
            return true
        } else {
            exoPlayer.seekTo(0)
            return false
        }
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        _playbackSpeed.value = clamped
        exoPlayer.playbackParameters = PlaybackParameters(clamped)
    }

    fun setResizeMode(mode: ResizeMode) {
        _resizeMode.value = mode
    }

    fun cycleResizeMode() {
        val modes = ResizeMode.values()
        val nextIndex = (modes.indexOf(_resizeMode.value) + 1) % modes.size
        _resizeMode.value = modes[nextIndex]
    }

    fun loadExternalSubtitle(uri: Uri, mimeType: String = MimeTypes.APPLICATION_SUBRIP) {
        val current = _currentVideo.value ?: return
        val currentPos = exoPlayer.currentPosition

        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mimeType)
            .setLanguage("custom")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(current.uri)
            .setSubtitleConfigurations(listOf(subtitleConfig))
            .build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.seekTo(currentPos)
        exoPlayer.playWhenReady = true
    }

    private fun extractSubtitleTracks(tracks: Tracks) {
        val subs = mutableListOf<SubtitleTrack>()
        val textGroups = tracks.groups.withIndex()
            .filter { it.value.type == C.TRACK_TYPE_TEXT }
        val hasSelectedSubtitle = textGroups.any { indexedGroup ->
            (0 until indexedGroup.value.length).any { indexedGroup.value.isTrackSelected(it) }
        }

        // "Off" is selected only when no text track is currently active.
        subs.add(SubtitleTrack("none", "Off (None)", isSelected = !hasSelectedSubtitle))

        textGroups.forEach { indexedGroup ->
            val groupIndex = indexedGroup.index
            val group = indexedGroup.value
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val label = format.label ?: format.language ?: "Track ${subs.size}"
                subs.add(
                    SubtitleTrack(
                        id = format.id ?: "$groupIndex-$i",
                        name = label,
                        language = format.language,
                        isSelected = group.isTrackSelected(i),
                        groupIndex = groupIndex,
                        trackIndex = i
                    )
                )
            }
        }
        _availableSubtitles.value = subs
    }

    private fun extractAudioTracks(tracks: Tracks) {
        val audioList = mutableListOf<AudioTrack>()
        var audioGroupIdx = 0
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val lang = format.language
                    val langName = if (!lang.isNullOrBlank()) {
                        try {
                            val loc = Locale(lang)
                            loc.displayLanguage.ifBlank { lang }
                        } catch (e: Exception) {
                            lang
                        }
                    } else null

                    val label = format.label ?: langName ?: "Audio Track ${audioList.size + 1}"
                    val isSelected = group.isTrackSelected(i)
                    audioList.add(
                        AudioTrack(
                            id = format.id ?: "$audioGroupIdx-$i",
                            name = label,
                            language = lang,
                            channels = format.channelCount,
                            sampleRate = format.sampleRate,
                            isSelected = isSelected,
                            groupIndex = audioGroupIdx,
                            trackIndex = i
                        )
                    )
                }
                audioGroupIdx++
            }
        }
        _availableAudioTracks.value = audioList
    }

    fun selectSubtitleTrack(track: SubtitleTrack) {
        val parameters = trackSelector.buildUponParameters()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)

        if (track.id == "none") {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            val selectedGroup = exoPlayer.currentTracks.groups
                .getOrNull(track.groupIndex)
                ?.takeIf { it.type == C.TRACK_TYPE_TEXT }

            if (selectedGroup != null && track.trackIndex in 0 until selectedGroup.length) {
                // Select this exact track, not merely the preferred language.
                parameters.addOverride(
                    TrackSelectionOverride(
                        selectedGroup.mediaTrackGroup,
                        track.trackIndex
                    )
                )
            } else if (track.language != null) {
                // Fallback for a track whose group is no longer present.
                parameters.setPreferredTextLanguage(track.language)
            }
        }
        trackSelector.setParameters(parameters)
    }

    fun selectAudioTrack(track: AudioTrack) {
        val parameters = trackSelector.buildUponParameters()
        if (track.language != null) {
            parameters.setPreferredAudioLanguage(track.language)
        }
        trackSelector.setParameters(parameters)
    }

    fun updatePosition() {
        _currentPositionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
        _bufferedPositionMs.value = exoPlayer.bufferedPosition.coerceAtLeast(0L)
        _durationMs.value = exoPlayer.duration.coerceAtLeast(0L)
    }

    fun release() {
        exoPlayer.release()
    }
}
