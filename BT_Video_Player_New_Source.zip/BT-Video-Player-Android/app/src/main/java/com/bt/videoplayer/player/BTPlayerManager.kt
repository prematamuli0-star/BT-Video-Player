package com.bt.videoplayer.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.bt.videoplayer.data.model.SubtitleTrack
import com.bt.videoplayer.data.model.VideoItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AudioTrackOption(
    val label: String,
    val language: String?,
    val group: TrackGroup,
    val trackIndex: Int,
    val isSelected: Boolean
)

@OptIn(UnstableApi::class)
class BTPlayerManager(private val context: Context) {

    private val trackSelector = DefaultTrackSelector(context)

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context)
        .setTrackSelector(trackSelector)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            /* handleAudioFocus = */ true
        )
        .build()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _bufferedPositionMs = MutableStateFlow(0L)
    val bufferedPositionMs: StateFlow<Long> = _bufferedPositionMs.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _resizeMode = MutableStateFlow(ResizeMode.FIT)
    val resizeMode: StateFlow<ResizeMode> = _resizeMode.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _availableSubtitles = MutableStateFlow<List<SubtitleTrack>>(emptyList())
    val availableSubtitles: StateFlow<List<SubtitleTrack>> = _availableSubtitles.asStateFlow()

    private val _availableAudioTracks = MutableStateFlow<List<AudioTrackOption>>(emptyList())
    val availableAudioTracks: StateFlow<List<AudioTrackOption>> = _availableAudioTracks.asStateFlow()

    private var playlist: List<VideoItem> = emptyList()
    private var currentIndex: Int = -1

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _durationMs.value = exoPlayer.duration.coerceAtLeast(0L)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                extractSubtitleTracks(tracks)
                extractAudioTracks(tracks)
            }
        })
    }

    fun setPlaylist(videos: List<VideoItem>, startIndex: Int, startPositionMs: Long = 0L) {
        playlist = videos
        currentIndex = startIndex.coerceIn(0, (videos.size - 1).coerceAtLeast(0))
        if (videos.isNotEmpty() && currentIndex in videos.indices) {
            playVideo(videos[currentIndex], startPositionMs)
        }
    }

    fun playVideo(video: VideoItem, startPositionMs: Long = 0L) {
        _currentVideo.value = video
        val mediaItem = MediaItem.fromUri(video.uri)
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        if (startPositionMs > 0) {
            exoPlayer.seekTo(startPositionMs)
        }
        exoPlayer.playWhenReady = true
    }

    fun play() {
        exoPlayer.play()
    }

    fun pause() {
        exoPlayer.pause()
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            pause()
        } else {
            play()
        }
    }


    fun seekTo(positionMs: Long) {
        exoPlayer.seekTo(positionMs.coerceIn(0L, exoPlayer.duration.coerceAtLeast(0L)))
        updatePosition()
    }

    fun playNext(): Boolean {
        if (playlist.isNotEmpty() && currentIndex < playlist.size - 1) {
            currentIndex++
            playVideo(playlist[currentIndex])
            return true
        }
        return false
    }

    fun playPrevious(): Boolean {
        if (playlist.isNotEmpty() && currentIndex > 0) {
            currentIndex--
            playVideo(playlist[currentIndex])
            return true
        } else {
            exoPlayer.seekTo(0)
            return false
        }
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        _playbackSpeed.value = clamped
        exoPlayer.playbackParameters = PlaybackParameters(clamped)
    }

    fun setResizeMode(mode: ResizeMode) {
        _resizeMode.value = mode
    }

    fun cycleResizeMode() {
        val modes = ResizeMode.values()
        val nextIndex = (modes.indexOf(_resizeMode.value) + 1) % modes.size
        _resizeMode.value = modes[nextIndex]
    }

    fun loadExternalSubtitle(uri: Uri, mimeType: String = MimeTypes.APPLICATION_SUBRIP) {
        val current = _currentVideo.value ?: return
        val currentPos = exoPlayer.currentPosition

        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mimeType)
            .setLanguage("custom")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(current.uri)
            .setSubtitleConfigurations(listOf(subtitleConfig))
            .build()

        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.seekTo(currentPos)
        exoPlayer.playWhenReady = true
    }

    private fun extractSubtitleTracks(tracks: Tracks) {
        val subs = mutableListOf<SubtitleTrack>()
        subs.add(SubtitleTrack("none", "Off (None)", isSelected = true))

        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val label = format.label ?: format.language ?: "Track ${subs.size}"
                    val isSelected = group.isTrackSelected(i)
                    subs.add(
                        SubtitleTrack(
                            id = format.id ?: "$i",
                            name = label,
                            language = format.language,
                            isSelected = isSelected
                        )
                    )
                }
            }
        }
        _availableSubtitles.value = subs
    }

    fun selectSubtitleTrack(track: SubtitleTrack) {
        val parameters = trackSelector.buildUponParameters()
        if (track.id == "none") {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            if (track.language != null) {
                parameters.setPreferredTextLanguage(track.language)
            }
        }
        trackSelector.setParameters(parameters)
    }


    private fun extractAudioTracks(tracks: Tracks) {
        val audio = mutableListOf<AudioTrackOption>()
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (index in 0 until group.length) {
                    val format = group.getTrackFormat(index)
                    val language = format.language?.takeIf { it.isNotBlank() && it != "und" }
                    val label = format.label?.takeIf { it.isNotBlank() }
                        ?: language?.let { java.util.Locale.forLanguageTag(it).getDisplayLanguage() }
                        ?: "Audio ${audio.size + 1}"
                    audio.add(
                        AudioTrackOption(
                            label = label,
                            language = language,
                            group = group.mediaTrackGroup,
                            trackIndex = index,
                            isSelected = group.isTrackSelected(index)
                        )
                    )
                }
            }
        }
        _availableAudioTracks.value = audio
    }

    fun selectAudioTrack(track: AudioTrackOption) {
        val parameters = trackSelector.buildUponParameters()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .addOverride(TrackSelectionOverride(track.group, listOf(track.trackIndex)))
        trackSelector.setParameters(parameters)
    }

    fun updatePosition() {
        _currentPositionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
        _bufferedPositionMs.value = exoPlayer.bufferedPosition.coerceAtLeast(0L)
        _durationMs.value = exoPlayer.duration.coerceAtLeast(0L)
    }

    fun release() {
        exoPlayer.release()
    }
}
