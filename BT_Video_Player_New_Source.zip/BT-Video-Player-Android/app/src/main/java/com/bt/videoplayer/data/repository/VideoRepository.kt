package com.bt.videoplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.bt.videoplayer.data.model.FolderItem
import com.bt.videoplayer.data.model.VideoItem
import com.bt.videoplayer.data.preferences.PlayerPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class VideoRepository(
    private val context: Context,
    private val preferences: PlayerPreferences
) {
    suspend fun getAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoItem>()

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val displayCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val widthCol = it.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = it.getColumnIndex(MediaStore.Video.Media.HEIGHT)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val rawTitle = it.getString(titleCol) ?: "Untitled Video"
                    val displayName = it.getString(displayCol) ?: rawTitle
                    val path = it.getString(dataCol) ?: ""
                    val duration = it.getLong(durationCol)
                    val size = it.getLong(sizeCol)
                    val dateAdded = it.getLong(dateCol)
                    val width = if (widthCol != -1) it.getInt(widthCol) else 0
                    val height = if (heightCol != -1) it.getInt(heightCol) else 0

                    val folderName = try {
                        val file = File(path)
                        file.parentFile?.name ?: "Internal Storage"
                    } catch (e: Exception) {
                        "Videos"
                    }

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    val isFav = preferences.isFavorite(id)
                    val lastPos = preferences.getLastPosition(id)

                    videoList.add(
                        VideoItem(
                            id = id,
                            title = rawTitle,
                            displayName = displayName,
                            uri = contentUri,
                            path = path,
                            durationMs = duration,
                            sizeBytes = size,
                            dateAdded = dateAdded,
                            folderName = folderName,
                            width = width,
                            height = height,
                            isFavorite = isFav,
                            lastPositionMs = lastPos
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        videoList
    }

    suspend fun getFolders(videos: List<VideoItem>): List<FolderItem> = withContext(Dispatchers.Default) {
        val folderMap = mutableMapOf<String, MutableList<VideoItem>>()
        videos.forEach { video ->
            val list = folderMap.getOrPut(video.folderName) { mutableListOf() }
            list.add(video)
        }

        folderMap.map { (name, videoGroup) ->
            val samplePath = videoGroup.firstOrNull()?.path ?: ""
            val folderPath = try {
                File(samplePath).parent ?: name
            } catch (e: Exception) {
                name
            }
            FolderItem(
                name = name,
                path = folderPath,
                videoCount = videoGroup.size,
                totalSizeBytes = videoGroup.sumOf { it.sizeBytes },
                latestVideoDate = videoGroup.maxOfOrNull { it.dateAdded } ?: 0L
            )
        }.sortedByDescending { it.videoCount }
    }

    fun toggleFavorite(videoId: Long): Boolean {
        return preferences.toggleFavorite(videoId)
    }

    fun saveResumePosition(videoId: Long, posMs: Long) {
        preferences.saveLastPosition(videoId, posMs)
    }
}
