package com.bt.videoplayer.data.repository

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.bt.videoplayer.data.model.FolderItem
import com.bt.videoplayer.data.model.VideoItem
import com.bt.videoplayer.data.preferences.PlayerPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class VideoRepository(
    private val context: Context,
    private val preferences: PlayerPreferences
) {
    suspend fun getAllVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoItem>()

        // RELATIVE_PATH is the supported folder source on Android 10+.
        // Keep DATA as a fallback for older Android versions and unusual providers.
        val projection = buildList {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.TITLE)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(MediaStore.Video.Media.DATA)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                add(MediaStore.Video.Media.RELATIVE_PATH)
            }
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.DATE_ADDED)
            add(MediaStore.Video.Media.WIDTH)
            add(MediaStore.Video.Media.HEIGHT)
        }.toTypedArray()

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        val videosUri = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        try {
            val cursor = context.contentResolver.query(
                videosUri,
                projection,
                null,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val displayCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val dataCol = it.getColumnIndex(MediaStore.Video.Media.DATA)
                val relativePathCol = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    it.getColumnIndex(MediaStore.Video.Media.RELATIVE_PATH)
                } else -1
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val widthCol = it.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = it.getColumnIndex(MediaStore.Video.Media.HEIGHT)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val rawTitle = it.getString(titleCol) ?: "Untitled Video"
                    val displayName = it.getString(displayCol) ?: rawTitle
                    val path = if (dataCol >= 0) it.getString(dataCol).orEmpty() else ""
                    val relativePath = if (relativePathCol >= 0) it.getString(relativePathCol).orEmpty() else ""
                    val duration = it.getLong(durationCol)
                    val size = it.getLong(sizeCol)
                    val dateAdded = it.getLong(dateCol)
                    val width = if (widthCol != -1) it.getInt(widthCol) else 0
                    val height = if (heightCol != -1) it.getInt(heightCol) else 0

                    val folderName = try {
                        // RELATIVE_PATH is usually like "Movies/" or "DCIM/Camera/".
                        relativePath.trimEnd('/')
                            .substringAfterLast('/', missingDelimiterValue = "")
                            .ifBlank {
                                File(path).parentFile?.name?.takeIf { it.isNotBlank() }
                                    ?: "Videos"
                            }
                    } catch (e: Exception) {
                        "Videos"
                    }

                    val contentUri = ContentUris.withAppendedId(videosUri, id)

                    val isFav = preferences.isFavorite(id)
                    val lastPos = preferences.getLastPosition(id)

                    videoList.add(
                        VideoItem(
                            id = id,
                            title = rawTitle,
                            displayName = displayName,
                            uri = contentUri,
                            path = path,
                            durationMs = duration,
                            sizeBytes = size,
                            dateAdded = dateAdded,
                            folderName = folderName,
                            width = width,
                            height = height,
                            isFavorite = isFav,
                            lastPositionMs = lastPos
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        videoList
    }

    suspend fun getFolders(videos: List<VideoItem>): List<FolderItem> = withContext(Dispatchers.Default) {
        val folderMap = mutableMapOf<String, MutableList<VideoItem>>()
        videos.forEach { video ->
            val list = folderMap.getOrPut(video.folderName) { mutableListOf() }
            list.add(video)
        }

        folderMap.map { (name, videoGroup) ->
            val samplePath = videoGroup.firstOrNull()?.path ?: ""
            val folderPath = try {
                File(samplePath).parent ?: name
            } catch (e: Exception) {
                name
            }
            FolderItem(
                name = name,
                path = folderPath,
                videoCount = videoGroup.size,
                totalSizeBytes = videoGroup.sumOf { it.sizeBytes },
                latestVideoDate = videoGroup.maxOfOrNull { it.dateAdded } ?: 0L
            )
        }.sortedByDescending { it.videoCount }
    }

    fun toggleFavorite(videoId: Long): Boolean {
        return preferences.toggleFavorite(videoId)
    }

    fun saveResumePosition(videoId: Long, posMs: Long) {
        preferences.saveLastPosition(videoId, posMs)
    }
}
