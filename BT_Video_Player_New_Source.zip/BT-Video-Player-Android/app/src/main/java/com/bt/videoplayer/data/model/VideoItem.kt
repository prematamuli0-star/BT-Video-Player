package com.bt.videoplayer.data.model

import android.net.Uri

data class VideoItem(
    val id: Long,
    val title: String,
    val displayName: String,
    val uri: Uri,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAdded: Long,
    val folderName: String,
    val width: Int = 0,
    val height: Int = 0,
    val isFavorite: Boolean = false,
    val lastPositionMs: Long = 0L
) {
    val formattedDuration: String
        get() {
            val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            return if (hours > 0) {
                String.format("%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }

    val formattedSize: String
        get() {
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.1f MB", mb)
                else -> String.format("%.0f KB", kb)
            }
        }

    val resolutionLabel: String
        get() {
            return when {
                width >= 3840 || height >= 2160 -> "4K"
                width >= 1920 || height >= 1080 -> "1080p"
                width >= 1280 || height >= 720 -> "720p"
                width > 0 && height > 0 -> "${height}p"
                else -> "HD"
            }
        }
}
