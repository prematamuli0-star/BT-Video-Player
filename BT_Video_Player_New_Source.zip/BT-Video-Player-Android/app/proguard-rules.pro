# Add project specific ProGuard rules here.
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.media3.common.util.UnstableApi <methods>;
    @androidx.media3.common.util.UnstableApi <fields>;
}
