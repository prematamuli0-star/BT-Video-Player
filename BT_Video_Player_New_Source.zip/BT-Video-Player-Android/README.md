# BT Video Player - Native Android Application

BT Video Player is a modern, high-performance native Android video player inspired by MX Player, built with **Kotlin**, **Jetpack Compose (Material 3)**, and **AndroidX Media3 ExoPlayer**.

---

## 🚀 Key Features

1. **Android 8.0 (API 26) to Android 15 Ready** (minSdk = 26, targetSdk = 34).
2. **AndroidX Media3 ExoPlayer Engine**: Hardware accelerated decoding, audio focus management, and smooth playback.
3. **MX Player-Inspired Dark UI**: Deep OLED blacks (`#0D0E12`), cyan accent (`#00E5FF`), sleek translucent overlays.
4. **Comprehensive Aspect Ratio Modes**:
   - Fit to Screen (Preserves aspect ratio)
   - Fill / Crop (Eliminates black bars entirely)
   - Stretch (Forces edge-to-edge fill)
   - 100% Original Resolution
5. **Floating Transparent Controls**:
   - Subtly translucent scrims ensuring video content remains completely visible.
   - Clean, balanced 3-button playback controls: **Previous**, **Play/Pause**, and **Next** arranged with perfect horizontal alignment.
   - Quick skip buttons removed in favor of intuitive swipe-to-seek.
   - Smooth seek bar with live buffered indicator and timecodes.
6. **Floating Edge Gesture HUDs**:
   - **Left Edge Brightness Bar**: Floating vertical bar with sun icon, vertical progress track, and live percentage (0–100%) controlling actual window screen brightness continuously.
   - **Right Edge Volume Bar**: Floating vertical bar with speaker icon, vertical progress track, and live percentage (0–100%) controlling actual Android media stream volume continuously.
   - Automatically hides shortly after finger release.
7. **MX Player Horizontal Long-Press Swipe-to-Seek**:
   - Central area horizontal drag to seek backward/forward continuously.
   - Live seek preview overlay showing direction arrow, time delta (e.g., `-00:15` or `+00:15`), target time, and duration.
   - Smoothly applies position on release.
8. **Audio Track / Language Selection**:
   - Dedicated Audio Track button in the top toolbar.
   - Real Media3 ExoPlayer audio track selection dialog with language names and channel layout.
   - Clean notification when no alternate audio tracks are present in the stream.
9. **Subtitles & External Tracks**: Embedded track selection + external `.srt` / `.vtt` file loading via Storage Access Framework.
10. **Playback Speed Control**: 0.5x, 0.75x, 1.0x, 1.25x, 1.5x, 1.75x, 2.0x with pitch correction.
11. **Picture-in-Picture (PiP)**:
    - Floating resizable PiP window with seamless aspect ratio.
    - Automatically enters PiP when pressing the Home button (`onUserLeaveHint`).
12. **Folder Browsing & Media Organization**:
    - Automatic MediaStore scanning for device folders (Movies, Downloads, WhatsApp, DCIM).
    - Video resolution badges (4K, 1080p, 720p), file sizes, durations, and dates.
    - Search, Favorites, and Resume Playback position tracking.

---

## 🛠️ How to Build and Generate a Signed APK

### Method 1: Using Android Studio (Recommended)

1. Open **Android Studio** (Hedgehog, Iguana, or Koala+).
2. Click **Open** and select the `/android` folder.
3. Wait for Gradle Sync to complete.
4. From the top menu, navigate to:
   **Build > Generate Signed Bundle / APK...**
5. Select **APK** and click **Next**.
6. Under **Key store path**:
   - If you have an existing keystore, choose it.
   - Otherwise, click **Create new...**, choose a path (e.g. `bt_release.jks`), enter password and alias details, then click **OK**.
7. Select **release** under Build Variants.
8. Check **V1 (Jar Signature)** and **V2 (Full APK Signature)**.
9. Click **Finish**. Your signed release APK will be generated at:
   `app/build/outputs/apk/release/app-release.apk`

---

### Method 2: Using Command Line (Terminal)

1. Ensure JDK 17+ is installed (`java -version`).
2. Run the automated script:
   ```bash
   chmod +x generate_signed_apk.sh
   ./generate_signed_apk.sh
   ```
3. Or manually build with Gradle:
   ```bash
   ./gradlew assembleRelease
   ```
