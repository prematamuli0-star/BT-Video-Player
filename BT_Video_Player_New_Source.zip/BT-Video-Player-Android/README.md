# BT Video Player - Native Android Application

BT Video Player is a modern, high-performance native Android video player inspired by MX Player, built with **Kotlin**, **Jetpack Compose (Material 3)**, and **AndroidX Media3 ExoPlayer**.

---

## 🚀 Key Features

1. **Android 8.0 (API 26) to Android 15 Ready** (minSdk = 26, targetSdk = 34).
2. **AndroidX Media3 ExoPlayer Engine**: Hardware accelerated decoding, audio focus management, and smooth playback.
3. **MX Player-Inspired Dark UI**: Deep OLED blacks (`#0D0E12`), cyan accent (`#00E5FF`), sleek translucent overlays.
4. **Comprehensive Aspect Ratio Modes**:
   - Fit to Screen (Preserves aspect ratio)
   - Fill / Crop (Eliminates black bars entirely)
   - Stretch (Forces edge-to-edge fill)
   - 100% Original Resolution
5. **Floating Overlay Controls**:
   - Auto-hides after 3.5 seconds of inactivity.
   - 5-second rewind (`-5s`) and 15-second forward (`+15s`) quick jump buttons.
   - Smooth seek bar with live buffered percentage indicator.
   - Previous and Next playlist navigation.
6. **Playback Speed Control**: 0.5x, 0.75x, 1.0x, 1.25x, 1.5x, 1.75x, 2.0x with pitch correction.
7. **Subtitles & Audio**: Embedded track selection + external `.srt` / `.vtt` file loading via Storage Access Framework.
8. **Picture-in-Picture (PiP)**:
   - Floating resizable PiP window with seamless aspect ratio.
   - Automatically enters PiP when pressing the Home button (`onUserLeaveHint`).
9. **Touch Gestures (MX Player Style)**:
   - Vertical swipe on left half: Brightness control HUD.
   - Vertical swipe on right half: Volume control HUD.
   - Double-tap left side: Rewind 10 seconds.
   - Double-tap right side: Fast-forward 10 seconds.
   - Single tap: Toggle controls.
   - Lock toggle: Locks screen against accidental touches.
10. **Folder Browsing & Media Organization**:
    - Automatic MediaStore scanning for device folders (Movies, Downloads, WhatsApp, DCIM).
    - Video resolution badges (4K, 1080p, 720p), file sizes, durations, and dates.
    - Search, Favorites, and Resume Playback position tracking.

---

## 🛠️ How to Build and Generate a Signed APK

### Method 1: Using Android Studio (Recommended)

1. Open **Android Studio** (Hedgehog, Iguana, or Koala+).
2. Click **Open** and select the `BT-Video-Player-Android` project root folder.
3. Wait for Gradle Sync to complete.
4. From the top menu, navigate to:
   **Build > Generate Signed Bundle / APK...**
5. Select **APK** and click **Next**.
6. Under **Key store path**:
   - If you have an existing keystore, choose it.
   - Otherwise, click **Create new...**, choose a path (e.g. `bt_release.jks`), enter password and alias details, then click **OK**.
7. Select **release** under Build Variants.
8. Check **V1 (Jar Signature)** and **V2 (Full APK Signature)**.
9. Click **Finish**. Your signed release APK will be generated at:
   `app/build/outputs/apk/release/app-release.apk`

---

### Method 2: Using Command Line (Terminal)

1. Ensure JDK 17+ is installed (`java -version`).
2. Run the automated script:
   ```bash
   Install Gradle 8.6+ and run `gradle --no-daemon assembleDebug`
   ```
3. Or run `gradle --no-daemon assembleDebug` from the project root. This ZIP does not contain a genuine Gradle Wrapper JAR, so `./gradlew` is not a usable wrapper.


## Important build/signing notes
- This ZIP did not contain `gradle-wrapper.jar`; use Android Studio Gradle Sync or install Gradle 8.6+.
- The included GitHub Actions workflow builds a debug APK and uploads it as an artifact.
- The release build is intentionally not signed with the public Android debug key. Use Android Studio's **Generate Signed Bundle / APK** wizard and keep your own keystore private.
- The original ZIP's shell script contained a hard-coded, predictable keystore password. It has been replaced with a script that only builds a debug APK and does not create or expose signing credentials.


## Build verification notes
- The uploaded ZIP did not include `gradle-wrapper.jar`; its original `gradlew` was only a thin call to a locally installed `gradle` command. Android Studio Gradle Sync or the included GitHub Actions workflow can supply/use Gradle 8.7.
- The original release build selected the debug signing key, which is not appropriate for publishing. This was removed. Use Android Studio's Generate Signed Bundle / APK wizard with your own private keystore.
- The original signing shell script contained a hard-coded keystore password. It has been replaced with a debug-build-only script.
- MainActivity's Compose UI now collects its StateFlows so library/player state changes trigger recomposition.
