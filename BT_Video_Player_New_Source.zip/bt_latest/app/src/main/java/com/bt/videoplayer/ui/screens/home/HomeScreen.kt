package com.bt.videoplayer.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.FavoriteBorder
import com.bt.videoplayer.ui.icons.BTPlayerIcons
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.bt.videoplayer.ads.ConsentAndAdsManager
import com.bt.videoplayer.ads.HomeAdMobBannerBar
import com.bt.videoplayer.domain.model.FolderItem
import com.bt.videoplayer.domain.model.VideoItem
import com.bt.videoplayer.player.controller.PlayerController
import com.bt.videoplayer.ui.theme.CyanAccent
import com.bt.videoplayer.ui.theme.DarkBg
import com.bt.videoplayer.ui.theme.DarkCard
import com.bt.videoplayer.ui.theme.DarkSurface
import com.bt.videoplayer.ui.theme.OrangeAccent
import com.bt.videoplayer.ui.theme.TextMuted
import com.bt.videoplayer.ui.theme.TextPrimary
import com.bt.videoplayer.ui.theme.TextSecondary

enum class HomeTab(val label: String) {
    FOLDERS("Folders"),
    VIDEOS("All Videos"),
    FAVORITES("Favorites"),
    RECENT("Recent")
}

enum class SortMode(val label: String) {
    DATE_DESC("Newest First"),
    DATE_ASC("Oldest First"),
    NAME_ASC("Name (A-Z)"),
    SIZE_DESC("Largest Size"),
    DURATION_DESC("Longest Duration")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    videos: List<VideoItem>,
    folders: List<FolderItem>,
    playerController: PlayerController,
    consentManager: ConsentAndAdsManager,
    showFloatingMiniPlayer: Boolean,
    onCloseMiniPlayer: () -> Unit,
    onVideoClick: (VideoItem, List<VideoItem>) -> Unit,
    onResumeFullScreenPlayer: () -> Unit,
    onOpenSafVideoPicker: () -> Unit,
    onToggleFavorite: (VideoItem) -> Unit,
    onRefresh: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(HomeTab.FOLDERS) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }
    var isGridView by remember { mutableStateOf(false) }
    var sortMode by remember { mutableStateOf(SortMode.DATE_DESC) }
    var showSortMenu by remember { mutableStateOf(false) }
    var selectedFolder by remember { mutableStateOf<String?>(null) }

    val activeVideo by playerController.currentVideo.collectAsState()
    val isPlaying by playerController.isPlaying.collectAsState()
    val displayedPositionMs by playerController.displayedPositionMs.collectAsState()
    val effectiveDurationMs by playerController.effectiveDurationMs.collectAsState()

    val filteredVideos = remember(videos, selectedTab, selectedFolder, searchQuery, sortMode) {
        var list = when (selectedTab) {
            HomeTab.FOLDERS -> {
                if (selectedFolder != null) {
                    videos.filter { it.folderName == selectedFolder }
                } else {
                    videos
                }
            }
            HomeTab.VIDEOS -> videos
            HomeTab.FAVORITES -> videos.filter { it.isFavorite }
            HomeTab.RECENT -> videos.filter { it.lastPositionMs > 0L }
        }

        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                    it.displayName.lowercase().contains(q) ||
                    it.folderName.lowercase().contains(q)
            }
        }

        when (sortMode) {
            SortMode.DATE_DESC -> list.sortedByDescending { it.dateAddedSec }
            SortMode.DATE_ASC -> list.sortedBy { it.dateAddedSec }
            SortMode.NAME_ASC -> list.sortedBy { it.title.lowercase() }
            SortMode.SIZE_DESC -> list.sortedByDescending { it.sizeBytes }
            SortMode.DURATION_DESC -> list.sortedByDescending { it.durationMs }
        }
    }

    Scaffold(
        topBar = {
            Column(modifier = Modifier.background(DarkSurface)) {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkSurface,
                        titleContentColor = TextPrimary
                    ),
                    title = {
                        if (isSearchActive) {
                            TextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Search videos...", color = TextMuted) },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    cursorColor = CyanAccent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CyanAccent),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "BT Logo",
                                        tint = DarkBg,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "BT Video Player",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "${videos.size} videos available",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            isSearchActive = !isSearchActive
                            if (!isSearchActive) searchQuery = ""
                        }) {
                            Icon(
                                imageVector = if (isSearchActive) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "Search",
                                tint = CyanAccent
                            )
                        }

                        IconButton(onClick = onOpenSafVideoPicker) {
                            Icon(
                                imageVector = BTPlayerIcons.FolderOpen,
                                contentDescription = "Open External File (SAF)",
                                tint = TextSecondary
                            )
                        }

                        IconButton(onClick = { isGridView = !isGridView }) {
                            Icon(
                                imageVector = if (isGridView) BTPlayerIcons.ViewList else BTPlayerIcons.GridView,
                                contentDescription = "Toggle View",
                                tint = TextSecondary
                            )
                        }

                        Box {
                            IconButton(onClick = { showSortMenu = true }) {
                                Icon(
                                    imageVector = BTPlayerIcons.Sort,
                                    contentDescription = "Sort",
                                    tint = TextSecondary
                                )
                            }
                            DropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false },
                                modifier = Modifier.background(DarkCard)
                            ) {
                                SortMode.entries.forEach { mode ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = mode.label,
                                                color = if (sortMode == mode) CyanAccent else TextPrimary
                                            )
                                        },
                                        onClick = {
                                            sortMode = mode
                                            showSortMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        IconButton(onClick = onRefresh) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = TextSecondary
                            )
                        }
                    }
                )

                TabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = DarkSurface,
                    contentColor = CyanAccent,
                    divider = {}
                ) {
                    HomeTab.entries.forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = {
                                selectedTab = tab
                                selectedFolder = null
                            },
                            text = {
                                Text(
                                    text = tab.label,
                                    fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == tab) CyanAccent else TextSecondary
                                )
                            }
                        )
                    }
                }
            }
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Non-intrusive Home AdMob / UMP Banner
                HomeAdMobBannerBar(consentManager = consentManager)
            }
        },
        containerColor = DarkBg
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (selectedTab == HomeTab.FOLDERS && selectedFolder == null) {
                FolderList(
                    folders = folders,
                    onFolderClick = { folder ->
                        selectedFolder = folder.name
                    }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    if (selectedFolder != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkCard)
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { selectedFolder = null },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to folders",
                                    tint = CyanAccent
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = BTPlayerIcons.Folder,
                                contentDescription = null,
                                tint = OrangeAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = selectedFolder.orEmpty(),
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${filteredVideos.size} items",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    if (filteredVideos.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = BTPlayerIcons.VideoFile,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "No videos found",
                                    color = TextSecondary,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    } else if (isGridView) {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 160.dp),
                            contentPadding = PaddingValues(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredVideos, key = { it.id }) { video ->
                                VideoGridItem(
                                    video = video,
                                    onClick = { onVideoClick(video, filteredVideos) },
                                    onFavoriteClick = { onToggleFavorite(video) }
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(vertical = 8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredVideos, key = { it.id }) { video ->
                                VideoListItem(
                                    video = video,
                                    onClick = { onVideoClick(video, filteredVideos) },
                                    onFavoriteClick = { onToggleFavorite(video) }
                                )
                            }
                        }
                    }
                }
            }
        
            // Draggable floating player over the folder/video list, not a fixed bottom bar.
            if (showFloatingMiniPlayer && activeVideo != null) {
                FloatingFolderPlayer(
                    video = activeVideo!!,
                    playerController = playerController,
                    isPlaying = isPlaying,
                    onExpand = onResumeFullScreenPlayer,
                    onClose = {
                        playerController.closeCurrentVideo()
                        onCloseMiniPlayer()
                    }
                )
            }
}
    }
}

@Composable
private fun MiniPlayerBar(
    video: VideoItem,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onExpand: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit
) {
    val progress = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkCard)
            .clickable { onExpand() }
    ) {
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp),
            color = CyanAccent,
            trackColor = DarkSurface
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CyanAccent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = video.displayName,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${VideoItem.formatTimestampMs(positionMs)} / ${VideoItem.formatTimestampMs(durationMs)}",
                    color = CyanAccent,
                    fontSize = 11.sp
                )
            }
            IconButton(onClick = onTogglePlayPause) {
                Icon(
                    imageVector = if (isPlaying) BTPlayerIcons.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = TextPrimary
                )
            }
            IconButton(onClick = onNext) {
                Icon(
                    imageVector = BTPlayerIcons.SkipNext,
                    contentDescription = "Next",
                    tint = TextPrimary
                )
            }
            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Pause Mini Player",
                    tint = TextSecondary
                )
            }
        }
    }
}

@Composable
fun FolderList(
    folders: List<FolderItem>,
    onFolderClick: (FolderItem) -> Unit
) {
    if (folders.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "No video folders found", color = TextSecondary)
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(folders, key = { it.path }) { folder ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onFolderClick(folder) },
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(DarkSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = BTPlayerIcons.Folder,
                            contentDescription = null,
                            tint = OrangeAccent,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = folder.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${folder.videoCount} videos • ${folder.path}",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Icon(
                        imageVector = BTPlayerIcons.ChevronRight,
                        contentDescription = "Open",
                        tint = TextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun VideoListItem(
    video: VideoItem,
    onClick: () -> Unit,
    onFavoriteClick: () -> Unit
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(110.dp)
                    .height(68.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(video.uri)
                        .videoFrameMillis(1000)
                        .crossfade(true)
                        .build(),
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.8f))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = video.formattedDuration,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyanAccent.copy(alpha = 0.9f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = video.resolutionLabel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkBg
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = video.displayName,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = TextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = video.folderName,
                        fontSize = 11.sp,
                        color = CyanAccent
                    )
                    Text(
                        text = " • ${video.formattedSize}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
                if (video.lastPositionMs > 0L) {
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = {
                            (video.lastPositionMs.toFloat() / video.durationMs.coerceAtLeast(1L).toFloat())
                                .coerceIn(0f, 1f)
                        },
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = CyanAccent,
                        trackColor = Color.DarkGray
                    )
                }
            }

            IconButton(onClick = onFavoriteClick) {
                Icon(
                    imageVector = if (video.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (video.isFavorite) Color.Red else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun VideoGridItem(
    video: VideoItem,
    onClick: () -> Unit,
    onFavoriteClick: () -> Unit
) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(video.uri)
                        .videoFrameMillis(1000)
                        .crossfade(true)
                        .build(),
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.8f))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = video.formattedDuration,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyanAccent.copy(alpha = 0.9f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = video.resolutionLabel,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = DarkBg
                    )
                }
            }

            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = video.displayName,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = video.formattedSize,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                    IconButton(
                        onClick = onFavoriteClick,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (video.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (video.isFavorite) Color.Red else TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}


@Composable
private fun FloatingFolderPlayer(
    video: VideoItem,
    playerController: PlayerController,
    isPlaying: Boolean,
    onExpand: () -> Unit,
    onClose: () -> Unit
) {
    val engine by playerController.activeEngineType.collectAsState()
    var x by remember(video.id) { mutableStateOf(0f) }
    var y by remember(video.id) { mutableStateOf(0f) }
    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.TopEnd
    ) {
        Column(
            modifier = Modifier
                .padding(end = 12.dp, top = 8.dp)
                .offset { androidx.compose.ui.unit.IntOffset(x.toInt(), y.toInt()) }
                .width(220.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(DarkCard)
                .pointerInput(video.id) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        x += drag.x
                        y += drag.y
                    }
                }
        ) {
            if (engine == com.bt.videoplayer.domain.model.EngineType.MEDIA3) {
                var miniPlayerView by remember(video.id) { mutableStateOf<androidx.media3.ui.PlayerView?>(null) }
                androidx.compose.runtime.DisposableEffect(video.id, engine) {
                    onDispose {
                        miniPlayerView?.player = null
                        playerController.onSurfaceDestroyed(com.bt.videoplayer.domain.model.EngineType.MEDIA3)
                    }
                }
                androidx.compose.ui.viewinterop.AndroidView(
                    factory = { context ->
                        androidx.media3.ui.PlayerView(context).apply {
                            useController = false
                            player = playerController.media3ExoPlayer
                            miniPlayerView = this
                        }
                    },
                    update = {
                        if (it.player !== playerController.media3ExoPlayer) {
                            it.player = playerController.media3ExoPlayer
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(120.dp).clickable { onExpand() }
                )
            } else {
                androidx.compose.ui.viewinterop.AndroidView(
                    factory = { context ->
                        android.widget.FrameLayout(context).apply {
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            val videoSurface = android.view.SurfaceView(context).apply {
                                layoutParams = android.widget.FrameLayout.LayoutParams(
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.Gravity.CENTER
                                )
                                holder.addCallback(object : android.view.SurfaceHolder.Callback {
                                    override fun surfaceCreated(holder: android.view.SurfaceHolder) {
                                        playerController.onVlcSurfaceCreated(this@apply, width, height)
                                    }
                                    override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {
                                        playerController.onSurfaceSizeChanged(width, height)
                                    }
                                    override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {
                                        playerController.onSurfaceDestroyed(com.bt.videoplayer.domain.model.EngineType.VLC)
                                    }
                                })
                            }
                            addView(videoSurface)
                        }
                    },
                    update = { container ->
                        if (container.width > 0 && container.height > 0) {
                            playerController.onSurfaceSizeChanged(container.width, container.height)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(120.dp).clickable { onExpand() }
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(video.displayName, modifier = Modifier.weight(1f).clickable { onExpand() }.padding(6.dp), color = Color.White, maxLines = 1)
                IconButton(onClick = { playerController.togglePlayPause() }) {
                    Icon(if (isPlaying) BTPlayerIcons.Pause else Icons.Default.PlayArrow, contentDescription = "Play or pause", tint = Color.White)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Stop and close", tint = Color.White)
                }
            }
        }
    }
}
