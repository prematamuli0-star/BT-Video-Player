BT Video Player – In-App Floating Mini Player Update

Changes in this source update:
1. Removed the two-step landscape-to-portrait player back flow. Back from the full player now exits directly to the Home/Folders screen.
2. Full player launches in landscape orientation. Returning to Home restores unspecified orientation so the folder screen can use portrait.
3. Added an explicit showFloatingMiniPlayer state. The mini player is shown only after leaving the full player; it no longer appears merely because a video is loaded.
4. Selecting a video or expanding the mini player hides the mini player and opens the full player.
5. Closing the mini player stops playback and hides the mini player.
6. Floating mini player is positioned near the top of the folder content, can be dragged, and has Play/Pause and Close controls.
7. Added a real LibVLC SurfaceView in the floating mini player instead of the old placeholder text.
8. Added Media3 PlayerView detachment when the mini-player composable is removed, to improve surface handoff when expanding back to full screen.
9. Removed the full-player control that switched the app into a portrait player layout.

Important validation note:
- Gradle build was attempted with ./gradlew --version but the wrapper could not download Gradle 8.7 because services.gradle.org was unreachable (UnknownHostException).
- Therefore this source ZIP has not been compiled or tested on a physical Android device. Verify Media3 and VLC surface handoff, Back navigation, play/pause, expand and close on device before release.
