# BT Video Player - Native Android Video Player

**BT Video Player** is a production-ready, feature-packed native Android video player application built with **Kotlin**, **Jetpack Compose**, and **AndroidX Media3 ExoPlayer**, inspired by the sleek dark UI of MX Player.

---

## Key Features

1. **Android 8.0+ Support**: Fully compatible with Android 8.0 (API 26) through Android 14+ (API 34).
2. **AndroidX Media3 ExoPlayer**: High-performance hardware-accelerated playback engine.
3. **MX Player-Inspired Dark UI**:
   - Modern dark theme (`#0B0E14`) with neon cyan accents (`#00E5FF`).
   - Clean folder card grid view and detailed video list view.
   - Video resolution badges (4K, 1080p, 720p, SD), file sizes, and duration tags.
4. **Full-Screen Video Playback**:
   - Aspect ratio modes: **Fit to Screen**, **Crop to Fill**, **Stretch**, **16:9**, **4:3**.
   - No unnecessary black bars; eliminates letterboxing when zoomed.
5. **Floating Transparent Controls**:
   - Translucent gradient scrims that smoothly fade in/out on tap.
   - Auto-hides controls after 4 seconds of idle playback.
   - Screen Lock button to prevent accidental touches.
6. **Playback Controls**:
   - Play / Pause, Previous, Next.
   - **5-second Rewind** (`<< 5s`) and **15-second Fast-Forward** (`15s >>`).
   - Smooth scrubber seek bar with buffered position indicator.
7. **Playback Speed Control**:
   - Change speed from **0.5x to 2.0x** (0.5x, 0.75x, 1.0x, 1.25x, 1.5x, 1.75x, 2.0x) with pitch preservation.
8. **Subtitles Support**:
   - Internal subtitle track selection (embedded SRT/VTT/ASS).
   - **External subtitle loader**: Pick any external subtitle file (`.srt`, `.vtt`) from device storage via Storage Access Framework.
9. **Touch Gestures**:
   - **Pinch-to-zoom**: Zoom in/out from 1.0x to 4.0x with smooth pan.
   - **Left vertical swipe**: Adjust screen brightness with HUD indicator.
   - **Right vertical swipe**: Adjust media volume with HUD indicator.
   - **Horizontal swipe**: Scrub and seek through video.
   - **Double-tap**: Double-tap left to rewind 5s; double-tap right to forward 15s.
10. **Picture-in-Picture (PiP)**:
    - Floating video window with resize and close support.
    - Automatically enters PiP mode when returning to the Home Screen (`onUserLeaveHint()`).
    - Seamless playback continuation without pauses or glitches.
11. **Media Library Browsing**:
    - Automatic MediaStore scanning for all device videos.
    - Group by **Folders** (Camera, Downloads, Movies, etc.).
    - Instant live **Search** filtering by title and folder name.
    - **Favorites**: Star videos to store them in your persistent Favorites list.
    - Sorting by Date Added, Name, File Size, and Duration.
12. **Permissions & Lifecycle**:
    - Handles `READ_MEDIA_VIDEO` on Android 13+ and `READ_EXTERNAL_STORAGE` on Android 8-12.
    - Safe system insets for camera punch holes, cutouts, and navigation bars.

---

## Project Structure

```
BTVideoPlayer/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/btvideoplayer/
│       │   ├── BTVideoPlayerApp.kt
│       │   ├── MainActivity.kt
│       │   ├── data/
│       │   │   ├── model/
│       │   │   │   ├── VideoItem.kt
│       │   │   │   ├── VideoFolder.kt
│       │   │   │   ├── SubtitleTrackInfo.kt
│       │   │   │   └── AudioTrackInfo.kt
│       │   │   └── repository/
│       │   │       ├── VideoRepository.kt
│       │   │       └── FavoritesRepository.kt
│       │   ├── ui/
│       │   │   ├── theme/
│       │   │   │   ├── Color.kt
│       │   │   │   ├── Theme.kt
│       │   │   │   └── Type.kt
│       │   │   ├── navigation/
│       │   │   │   └── Screen.kt
│       │   │   ├── home/
│       │   │   │   ├── HomeScreen.kt
│       │   │   │   ├── HomeViewModel.kt
│       │   │   │   └── components/
│       │   │   │       ├── VideoCard.kt
│       │   │   │       ├── FolderCard.kt
│       │   │   │       └── SearchBar.kt
│       │   │   └── player/
│       │   │       ├── PlayerScreen.kt
│       │   │       ├── PlayerViewModel.kt
│       │   │       ├── PlayerControls.kt
│       │   │       └── components/
│       │   │           ├── PlayerGestures.kt
│       │   │           ├── GestureHud.kt
│       │   │           ├── SpeedSelectionDialog.kt
│       │   │           ├── SubtitleDialog.kt
│       │   │           ├── AudioTrackDialog.kt
│       │   │           └── PipActionReceiver.kt
│       │   └── util/
│       │       ├── TimeUtils.kt
│       │       ├── FileUtils.kt
│       │       └── SystemUiUtils.kt
│       └── res/
│           ├── drawable/
│           ├── mipmap-anydpi-v26/
│           └── values/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
└── gradlew.bat
```

---

## Instructions to Open & Run in Android Studio

1. **Extract or Open Project**:
   - Extract the project zip file or open the `BTVideoPlayer` directory.
   - Open **Android Studio** (Hedgehog, Iguana, Jellyfish, Koala, Ladybug or newer).
   - Select **File -> Open...** and choose the `BTVideoPlayer` root directory.
2. **Gradle Sync**:
   - Android Studio will automatically recognize the Gradle build files and prompt a Gradle Sync.
   - Click **Sync Project with Gradle Files**.
   - Requires JDK 17 (configured by default in modern Android Studio via `Settings -> Build, Execution, Deployment -> Build Tools -> Gradle -> Gradle JDK`).
3. **Run on Device or Emulator**:
   - Connect a physical Android device (via USB or WiFi) or start an Android Virtual Device (AVD).
   - Press **Run 'app'** (`Shift + F10` or the green play button).
   - Grant media/storage permissions when prompted to start playing videos!

---

## Instructions to Generate a Signed APK

### Method 1: Via Android Studio GUI (Recommended)

1. In Android Studio, go to the top menu and select:
   **Build -> Generate Signed Bundle / APK...**
2. Choose **APK** and click **Next**.
3. Under **Key store path**:
   - If you already have a keystore (`.jks` or `.keystore`), click **Choose existing...**.
   - To create a new one, click **Create new...**:
     - Choose a file path (e.g. `release-keystore.jks`).
     - Enter and confirm a strong password for the Keystore.
     - Under **Key**, enter an alias (e.g. `btvideoplayer-key`) and password.
     - Fill in your Certificate details (e.g., Name, Organization) and click **OK**.
4. Check **Remember passwords** if desired and click **Next**.
5. Select the **release** build variant.
6. Check both **V1 (Jar Signature)** and **V2 (Full APK Signature)** signature versions.
7. Click **Create** / **Finish**.
8. Android Studio will build the signed APK and display a notification with a **locate** link to the output directory:
   `app/release/app-release.apk`

---

### Method 2: Via Command Line (Gradle)

1. **Generate a Keystore file using `keytool`**:
   ```bash
   keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias btkey
   ```
2. **Configure Signing in `app/build.gradle.kts`**:
   Add the following inside the `android { ... }` block:
   ```kotlin
   signingConfigs {
       create("release") {
           storeFile = file("../release-key.jks")
           storePassword = System.getenv("KEYSTORE_PASSWORD") ?: "yourStorePassword"
           keyAlias = "btkey"
           keyPassword = System.getenv("KEY_PASSWORD") ?: "yourKeyPassword"
       }
   }
   buildTypes {
       release {
           isMinifyEnabled = true
           proguardFiles(
               getDefaultProguardFile("proguard-android-optimize.txt"),
               "proguard-rules.pro"
           )
           signingConfig = signingConfigs.getByName("release")
       }
   }
   ```
3. **Build the Release APK**:
   ```bash
   # On Linux / macOS:
   ./gradlew assembleRelease

   # On Windows:
   gradlew.bat assembleRelease
   ```
4. **Locate your Signed APK**:
   The generated signed APK will be located at:
   `app/build/outputs/apk/release/app-release.apk`


## Latest gesture update
- Long-press and drag on the left 30% of the player adjusts the app window brightness.
- Long-press and drag on the right 30% adjusts Android media volume.
- Long-press and drag horizontally through the center seeks continuously through the video.
- Brightness and volume HUDs appear as vertical bars at the corresponding screen edges while adjusting.
- The gesture HUD fades after the finger is released and interaction stops.

Build verification: this source update has not been compiled in this environment. The Gradle wrapper JAR is not included in this ZIP; use Android Studio or the repository's configured GitHub Actions build environment.
