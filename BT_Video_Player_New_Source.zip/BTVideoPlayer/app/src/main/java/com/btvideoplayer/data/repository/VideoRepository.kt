package com.btvideoplayer.data.repository

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.os.Build
import android.provider.MediaStore
import com.btvideoplayer.data.model.VideoFolder
import com.btvideoplayer.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class SortOption {
    DATE_DESC,
    DATE_ASC,
    NAME_ASC,
    NAME_DESC,
    SIZE_DESC,
    DURATION_DESC
}

class VideoRepository(private val context: Context) {

    suspend fun getAllVideos(sortOption: SortOption = SortOption.DATE_DESC): List<VideoItem> =
        withContext(Dispatchers.IO) {
            val videoList = mutableListOf<VideoItem>()
            val contentResolver: ContentResolver = context.contentResolver

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }

            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_MODIFIED,
                MediaStore.Video.Media.WIDTH,
                MediaStore.Video.Media.HEIGHT,
                MediaStore.Video.Media.BUCKET_ID,
                MediaStore.Video.Media.BUCKET_DISPLAY_NAME
            )

            val sortOrder = when (sortOption) {
                SortOption.DATE_DESC -> "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
                SortOption.DATE_ASC -> "${MediaStore.Video.Media.DATE_MODIFIED} ASC"
                SortOption.NAME_ASC -> "${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE ASC"
                SortOption.NAME_DESC -> "${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE DESC"
                SortOption.SIZE_DESC -> "${MediaStore.Video.Media.SIZE} DESC"
                SortOption.DURATION_DESC -> "${MediaStore.Video.Media.DURATION} DESC"
            }

            try {
                contentResolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                    val displayNameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                    val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    val dateModifiedCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                    val widthCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                    val heightCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                    val bucketIdCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_ID)
                    val bucketNameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val title = cursor.getString(titleCol) ?: ""
                        val displayName = cursor.getString(displayNameCol) ?: "Video"
                        val path = cursor.getString(dataCol) ?: ""
                        val duration = cursor.getLong(durationCol)
                        val size = cursor.getLong(sizeCol)
                        val dateModified = cursor.getLong(dateModifiedCol)
                        val width = cursor.getInt(widthCol)
                        val height = cursor.getInt(heightCol)
                        val bucketId = cursor.getString(bucketIdCol) ?: "unknown_folder"
                        val bucketName = cursor.getString(bucketNameCol) ?: "Internal Storage"

                        videoList.add(
                            VideoItem(
                                id = id,
                                title = title,
                                displayName = displayName,
                                path = path,
                                durationMs = duration,
                                sizeBytes = size,
                                dateModified = dateModified,
                                width = width,
                                height = height,
                                bucketId = bucketId,
                                bucketDisplayName = bucketName
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            videoList
        }

    fun groupVideosByFolder(videos: List<VideoItem>): List<VideoFolder> {
        val grouped = videos.groupBy { it.bucketId }
        return grouped.map { (bucketId, folderVideos) ->
            val firstVideo = folderVideos.firstOrNull()
            VideoFolder(
                id = bucketId,
                name = firstVideo?.bucketDisplayName ?: "Folder",
                videoCount = folderVideos.size,
                thumbnailUri = firstVideo?.contentUri,
                totalDurationMs = folderVideos.sumOf { it.durationMs },
                totalSizeBytes = folderVideos.sumOf { it.sizeBytes }
            )
        }.sortedBy { it.name.lowercase() }
    }
}
