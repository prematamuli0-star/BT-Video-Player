package com.btvideoplayer.data.model

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import com.btvideoplayer.util.FileUtils
import com.btvideoplayer.util.TimeUtils

data class VideoItem(
    val id: Long,
    val title: String,
    val displayName: String,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateModified: Long,
    val width: Int,
    val height: Int,
    val bucketId: String,
    val bucketDisplayName: String
) {
    val contentUri: Uri
        get() = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

    val formattedDuration: String
        get() = TimeUtils.formatDuration(durationMs)

    val formattedSize: String
        get() = FileUtils.formatFileSize(sizeBytes)

    val resolutionLabel: String
        get() = FileUtils.getResolutionLabel(width, height)
}
