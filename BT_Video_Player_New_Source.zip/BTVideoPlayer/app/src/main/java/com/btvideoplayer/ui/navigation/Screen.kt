package com.btvideoplayer.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Player : Screen("player/{initialVideoId}?folderId={folderId}") {
        fun createRoute(videoId: Long, folderId: String? = null): String {
            return if (folderId != null) {
                "player/$videoId?folderId=$folderId"
            } else {
                "player/$videoId"
            }
        }
    }
}
