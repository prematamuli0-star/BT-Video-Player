package com.btvideoplayer.ui.player

import android.app.Application
import android.net.Uri
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import com.btvideoplayer.data.model.AudioTrackInfo
import com.btvideoplayer.data.model.SubtitleTrackInfo
import com.btvideoplayer.data.model.VideoItem
import com.btvideoplayer.data.repository.VideoRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AspectRatioMode(val displayName: String, val resizeMode: Int) {
    FIT("Fit to Screen", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    ZOOM("Crop to Fill", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH("Stretch", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    RATIO_16_9("16:9", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    RATIO_4_3("4:3", AspectRatioFrameLayout.RESIZE_MODE_FIT)
}

data class PlayerUiState(
    val currentVideo: VideoItem? = null,
    val isPlaying: Boolean = false,
    val currentPosition: Long = 0L,
    val duration: Long = 0L,
    val bufferedPosition: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val aspectRatioMode: AspectRatioMode = AspectRatioMode.FIT,
    val isLocked: Boolean = false,
    val isControlsVisible: Boolean = true,
    val subtitleTracks: List<SubtitleTrackInfo> = emptyList(),
    val selectedSubtitleTrackIndex: Int = -1,
    val audioTracks: List<AudioTrackInfo> = emptyList(),
    val selectedAudioTrackIndex: Int = 0,
    val hudMessage: String? = null
)

@OptIn(UnstableApi::class)
class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val videoRepository = VideoRepository(application)
    val player: ExoPlayer = ExoPlayer.Builder(application).build()

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var videoPlaylist: List<VideoItem> = emptyList()
    private var currentIndex: Int = -1
    private var progressUpdateJob: Job? = null
    private var controlsHideJob: Job? = null

    init {
        setupPlayerListeners()
    }

    private fun setupPlayerListeners() {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.update { it.copy(isPlaying = isPlaying) }
                if (isPlaying) {
                    startProgressTracker()
                    scheduleControlsAutoHide()
                } else {
                    stopProgressTracker()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    _uiState.update {
                        it.copy(
                            duration = player.duration.coerceAtLeast(0L),
                            currentPosition = player.currentPosition.coerceAtLeast(0L)
                        )
                    }
                } else if (playbackState == Player.STATE_ENDED) {
                    playNext()
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                extractTracks(tracks)
            }
        })
    }

    fun initPlaylist(initialVideoId: Long, folderId: String?) {
        viewModelScope.launch {
            val all = videoRepository.getAllVideos()
            videoPlaylist = if (folderId != null) {
                all.filter { it.bucketId == folderId }
            } else {
                all
            }

            currentIndex = videoPlaylist.indexOfFirst { it.id == initialVideoId }
            if (currentIndex == -1 && videoPlaylist.isNotEmpty()) {
                currentIndex = 0
            }

            if (currentIndex in videoPlaylist.indices) {
                playVideoAtIndex(currentIndex)
            }
        }
    }

    private fun playVideoAtIndex(index: Int) {
        if (index !in videoPlaylist.indices) return
        currentIndex = index
        val video = videoPlaylist[index]

        _uiState.update {
            it.copy(
                currentVideo = video,
                currentPosition = 0L,
                duration = video.durationMs
            )
        }

        val mediaItem = MediaItem.fromUri(video.contentUri)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = true
    }

    private fun startProgressTracker() {
        progressUpdateJob?.cancel()
        progressUpdateJob = viewModelScope.launch {
            while (isActive) {
                _uiState.update {
                    it.copy(
                        currentPosition = player.currentPosition.coerceAtLeast(0L),
                        bufferedPosition = player.bufferedPosition.coerceAtLeast(0L),
                        duration = player.duration.coerceAtLeast(0L)
                    )
                }
                delay(500)
            }
        }
    }

    private fun stopProgressTracker() {
        progressUpdateJob?.cancel()
    }

    fun togglePlayPause() {
        if (player.isPlaying) {
            player.pause()
        } else {
            player.play()
        }
    }

    fun seekTo(positionMs: Long) {
        val clamped = positionMs.coerceIn(0L, player.duration.coerceAtLeast(0L))
        player.seekTo(clamped)
        _uiState.update { it.copy(currentPosition = clamped) }
        scheduleControlsAutoHide()
    }

    fun rewind5s() {
        seekTo(player.currentPosition - 5000L)
    }

    fun forward15s() {
        seekTo(player.currentPosition + 15000L)
    }

    fun playPrevious() {
        if (currentIndex > 0) {
            playVideoAtIndex(currentIndex - 1)
        } else if (videoPlaylist.isNotEmpty()) {
            playVideoAtIndex(videoPlaylist.size - 1)
        }
    }

    fun playNext() {
        if (currentIndex < videoPlaylist.size - 1) {
            playVideoAtIndex(currentIndex + 1)
        } else if (videoPlaylist.isNotEmpty()) {
            playVideoAtIndex(0)
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        val params = PlaybackParameters(speed)
        player.playbackParameters = params
        _uiState.update { it.copy(playbackSpeed = speed) }
    }

    fun cycleAspectRatio(): AspectRatioMode {
        val modes = AspectRatioMode.values()
        val nextIndex = (uiState.value.aspectRatioMode.ordinal + 1) % modes.size
        val nextMode = modes[nextIndex]
        _uiState.update { it.copy(aspectRatioMode = nextMode) }
        return nextMode
    }

    fun toggleControlsVisibility() {
        val next = !_uiState.value.isControlsVisible
        _uiState.update { it.copy(isControlsVisible = next) }
        if (next && player.isPlaying) {
            scheduleControlsAutoHide()
        }
    }

    fun scheduleControlsAutoHide() {
        controlsHideJob?.cancel()
        controlsHideJob = viewModelScope.launch {
            delay(4000)
            if (player.isPlaying) {
                _uiState.update { it.copy(isControlsVisible = false) }
            }
        }
    }

    fun toggleLock() {
        val newLock = !_uiState.value.isLocked
        _uiState.update { it.copy(isLocked = newLock, isControlsVisible = true) }
        if (!newLock) {
            scheduleControlsAutoHide()
        }
    }

    private fun extractTracks(tracks: Tracks) {
        val subList = mutableListOf<SubtitleTrackInfo>()
        val audioList = mutableListOf<AudioTrackInfo>()

        for (groupIndex in 0 until tracks.groups.size) {
            val group = tracks.groups[groupIndex]
            val trackType = group.type

            for (trackIndex in 0 until group.length) {
                val format = group.getTrackFormat(trackIndex)
                val isSelected = group.isTrackSelected(trackIndex)

                if (trackType == C.TRACK_TYPE_TEXT) {
                    val label = format.label ?: format.language ?: "Track ${subList.size + 1}"
                    subList.add(
                        SubtitleTrackInfo(
                            trackGroupIndex = groupIndex,
                            trackIndex = trackIndex,
                            language = format.language,
                            label = label,
                            isSelected = isSelected
                        )
                    )
                } else if (trackType == C.TRACK_TYPE_AUDIO) {
                    val label = format.label ?: format.language ?: "Audio ${audioList.size + 1}"
                    audioList.add(
                        AudioTrackInfo(
                            trackGroupIndex = groupIndex,
                            trackIndex = trackIndex,
                            language = format.language,
                            label = label,
                            channels = format.channelCount,
                            sampleRate = format.sampleRate,
                            isSelected = isSelected
                        )
                    )
                }
            }
        }

        val selectedSubIdx = subList.indexOfFirst { it.isSelected }
        val selectedAudioIdx = audioList.indexOfFirst { it.isSelected }.coerceAtLeast(0)

        _uiState.update {
            it.copy(
                subtitleTracks = subList,
                selectedSubtitleTrackIndex = selectedSubIdx,
                audioTracks = audioList,
                selectedAudioTrackIndex = selectedAudioIdx
            )
        }
    }

    fun selectSubtitleTrack(index: Int) {
        val parametersBuilder = player.trackSelectionParameters.buildUpon()
        if (index == -1) {
            // Disabled
            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else if (index in _uiState.value.subtitleTracks.indices) {
            val track = _uiState.value.subtitleTracks[index]
            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            val currentTracks = player.currentTracks
            if (track.trackGroupIndex in 0 until currentTracks.groups.size) {
                val group = currentTracks.groups[track.trackGroupIndex]
                parametersBuilder.setOverrideForType(
                    TrackSelectionOverride(group.mediaTrackGroup, listOf(track.trackIndex))
                )
            }
        }
        player.trackSelectionParameters = parametersBuilder.build()
        _uiState.update { it.copy(selectedSubtitleTrackIndex = index) }
    }

    fun selectAudioTrack(index: Int) {
        if (index !in _uiState.value.audioTracks.indices) return
        val track = _uiState.value.audioTracks[index]
        val parametersBuilder = player.trackSelectionParameters.buildUpon()
        val currentTracks = player.currentTracks
        if (track.trackGroupIndex in 0 until currentTracks.groups.size) {
            val group = currentTracks.groups[track.trackGroupIndex]
            parametersBuilder.setOverrideForType(
                TrackSelectionOverride(group.mediaTrackGroup, listOf(track.trackIndex))
            )
        }
        player.trackSelectionParameters = parametersBuilder.build()
        _uiState.update { it.copy(selectedAudioTrackIndex = index) }
    }

    fun loadExternalSubtitle(uri: Uri) {
        val video = _uiState.value.currentVideo ?: return
        val currentPos = player.currentPosition

        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(MimeTypes.APPLICATION_SUBRIP)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(video.contentUri)
            .setSubtitleConfigurations(listOf(subtitleConfig))
            .build()

        player.setMediaItem(mediaItem, currentPos)
        player.prepare()
        player.play()
    }

    override fun onCleared() {
        super.onCleared()
        stopProgressTracker()
        controlsHideJob?.cancel()
        player.release()
    }
}
