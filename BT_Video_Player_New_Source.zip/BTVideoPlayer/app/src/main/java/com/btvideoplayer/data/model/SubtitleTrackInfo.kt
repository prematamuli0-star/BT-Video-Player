package com.btvideoplayer.data.model

data class SubtitleTrackInfo(
    val trackGroupIndex: Int,
    val trackIndex: Int,
    val language: String?,
    val label: String,
    val isSelected: Boolean,
    val isExternal: Boolean = false,
    val uriString: String? = null
)
