package com.btvideoplayer.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.btvideoplayer.data.model.VideoFolder
import com.btvideoplayer.data.model.VideoItem
import com.btvideoplayer.data.repository.FavoritesRepository
import com.btvideoplayer.data.repository.SortOption
import com.btvideoplayer.data.repository.VideoRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HomeUiState(
    val selectedTab: Int = 0, // 0 = Folders, 1 = Videos, 2 = Favorites
    val selectedFolder: VideoFolder? = null,
    val searchQuery: String = "",
    val sortOption: SortOption = SortOption.DATE_DESC,
    val allVideos: List<VideoItem> = emptyList(),
    val folders: List<VideoFolder> = emptyList(),
    val favorites: Set<Long> = emptySet(),
    val isLoading: Boolean = false,
    val hasPermission: Boolean = false
) {
    val displayVideos: List<VideoItem>
        get() {
            var list = when {
                selectedFolder != null -> allVideos.filter { it.bucketId == selectedFolder.id }
                selectedTab == 2 -> allVideos.filter { favorites.contains(it.id) }
                else -> allVideos
            }
            if (searchQuery.isNotBlank()) {
                val q = searchQuery.trim().lowercase()
                list = list.filter {
                    it.displayName.lowercase().contains(q) ||
                            it.bucketDisplayName.lowercase().contains(q)
                }
            }
            return list
        }

    val displayFolders: List<VideoFolder>
        get() {
            if (searchQuery.isBlank()) return folders
            val q = searchQuery.trim().lowercase()
            return folders.filter { it.name.lowercase().contains(q) }
        }
}

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val videoRepository = VideoRepository(application)
    private val favoritesRepository = FavoritesRepository(application)

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            favoritesRepository.favoritesFlow.collect { favs ->
                _uiState.update { it.copy(favorites = favs) }
            }
        }
    }

    fun onPermissionResult(granted: Boolean) {
        _uiState.update { it.copy(hasPermission = granted) }
        if (granted) {
            loadVideos()
        }
    }

    fun loadVideos() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val videos = videoRepository.getAllVideos(_uiState.value.sortOption)
            val folders = videoRepository.groupVideosByFolder(videos)
            _uiState.update {
                it.copy(
                    allVideos = videos,
                    folders = folders,
                    isLoading = false
                )
            }
        }
    }

    fun setSelectedTab(tabIndex: Int) {
        _uiState.update { it.copy(selectedTab = tabIndex, selectedFolder = null) }
    }

    fun selectFolder(folder: VideoFolder?) {
        _uiState.update { it.copy(selectedFolder = folder) }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setSortOption(sortOption: SortOption) {
        _uiState.update { it.copy(sortOption = sortOption) }
        loadVideos()
    }

    fun toggleFavorite(videoId: Long) {
        favoritesRepository.toggleFavorite(videoId)
    }
}
