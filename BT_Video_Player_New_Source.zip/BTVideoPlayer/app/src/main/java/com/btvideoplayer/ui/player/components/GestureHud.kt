package com.btvideoplayer.ui.player.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.btvideoplayer.ui.theme.*

sealed class HudState {
    object Idle : HudState()
    data class Volume(val percent: Int) : HudState()
    data class Brightness(val percent: Int) : HudState()
    data class Seek(val targetTime: String, val deltaSeconds: Int) : HudState()
    data class Message(val text: String) : HudState()
}

@Composable
fun GestureHud(
    hudState: HudState,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        when (hudState) {
            is HudState.Volume -> EdgeControlBar(
                percent = hudState.percent,
                label = "VOLUME",
                isVolume = true,
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp)
            )
            is HudState.Brightness -> EdgeControlBar(
                percent = hudState.percent,
                label = "BRIGHTNESS",
                isVolume = false,
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 18.dp)
            )
            is HudState.Seek -> AnimatedVisibility(
                visible = true,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(ScrimDark.copy(alpha = 0.88f))
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (hudState.deltaSeconds >= 0) "+${hudState.deltaSeconds}s" else "${hudState.deltaSeconds}s",
                        style = Typography.titleLarge,
                        color = NeonCyan
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(hudState.targetTime, style = Typography.bodyLarge, color = TextPrimary)
                }
            }
            is HudState.Message -> Text(
                text = hudState.text,
                style = Typography.titleMedium,
                color = TextPrimary,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(ScrimDark)
                    .padding(16.dp)
            )
            HudState.Idle -> Unit
        }
    }
}

@Composable
private fun EdgeControlBar(
    percent: Int,
    label: String,
    isVolume: Boolean,
    modifier: Modifier = Modifier
) {
    val accent = NeonCyan
    Column(
        modifier = modifier
            .width(54.dp)
            .height(184.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xD9161A20))
            .padding(vertical = 13.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(if (isVolume) "🔊" else "☀", color = accent, style = Typography.titleMedium)
        Box(
            modifier = Modifier
                .weight(1f)
                .width(6.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(DarkSurfaceVariant),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight((percent / 100f).coerceIn(0.01f, 1f))
                    .clip(RoundedCornerShape(4.dp))
                    .background(accent)
            )
        }
        Text("${percent}%", color = TextPrimary, style = Typography.labelSmall)
    }
}
