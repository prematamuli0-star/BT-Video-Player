package com.btvideoplayer.ui.player.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.btvideoplayer.R
import com.btvideoplayer.data.model.SubtitleTrackInfo
import com.btvideoplayer.ui.theme.*

@Composable
fun SubtitleDialog(
    subtitleTracks: List<SubtitleTrackInfo>,
    selectedTrackIndex: Int,
    onTrackSelected: (Int) -> Unit,
    onLoadExternalSubtitle: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(
                text = stringResource(id = R.string.subtitles),
                style = Typography.titleMedium,
                color = TextPrimary
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Button to load external subtitle file (.srt, .vtt)
                OutlinedButton(
                    onClick = onLoadExternalSubtitle,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_subtitles),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = stringResource(id = R.string.load_external_subtitle))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Divider(color = DarkSurfaceVariant)

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    // Option: Off
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onTrackSelected(-1) }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedTrackIndex == -1,
                                onClick = { onTrackSelected(-1) },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = NeonCyan,
                                    unselectedColor = TextTertiary
                                )
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Off",
                                style = Typography.bodyLarge,
                                color = if (selectedTrackIndex == -1) NeonCyan else TextPrimary
                            )
                        }
                    }

                    // Available tracks
                    itemsIndexed(subtitleTracks) { index, track ->
                        val isSelected = selectedTrackIndex == index
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onTrackSelected(index) }
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { onTrackSelected(index) },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = NeonCyan,
                                    unselectedColor = TextTertiary
                                )
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = track.label,
                                    style = Typography.bodyLarge,
                                    color = if (isSelected) NeonCyan else TextPrimary
                                )
                                if (track.isExternal) {
                                    Text(
                                        text = "External File",
                                        style = Typography.labelSmall,
                                        color = AccentAmber
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Close", color = NeonCyan)
            }
        }
    )
}
