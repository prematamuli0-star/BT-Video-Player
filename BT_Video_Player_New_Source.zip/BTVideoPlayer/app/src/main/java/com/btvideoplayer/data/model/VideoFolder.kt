package com.btvideoplayer.data.model

import android.net.Uri

data class VideoFolder(
    val id: String,
    val name: String,
    val videoCount: Int,
    val thumbnailUri: Uri?,
    val totalDurationMs: Long,
    val totalSizeBytes: Long
)
