package com.btvideoplayer.data.model

data class AudioTrackInfo(
    val trackGroupIndex: Int,
    val trackIndex: Int,
    val language: String?,
    val label: String,
    val channels: Int,
    val sampleRate: Int,
    val isSelected: Boolean
)
