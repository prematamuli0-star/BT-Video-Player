package com.btvideoplayer.ui.player.components

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PipActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_PIP_CONTROL = "com.btvideoplayer.ACTION_PIP_CONTROL"
        const val EXTRA_CONTROL_TYPE = "extra_control_type"

        const val CONTROL_PLAY_PAUSE = 1
        const val CONTROL_REWIND = 2
        const val CONTROL_FORWARD = 3

        var onPipActionReceived: ((Int) -> Unit)? = null
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == ACTION_PIP_CONTROL) {
            val controlType = intent.getIntExtra(EXTRA_CONTROL_TYPE, 0)
            onPipActionReceived?.invoke(controlType)
        }
    }
}
