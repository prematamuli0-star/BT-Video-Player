package com.btvideoplayer.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FavoritesRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("bt_video_player_favorites", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val key = "favorite_video_ids"

    private val _favoritesFlow = MutableStateFlow<Set<Long>>(loadFavorites())
    val favoritesFlow: StateFlow<Set<Long>> = _favoritesFlow.asStateFlow()

    private fun loadFavorites(): Set<Long> {
        val json = prefs.getString(key, null) ?: return emptySet()
        return try {
            val type = object : TypeToken<Set<Long>>() {}.type
            gson.fromJson(json, type) ?: emptySet()
        } catch (e: Exception) {
            emptySet()
        }
    }

    private fun saveFavorites(ids: Set<Long>) {
        val json = gson.toJson(ids)
        prefs.edit().putString(key, json).apply()
        _favoritesFlow.value = ids
    }

    fun isFavorite(videoId: Long): Boolean {
        return _favoritesFlow.value.contains(videoId)
    }

    fun toggleFavorite(videoId: Long) {
        val current = _favoritesFlow.value.toMutableSet()
        if (current.contains(videoId)) {
            current.remove(videoId)
        } else {
            current.add(videoId)
        }
        saveFavorites(current)
    }
}
