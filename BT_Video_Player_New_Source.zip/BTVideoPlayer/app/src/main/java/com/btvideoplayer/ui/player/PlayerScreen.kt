package com.btvideoplayer.ui.player

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.view.ViewGroup
import android.view.WindowManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.btvideoplayer.ui.player.components.*
import com.btvideoplayer.ui.theme.DarkBackground
import com.btvideoplayer.util.SystemUiUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import com.btvideoplayer.util.TimeUtils

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    initialVideoId: Long,
    folderId: String?,
    onBackClick: () -> Unit,
    onEnterPip: () -> Unit,
    isInPipMode: Boolean,
    viewModel: PlayerViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val activity = context as? Activity
    val coroutineScope = rememberCoroutineScope()
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    val maxMediaVolume = remember(audioManager) {
        audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
    }
    val initialVolumePercent = remember(audioManager) {
        (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / maxMediaVolume).roundToInt()
    }
    val initialBrightnessPercent = remember(context) {
        val systemValue = runCatching {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        }.getOrDefault(128)
        (systemValue * 100f / 255f).roundToInt().coerceIn(1, 100)
    }
    var seekGestureDeltaSeconds by remember { mutableStateOf(0f) }

    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSubtitleDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var hudState by remember { mutableStateOf<HudState>(HudState.Idle) }

    // Pinch-to-zoom state
    var zoomScale by remember { mutableStateOf(1.0f) }
    var zoomOffset by remember { mutableStateOf(Offset.Zero) }

    // External Subtitle Picker launcher
    val subtitleFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.loadExternalSubtitle(uri)
            showSubtitleDialog = false
        }
    }

    // Initialize playlist
    LaunchedEffect(initialVideoId, folderId) {
        viewModel.initPlaylist(initialVideoId, folderId)
    }

    // Hide system bars for immersive video experience
    DisposableEffect(isInPipMode) {
        if (!isInPipMode && activity != null) {
            SystemUiUtils.hideSystemBars(activity)
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            if (activity != null) {
                SystemUiUtils.showSystemBars(activity)
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    fun showHud(state: HudState, autoHide: Boolean = true) {
        hudState = state
        if (autoHide) {
            coroutineScope.launch {
                delay(1500)
                if (hudState == state) hudState = HudState.Idle
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Player View Container with Zoom / Pan transform
        PlayerGestureDetector(
            isLocked = uiState.isLocked,
            onSingleTap = { viewModel.toggleControlsVisibility() },
            onDoubleTapLeft = {
                viewModel.rewind5s()
                showHud(HudState.Seek("Rewind 5s", -5))
            },
            onDoubleTapRight = {
                viewModel.forward15s()
                showHud(HudState.Seek("Forward 15s", 15))
            },
            onSeekDelta = { delta ->
                seekGestureDeltaSeconds += delta
                val target = viewModel.player.currentPosition + (delta * 1000f).toLong()
                viewModel.seekTo(target)
                showHud(
                    HudState.Seek(
                        TimeUtils.formatDuration(viewModel.player.currentPosition),
                        seekGestureDeltaSeconds.roundToInt()
                    ),
                    autoHide = false
                )
            },
            onSeekCommit = {
                seekGestureDeltaSeconds = 0f
                coroutineScope.launch {
                    delay(700)
                    hudState = HudState.Idle
                }
                viewModel.scheduleControlsAutoHide()
            },
            onVolumeChange = { percent ->
                val targetVolume = (maxMediaVolume * percent / 100f).roundToInt()
                    .coerceIn(0, maxMediaVolume)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, 0)
                showHud(HudState.Volume(percent), autoHide = false)
            },
            onBrightnessChange = { percent ->
                activity?.let { host ->
                    val attributes = host.window.attributes
                    attributes.screenBrightness = (percent / 100f).coerceIn(0.01f, 1f)
                    host.window.attributes = attributes
                }
                showHud(HudState.Brightness(percent), autoHide = false)
            },
            onZoomChange = { zoom, pan ->
                zoomScale = (zoomScale * zoom).coerceIn(1.0f, 4.0f)
                zoomOffset = if (zoomScale == 1.0f) Offset.Zero else zoomOffset + pan
            },
            initialVolumePercent = initialVolumePercent,
            initialBrightnessPercent = initialBrightnessPercent,
            modifier = Modifier.fillMaxSize()
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = viewModel.player
                        useController = false
                        resizeMode = uiState.aspectRatioMode.resizeMode
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { playerView ->
                    playerView.resizeMode = uiState.aspectRatioMode.resizeMode
                },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = zoomScale
                        scaleY = zoomScale
                        translationX = zoomOffset.x
                        translationY = zoomOffset.y
                    }
            )
        }

        // Gesture HUD Overlay
        GestureHud(
            hudState = hudState,
            modifier = Modifier.align(Alignment.Center)
        )

        // Player Controls Overlay (hidden in PiP mode)
        if (!isInPipMode) {
            PlayerControlsOverlay(
                isVisible = uiState.isControlsVisible,
                isLocked = uiState.isLocked,
                title = uiState.currentVideo?.displayName ?: "",
                isPlaying = uiState.isPlaying,
                currentPosition = uiState.currentPosition,
                duration = uiState.duration,
                bufferedPosition = uiState.bufferedPosition,
                playbackSpeed = uiState.playbackSpeed,
                aspectRatioName = uiState.aspectRatioMode.displayName,
                onBackClick = onBackClick,
                onPlayPauseClick = { viewModel.togglePlayPause() },
                onPreviousClick = { viewModel.playPrevious() },
                onNextClick = { viewModel.playNext() },
                onSeek = { viewModel.seekTo(it) },
                onToggleLock = {
                    viewModel.toggleLock()
                    showHud(
                        HudState.Message(
                            if (uiState.isLocked) "Screen Unlocked" else "Screen Locked"
                        )
                    )
                },
                onSpeedClick = { showSpeedDialog = true },
                onSubtitleClick = { showSubtitleDialog = true },
                onAudioTrackClick = { showAudioDialog = true },
                onAspectRatioClick = {
                    val mode = viewModel.cycleAspectRatio()
                    showHud(HudState.Message(mode.displayName))
                },
                onPipClick = onEnterPip,
                onRotateClick = {
                    if (activity != null) {
                        val currentOrientation = activity.requestedOrientation
                        val newOrientation = if (currentOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        } else {
                            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        }
                        activity.requestedOrientation = newOrientation
                    }
                }
            )
        }
    }

    // Dialogs
    if (showSpeedDialog) {
        SpeedSelectionDialog(
            currentSpeed = uiState.playbackSpeed,
            onSpeedSelected = {
                viewModel.setPlaybackSpeed(it)
                showSpeedDialog = false
                showHud(HudState.Message("${it}x Speed"))
            },
            onDismiss = { showSpeedDialog = false }
        )
    }

    if (showSubtitleDialog) {
        SubtitleDialog(
            subtitleTracks = uiState.subtitleTracks,
            selectedTrackIndex = uiState.selectedSubtitleTrackIndex,
            onTrackSelected = {
                viewModel.selectSubtitleTrack(it)
                showSubtitleDialog = false
            },
            onLoadExternalSubtitle = {
                subtitleFilePicker.launch(
                    arrayOf(
                        "text/*",
                        "application/x-subrip",
                        "application/octet-stream",
                        "*/*"
                    )
                )
            },
            onDismiss = { showSubtitleDialog = false }
        )
    }

    if (showAudioDialog) {
        AudioTrackDialog(
            audioTracks = uiState.audioTracks,
            selectedTrackIndex = uiState.selectedAudioTrackIndex,
            onTrackSelected = {
                viewModel.selectAudioTrack(it)
                showAudioDialog = false
            },
            onDismiss = { showAudioDialog = false }
        )
    }
}
