package com.btvideoplayer.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0B0E14)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF212833)
val DarkSurfaceHighlight = Color(0xFF30363D)

val NeonCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF3D7BF6)
val AccentPink = Color(0xFFFF4081)
val AccentAmber = Color(0xFFFFB300)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextTertiary = Color(0xFF6E7681)

val ScrimDark = Color(0xCC000000)
val ScrimLight = Color(0x66000000)
val Transparent = Color(0x00000000)
