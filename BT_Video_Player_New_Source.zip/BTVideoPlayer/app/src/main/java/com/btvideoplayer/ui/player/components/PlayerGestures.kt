package com.btvideoplayer.ui.player.components

import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs

@Composable
fun PlayerGestureDetector(
    isLocked: Boolean,
    onSingleTap: () -> Unit,
    onDoubleTapLeft: () -> Unit,
    onDoubleTapRight: () -> Unit,
    onSeekDelta: (Float) -> Unit,
    onSeekCommit: () -> Unit,
    onVolumeChange: (Int) -> Unit,
    onBrightnessChange: (Int) -> Unit,
    onZoomChange: (Float, Offset) -> Unit,
    initialVolumePercent: Int = 50,
    initialBrightnessPercent: Int = 50,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var dragDirection by remember { mutableStateOf<DragDirection?>(null) }
    var activeSide by remember { mutableStateOf(DragDirection.HORIZONTAL) }
    var volumePercent by remember { mutableStateOf(initialVolumePercent.coerceIn(0, 100)) }
    var brightnessPercent by remember { mutableStateOf(initialBrightnessPercent.coerceIn(1, 100)) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(isLocked) {
                if (!isLocked) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { offset ->
                            val width = size.width.toFloat().coerceAtLeast(1f)
                            activeSide = when {
                                offset.x < width * 0.30f -> DragDirection.VERTICAL_LEFT
                                offset.x > width * 0.70f -> DragDirection.VERTICAL_RIGHT
                                else -> DragDirection.HORIZONTAL
                            }
                            dragDirection = activeSide
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            when (activeSide) {
                                DragDirection.VERTICAL_LEFT -> {
                                    // Dragging upward raises brightness.
                                    val step = (-dragAmount.y / size.height * 100f).toInt()
                                    brightnessPercent = (brightnessPercent + step).coerceIn(1, 100)
                                    onBrightnessChange(brightnessPercent)
                                }
                                DragDirection.VERTICAL_RIGHT -> {
                                    // Dragging upward raises media volume.
                                    val step = (-dragAmount.y / size.height * 100f).toInt()
                                    volumePercent = (volumePercent + step).coerceIn(0, 100)
                                    onVolumeChange(volumePercent)
                                }
                                DragDirection.HORIZONTAL -> {
                                    // A full-width horizontal drag maps to about one minute of seeking.
                                    val deltaSeconds = dragAmount.x / size.width.coerceAtLeast(1) * 60f
                                    if (abs(deltaSeconds) >= 0.01f) onSeekDelta(deltaSeconds)
                                }
                            }
                        },
                        onDragEnd = {
                            dragDirection = null
                            onSeekCommit()
                        },
                        onDragCancel = {
                            dragDirection = null
                            onSeekCommit()
                        }
                    )
                }
            }
            .pointerInput(isLocked) {
                if (!isLocked) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        if (zoom != 1f || pan != Offset.Zero) onZoomChange(zoom, pan)
                    }
                }
            }
            .pointerInput(isLocked) {
                detectTapGestures(
                    onTap = { onSingleTap() },
                    onDoubleTap = { offset ->
                        if (offset.x < size.width / 2f) onDoubleTapLeft() else onDoubleTapRight()
                    }
                )
            }
    ) {
        content()
    }
}

enum class DragDirection {
    HORIZONTAL,
    VERTICAL_LEFT,
    VERTICAL_RIGHT
}
