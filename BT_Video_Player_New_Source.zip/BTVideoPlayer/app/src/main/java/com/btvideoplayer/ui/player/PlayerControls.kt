package com.btvideoplayer.ui.player

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btvideoplayer.R
import com.btvideoplayer.ui.theme.*
import com.btvideoplayer.util.TimeUtils

@Composable
fun PlayerControlsOverlay(
    isVisible: Boolean,
    isLocked: Boolean,
    title: String,
    isPlaying: Boolean,
    currentPosition: Long,
    duration: Long,
    bufferedPosition: Long,
    playbackSpeed: Float,
    aspectRatioName: String,
    onBackClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleLock: () -> Unit,
    onSpeedClick: () -> Unit,
    onSubtitleClick: () -> Unit,
    onAudioTrackClick: () -> Unit,
    onAspectRatioClick: () -> Unit,
    onPipClick: () -> Unit,
    onRotateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {

        // When locked, only show floating unlock button
        if (isLocked) {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 24.dp)
            ) {
                IconButton(
                    onClick = onToggleLock,
                    modifier = Modifier
                        .size(52.dp)
                        .background(ScrimDark, CircleShape)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_lock),
                        contentDescription = "Unlock",
                        tint = NeonCyan,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
            return
        }

        // Full Controls Overlay
        AnimatedVisibility(
            visible = isVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {

                // Top Floating Bar with Dark Gradient Scrim
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(ScrimDark, Transparent)
                            )
                        )
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_arrow_back),
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }

                        Text(
                            text = title,
                            style = Typography.titleMedium.copy(fontWeight = FontWeight.Medium),
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp)
                        )

                        // Audio Track Selector
                        IconButton(onClick = onAudioTrackClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_audio_language),
                                contentDescription = "Audio Language",
                                tint = TextPrimary
                            )
                        }

                        // Subtitles Selector
                        IconButton(onClick = onSubtitleClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_subtitles),
                                contentDescription = "Subtitles",
                                tint = TextPrimary
                            )
                        }

                        // Playback speed selector
                        IconButton(onClick = onSpeedClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_speed),
                                contentDescription = "Playback speed ${playbackSpeed}x",
                                tint = TextPrimary
                            )
                        }

                        // Aspect Ratio Toggle
                        IconButton(onClick = onAspectRatioClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_aspect_ratio),
                                contentDescription = "Aspect Ratio: $aspectRatioName",
                                tint = NeonCyan
                            )
                        }

                        // Picture in Picture
                        IconButton(onClick = onPipClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_pip),
                                contentDescription = "Picture in Picture",
                                tint = TextPrimary
                            )
                        }

                        // Lock controls (kept in the top bar, as in the reference)
                        IconButton(onClick = onToggleLock) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_lock_open),
                                contentDescription = "Lock Controls",
                                tint = TextPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                // Bottom Floating Controls with a subtle transparent gradient
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Transparent,
                                    ScrimDark.copy(alpha = 0.18f)
                                )
                            )
                        )
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    // Time Labels & Scrubber
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = TimeUtils.formatDuration(currentPosition),
                            style = Typography.bodyMedium.copy(fontSize = 12.sp),
                            color = TextPrimary
                        )

                        Slider(
                            value = currentPosition.toFloat(),
                            onValueChange = { onSeek(it.toLong()) },
                            valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)),
                            colors = SliderDefaults.colors(
                                thumbColor = NeonCyan,
                                activeTrackColor = NeonCyan,
                                inactiveTrackColor = DarkSurfaceHighlight
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 10.dp)
                        )

                        Text(
                            text = TimeUtils.formatDuration(duration),
                            style = Typography.bodyMedium.copy(fontSize = 12.sp),
                            color = TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Simplified, evenly spaced playback controls.
                    // Rewind/forward buttons are removed; long-press swipe seeking remains available.
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        IconButton(onClick = onPreviousClick, modifier = Modifier.size(48.dp)) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_skip_previous),
                                contentDescription = "Previous Video",
                                tint = TextPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        IconButton(
                            onClick = onPlayPauseClick,
                            modifier = Modifier
                                .size(64.dp)
                                .background(NeonCyan, CircleShape)
                        ) {
                            Icon(
                                painter = painterResource(
                                    id = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                                ),
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = DarkBackground,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        IconButton(onClick = onNextClick, modifier = Modifier.size(48.dp)) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_skip_next),
                                contentDescription = "Next Video",
                                tint = TextPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        IconButton(onClick = onRotateClick, modifier = Modifier.size(48.dp)) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_screen_rotation),
                                contentDescription = "Rotate",
                                tint = TextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
