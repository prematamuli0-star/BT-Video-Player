package com.btvideoplayer

import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.btvideoplayer.ui.home.HomeScreen
import com.btvideoplayer.ui.navigation.Screen
import com.btvideoplayer.ui.player.PlayerScreen
import com.btvideoplayer.ui.player.components.PipActionReceiver
import com.btvideoplayer.ui.theme.BTVideoPlayerTheme
import com.btvideoplayer.ui.theme.DarkBackground

class MainActivity : ComponentActivity() {

    private var isInPipMode by mutableStateOf(false)
    private var isPlayingVideo by mutableStateOf(false)
    private var isPlayerScreenActive by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup PiP Action Receiver
        PipActionReceiver.onPipActionReceived = { controlType ->
            // Broadcast handled in player
        }

        setContent {
            BTVideoPlayerTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    val navController = rememberNavController()

                    NavHost(
                        navController = navController,
                        startDestination = Screen.Home.route
                    ) {
                        composable(Screen.Home.route) {
                            isPlayerScreenActive = false
                            HomeScreen(
                                onVideoClick = { videoId, folderId ->
                                    isPlayerScreenActive = true
                                    navController.navigate(Screen.Player.createRoute(videoId, folderId))
                                }
                            )
                        }

                        composable(
                            route = Screen.Player.route,
                            arguments = listOf(
                                navArgument("initialVideoId") { type = NavType.LongType },
                                navArgument("folderId") {
                                    type = NavType.StringType
                                    nullable = true
                                }
                            )
                        ) { backStackEntry ->
                            isPlayerScreenActive = true
                            val initialVideoId = backStackEntry.arguments?.getLong("initialVideoId") ?: 0L
                            val folderId = backStackEntry.arguments?.getString("folderId")

                            PlayerScreen(
                                initialVideoId = initialVideoId,
                                folderId = folderId,
                                onBackClick = {
                                    isPlayerScreenActive = false
                                    navController.popBackStack()
                                },
                                onEnterPip = { enterPipMode() },
                                isInPipMode = isInPipMode
                            )
                        }
                    }
                }
            }
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            val aspectRatio = Rational(16, 9)
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(aspectRatio)
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Automatically enter PiP when returning to home screen if player is active
        if (isPlayerScreenActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPipMode()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipMode = isInPictureInPictureMode
    }
}
