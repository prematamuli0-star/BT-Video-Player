BT Video Player 2.0 - scoped source audit

Base: uploaded android_v2 project ZIP (83 entries). Original uploaded ZIP was not modified.

Changes in this audited copy:
1. Media3 seek completion is no longer inferred from STATE_READY. It is acknowledged from the explicit seek position-discontinuity callback, including when the player is buffering.
2. Media3 timeline readiness now means STATE_READY only. A finite metadata duration no longer overrides the engine's actual isCurrentMediaItemSeekable result.
3. Media3 rejects a seek on a READY timeline explicitly marked unseekable, instead of treating metadata duration as proof of seekability.
4. LibVLC no longer reports prepare success immediately after assigning Media. It waits for asynchronous Playing/Paused events before reporting a ready timeline.
5. LibVLC now fails clearly if neither a usable VideoItem URI nor a path-derived URI can be created; it does not silently continue with no media.
6. LibVLC initial resume seeking waits for playback readiness/seekability and retries briefly instead of issuing setTime immediately after play().
7. LibVLC seek completion is asynchronous: it waits for a TimeChanged event near the requested target and no longer reports success from the pre-seek player.time value.
8. LibVLC uses accurate (fast=false) seeking to reduce keyframe drift on high-bitrate files.
9. VLC surface attachment state is set by the IVLCVout surface-created callback, not optimistically immediately after attachViews().
10. SeekController ignores seek completion/failure callbacks from an engine that is no longer active.

Not verified:
- Full Gradle build / APK assembly (Gradle distribution and Android dependencies are not available offline in this environment).
- Android runtime behavior, actual device decoder support, surface lifecycle, PiP, and large MKV seeking.
- VLC seek event timing/tolerance across all container types and Android devices.

No UI, package name, minSdk, targetSdk, dependency versions, ABI filters, Ads, folder repository, or unrelated app features were intentionally changed.

Build tooling note:
- Added a Windows gradlew.bat launcher so the project can invoke the included Gradle wrapper on Windows.
- Marked the POSIX gradlew launcher executable in the exported ZIP.
- A local test invocation was attempted, but the wrapper could not download Gradle 8.7 because this environment has no network access (UnknownHostException: services.gradle.org). This is an environment limitation, not a verified source compilation result.

11. Added a BT Video Player launcher icon set (adaptive icon for Android 8.0+ plus legacy density PNGs).
12. Added a full BT All Format Player logo drawable at res/drawable-nodpi/bt_player_logo.png.
13. Removed forced constant-bitrate seeking from Media3. CBR seeking remains enabled only when the extractor can identify a CBR stream. Forcing it for arbitrary MKV/MP4 files can produce incorrect byte-offset calculations and cause seeks to jump to the wrong position or restart.
14. Kept Media3's CLOSEST_SYNC seek policy so playback resumes at a valid nearby keyframe; exact frame-accurate seeking may take longer on long-GOP/high-bitrate files.

Still not verified:
- APK assembly and runtime seek behavior on real MP4/MKV/AVI/FLV samples. The uploaded source has not been compiled or run on a device in this environment.
- The new logo/icon appearance on actual Android launcher masks and different OEM launchers.
