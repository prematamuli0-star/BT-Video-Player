# BT Video Player – Direct Aspect Mode Cycle

The aspect-ratio icon now cycles modes directly on tap using PlayerController.cycleResizeMode(). It no longer opens the aspect-ratio selection dialog from either the top toolbar or bottom transport control. Modes cycle in this order: FIT → FILL → STRETCH → FIXED_WIDTH → FIXED_HEIGHT → ORIGINAL_100 → FIT.

No APK build or physical-device test is claimed.
