package com.btvideoplayer.ui.home

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.btvideoplayer.R
import com.btvideoplayer.data.repository.SortOption
import com.btvideoplayer.ui.home.components.FolderCard
import com.btvideoplayer.ui.home.components.SearchBar
import com.btvideoplayer.ui.home.components.VideoCard
import com.btvideoplayer.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onVideoClick: (Long, String?) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var showSortDialog by remember { mutableStateOf(false) }

    // Permission launcher supporting Android 13+ READ_MEDIA_VIDEO and legacy READ_EXTERNAL_STORAGE
    val permissionToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.onPermissionResult(isGranted)
    }

    LaunchedEffect(Unit) {
        val isGranted = androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            permissionToRequest
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        viewModel.onPermissionResult(isGranted)
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkBackground)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // App Bar Title & Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (uiState.selectedFolder != null) {
                            IconButton(onClick = { viewModel.selectFolder(null) }) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_arrow_back),
                                    contentDescription = "Back",
                                    tint = TextPrimary
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = uiState.selectedFolder?.name
                                ?: stringResource(id = R.string.app_name),
                            style = Typography.titleLarge,
                            color = TextPrimary
                        )
                    }

                    Row {
                        IconButton(onClick = { showSortDialog = true }) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_sort),
                                contentDescription = "Sort",
                                tint = TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Bar
                SearchBar(
                    query = uiState.searchQuery,
                    onQueryChange = viewModel::onSearchQueryChanged,
                    onClearQuery = { viewModel.onSearchQueryChanged("") }
                )

                // Navigation Tabs (Folders, Videos, Favorites) - only show when not in a folder
                if (uiState.selectedFolder == null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    TabRow(
                        selectedTabIndex = uiState.selectedTab,
                        containerColor = DarkBackground,
                        contentColor = NeonCyan,
                        indicator = { tabPositions ->
                            TabRowDefaults.Indicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[uiState.selectedTab]),
                                color = NeonCyan,
                                height = 3.dp
                            )
                        },
                        divider = {
                            Divider(color = DarkSurfaceVariant, thickness = 1.dp)
                        }
                    ) {
                        Tab(
                            selected = uiState.selectedTab == 0,
                            onClick = { viewModel.setSelectedTab(0) },
                            text = {
                                Text(
                                    text = stringResource(id = R.string.folders),
                                    style = Typography.titleMedium.copy(
                                        fontWeight = if (uiState.selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            }
                        )
                        Tab(
                            selected = uiState.selectedTab == 1,
                            onClick = { viewModel.setSelectedTab(1) },
                            text = {
                                Text(
                                    text = stringResource(id = R.string.videos),
                                    style = Typography.titleMedium.copy(
                                        fontWeight = if (uiState.selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            }
                        )
                        Tab(
                            selected = uiState.selectedTab == 2,
                            onClick = { viewModel.setSelectedTab(2) },
                            text = {
                                Text(
                                    text = stringResource(id = R.string.favorites),
                                    style = Typography.titleMedium.copy(
                                        fontWeight = if (uiState.selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                            }
                        )
                    }
                }
            }
        },
        containerColor = DarkBackground
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                !uiState.hasPermission -> {
                    PermissionRequiredView(
                        onRequestPermission = { permissionLauncher.launch(permissionToRequest) },
                        onOpenSettings = {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null)
                            )
                            context.startActivity(intent)
                        }
                    )
                }

                uiState.isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = NeonCyan)
                    }
                }

                // If a folder is opened, display videos in that folder
                uiState.selectedFolder != null -> {
                    val folderVideos = uiState.displayVideos
                    if (folderVideos.isEmpty()) {
                        EmptyView(message = stringResource(id = R.string.no_videos_found))
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(folderVideos, key = { it.id }) { video ->
                                VideoCard(
                                    video = video,
                                    isFavorite = uiState.favorites.contains(video.id),
                                    onToggleFavorite = { viewModel.toggleFavorite(video.id) },
                                    onClick = { onVideoClick(video.id, uiState.selectedFolder?.id) }
                                )
                            }
                        }
                    }
                }

                // Tab 0: Folders
                uiState.selectedTab == 0 -> {
                    val folders = uiState.displayFolders
                    if (folders.isEmpty()) {
                        EmptyView(message = stringResource(id = R.string.no_videos_found))
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 160.dp),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(folders, key = { it.id }) { folder ->
                                FolderCard(
                                    folder = folder,
                                    onClick = { viewModel.selectFolder(folder) }
                                )
                            }
                        }
                    }
                }

                // Tab 1 & Tab 2: Videos / Favorites
                else -> {
                    val videos = uiState.displayVideos
                    if (videos.isEmpty()) {
                        EmptyView(
                            message = if (uiState.selectedTab == 2) {
                                stringResource(id = R.string.no_favorites_yet)
                            } else {
                                stringResource(id = R.string.no_videos_found)
                            }
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(videos, key = { it.id }) { video ->
                                VideoCard(
                                    video = video,
                                    isFavorite = uiState.favorites.contains(video.id),
                                    onToggleFavorite = { viewModel.toggleFavorite(video.id) },
                                    onClick = { onVideoClick(video.id, null) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSortDialog) {
        SortDialog(
            currentSort = uiState.sortOption,
            onSortSelected = {
                viewModel.setSortOption(it)
                showSortDialog = false
            },
            onDismiss = { showSortDialog = false }
        )
    }
}

@Composable
fun PermissionRequiredView(
    onRequestPermission: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            painter = painterResource(id = R.drawable.ic_video),
            contentDescription = null,
            tint = NeonCyan,
            modifier = Modifier.size(72.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = stringResource(id = R.string.permission_required),
            style = Typography.titleLarge,
            color = TextPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = stringResource(id = R.string.permission_rationale),
            style = Typography.bodyLarge,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(26.dp))

        Button(
            onClick = onRequestPermission,
            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = DarkBackground),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(
                text = stringResource(id = R.string.grant_permission),
                style = Typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onOpenSettings,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(
                text = stringResource(id = R.string.open_settings),
                style = Typography.titleMedium
            )
        }
    }
}

@Composable
fun EmptyView(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            style = Typography.bodyLarge,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun SortDialog(
    currentSort: SortOption,
    onSortSelected: (SortOption) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(
                text = stringResource(id = R.string.sort_by),
                style = Typography.titleMedium,
                color = TextPrimary
            )
        },
        text = {
            Column {
                SortOptionItem(
                    title = "Date Added (Newest first)",
                    selected = currentSort == SortOption.DATE_DESC,
                    onClick = { onSortSelected(SortOption.DATE_DESC) }
                )
                SortOptionItem(
                    title = "Date Added (Oldest first)",
                    selected = currentSort == SortOption.DATE_ASC,
                    onClick = { onSortSelected(SortOption.DATE_ASC) }
                )
                SortOptionItem(
                    title = "Name (A to Z)",
                    selected = currentSort == SortOption.NAME_ASC,
                    onClick = { onSortSelected(SortOption.NAME_ASC) }
                )
                SortOptionItem(
                    title = "Name (Z to A)",
                    selected = currentSort == SortOption.NAME_DESC,
                    onClick = { onSortSelected(SortOption.NAME_DESC) }
                )
                SortOptionItem(
                    title = "Size (Largest first)",
                    selected = currentSort == SortOption.SIZE_DESC,
                    onClick = { onSortSelected(SortOption.SIZE_DESC) }
                )
                SortOptionItem(
                    title = "Duration (Longest first)",
                    selected = currentSort == SortOption.DURATION_DESC,
                    onClick = { onSortSelected(SortOption.DURATION_DESC) }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Cancel", color = NeonCyan)
            }
        }
    )
}

@Composable
fun SortOptionItem(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(
                selectedColor = NeonCyan,
                unselectedColor = TextTertiary
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = Typography.bodyLarge,
            color = if (selected) NeonCyan else TextPrimary
        )
    }
}
