package com.btvideoplayer.ui.player

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.btvideoplayer.R
import com.btvideoplayer.ui.theme.*
import com.btvideoplayer.util.TimeUtils

@Composable
fun PlayerControlsOverlay(
    isVisible: Boolean,
    isLocked: Boolean,
    title: String,
    isPlaying: Boolean,
    currentPosition: Long,
    duration: Long,
    bufferedPosition: Long,
    playbackSpeed: Float,
    aspectRatioName: String,
    onBackClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onRewind5Click: () -> Unit,
    onForward15Click: () -> Unit,
    onPreviousClick: () -> Unit,
    onNextClick: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleLock: () -> Unit,
    onSpeedClick: () -> Unit,
    onSubtitleClick: () -> Unit,
    onAudioTrackClick: () -> Unit,
    onAspectRatioClick: () -> Unit,
    onPipClick: () -> Unit,
    onRotateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {

        // When locked, only show floating unlock button
        if (isLocked) {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 24.dp)
            ) {
                IconButton(
                    onClick = onToggleLock,
                    modifier = Modifier
                        .size(52.dp)
                        .background(ScrimDark, CircleShape)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_lock),
                        contentDescription = "Unlock",
                        tint = NeonCyan,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
            return
        }

        // Full Controls Overlay
        AnimatedVisibility(
            visible = isVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {

                // Top Floating Bar with Dark Gradient Scrim
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(ScrimDark, Transparent)
                            )
                        )
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_arrow_back),
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }

                        Text(
                            text = title,
                            style = Typography.titleMedium.copy(fontWeight = FontWeight.Medium),
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp)
                        )

                        // Audio Track Selector
                        IconButton(onClick = onAudioTrackClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_audio_track),
                                contentDescription = "Audio Track",
                                tint = TextPrimary
                            )
                        }

                        // Subtitles Selector
                        IconButton(onClick = onSubtitleClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_subtitles),
                                contentDescription = "Subtitles",
                                tint = TextPrimary
                            )
                        }

                        // Aspect Ratio Toggle
                        IconButton(onClick = onAspectRatioClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_aspect_ratio),
                                contentDescription = "Aspect Ratio: $aspectRatioName",
                                tint = NeonCyan
                            )
                        }

                        // Picture in Picture
                        IconButton(onClick = onPipClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_pip),
                                contentDescription = "Picture in Picture",
                                tint = TextPrimary
                            )
                        }
                    }
                }

                // Bottom Floating Controls with Dark Gradient Scrim
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Transparent, ScrimDark)
                            )
                        )
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    // Time Labels & Scrubber
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = TimeUtils.formatDuration(currentPosition),
                            style = Typography.bodyMedium.copy(fontSize = 12.sp),
                            color = TextPrimary
                        )

                        Slider(
                            value = currentPosition.toFloat(),
                            onValueChange = { onSeek(it.toLong()) },
                            valueRange = 0f..(duration.toFloat().coerceAtLeast(1f)),
                            colors = SliderDefaults.colors(
                                thumbColor = NeonCyan,
                                activeTrackColor = NeonCyan,
                                inactiveTrackColor = DarkSurfaceHighlight
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 10.dp)
                        )

                        Text(
                            text = TimeUtils.formatDuration(duration),
                            style = Typography.bodyMedium.copy(fontSize = 12.sp),
                            color = TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Buttons Row: Lock, Prev, Rewind 5s, Play/Pause, Forward 15s, Next, Speed, Rotate
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        // Lock screen button
                        IconButton(onClick = onToggleLock) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_lock_open),
                                contentDescription = "Lock Controls",
                                tint = TextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Previous video
                        IconButton(onClick = onPreviousClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_skip_previous),
                                contentDescription = "Previous Video",
                                tint = TextPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        // Rewind 5 seconds
                        IconButton(onClick = onRewind5Click) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_replay_5),
                                contentDescription = "Rewind 5s",
                                tint = TextPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        // Play / Pause Button (Large Neon Circle)
                        IconButton(
                            onClick = onPlayPauseClick,
                            modifier = Modifier
                                .size(56.dp)
                                .background(NeonCyan, CircleShape)
                        ) {
                            Icon(
                                painter = painterResource(
                                    id = if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                                ),
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = DarkBackground,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Forward 15 seconds
                        IconButton(onClick = onForward15Click) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_forward_15),
                                contentDescription = "Forward 15s",
                                tint = TextPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }

                        // Next video
                        IconButton(onClick = onNextClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_skip_next),
                                contentDescription = "Next Video",
                                tint = TextPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        // Playback Speed badge button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(DarkSurfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            TextButton(
                                onClick = onSpeedClick,
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(
                                    text = "${playbackSpeed}x",
                                    style = Typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = NeonCyan
                                )
                            }
                        }

                        // Screen Rotation
                        IconButton(onClick = onRotateClick) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_screen_rotation),
                                contentDescription = "Rotate",
                                tint = TextSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
