package com.btvideoplayer.ui.player.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.btvideoplayer.R
import com.btvideoplayer.ui.theme.*

sealed class HudState {
    object Idle : HudState()
    data class Volume(val percent: Int) : HudState()
    data class Brightness(val percent: Int) : HudState()
    data class Seek(val targetTime: String, val deltaSeconds: Int) : HudState()
    data class Message(val text: String) : HudState()
}

@Composable
fun GestureHud(
    hudState: HudState,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = hudState !is HudState.Idle,
        enter = fadeIn() + scaleIn(initialScale = 0.9f),
        exit = fadeOut() + scaleOut(targetScale = 0.9f),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(ScrimDark)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            when (hudState) {
                is HudState.Volume -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(140.dp)
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_volume),
                            contentDescription = "Volume",
                            tint = NeonCyan,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = (hudState.percent / 100f).coerceIn(0f, 1f),
                            color = NeonCyan,
                            trackColor = DarkSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${hudState.percent}%",
                            style = Typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                    }
                }

                is HudState.Brightness -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.width(140.dp)
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_brightness),
                            contentDescription = "Brightness",
                            tint = AccentAmber,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = (hudState.percent / 100f).coerceIn(0f, 1f),
                            color = AccentAmber,
                            trackColor = DarkSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${hudState.percent}%",
                            style = Typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                    }
                }

                is HudState.Seek -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (hudState.deltaSeconds >= 0) {
                                "+${hudState.deltaSeconds}s"
                            } else {
                                "${hudState.deltaSeconds}s"
                            },
                            style = Typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = NeonCyan
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = hudState.targetTime,
                            style = Typography.bodyLarge,
                            color = TextPrimary
                        )
                    }
                }

                is HudState.Message -> {
                    Text(
                        text = hudState.text,
                        style = Typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }

                HudState.Idle -> {}
            }
        }
    }
}
