package com.bt.videoplayer.player

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.bt.videoplayer.data.model.AudioTrack
import com.bt.videoplayer.data.model.SubtitleTrack
import com.bt.videoplayer.data.model.VideoItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.Locale

@OptIn(UnstableApi::class)
class BTPlayerManager(private val context: Context) {

    private val trackSelector = DefaultTrackSelector(context)
    private val libVlc: LibVLC by lazy {
        LibVLC(context, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
    }
    private val vlcPlayer: MediaPlayer by lazy { MediaPlayer(libVlc) }
    private var vlcViewsAttached = false
    private var attachedVlcLayout: VLCVideoLayout? = null
    private var vlcPfd: ParcelFileDescriptor? = null
    private var pendingVlcStart = false
    // Startup seek target to apply once VLC transitions to Playing for the first time.
    private var pendingVlcSeekMs: Long? = null
    private var vlcPlaybackStarted = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var vlcSeekGeneration = 0L
    private var activeVlcSeekTargetMs: Long? = null
    private var fallbackAttemptedForCurrentItem = false

    // Optimistic seek tracking so rapid skips (+10s / -10s) accumulate cleanly
    // and periodic position polling does not snap the UI back to a stale timestamp.
    private var lastSeekTimestampMs: Long = 0L
    private var lastSeekTargetMs: Long = 0L

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context)
        .setTrackSelector(trackSelector)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            /* handleAudioFocus = */ true
        )
        .build()

    private val _isVlcFallback = MutableStateFlow(false)
    val isVlcFallback: StateFlow<Boolean> = _isVlcFallback.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _bufferedPositionMs = MutableStateFlow(0L)
    val bufferedPositionMs: StateFlow<Long> = _bufferedPositionMs.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _resizeMode = MutableStateFlow(ResizeMode.FIT)
    val resizeMode: StateFlow<ResizeMode> = _resizeMode.asStateFlow()

    private val _currentVideo = MutableStateFlow<VideoItem?>(null)
    val currentVideo: StateFlow<VideoItem?> = _currentVideo.asStateFlow()

    private val _availableSubtitles = MutableStateFlow<List<SubtitleTrack>>(emptyList())
    val availableSubtitles: StateFlow<List<SubtitleTrack>> = _availableSubtitles.asStateFlow()

    private val _availableAudioTracks = MutableStateFlow<List<AudioTrack>>(emptyList())
    val availableAudioTracks: StateFlow<List<AudioTrack>> = _availableAudioTracks.asStateFlow()

    private var playlist: List<VideoItem> = emptyList()
    private var currentIndex: Int = -1

    private companion object {
        const val SEEK_GUARD_WINDOW_MS = 750L
        const val VLC_VERIFY_DELAY_MS = 350L
        const val VLC_STARTUP_MAX_RETRIES = 4
    }

    init {
        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!_isVlcFallback.value) _isPlaying.value = isPlaying
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                // Attempt VLC exactly once for this item to avoid engine-switch loops.
                if (!fallbackAttemptedForCurrentItem) {
                    fallbackAttemptedForCurrentItem = true
                    val resumePos = _currentPositionMs.value.coerceAtLeast(
                        exoPlayer.currentPosition.coerceAtLeast(0L)
                    )
                    startVlcFallback(resumePos)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && !_isVlcFallback.value) {
                    val dur = exoPlayer.duration
                    if (dur != C.TIME_UNSET && dur > 0L) {
                        _durationMs.value = dur
                    }
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                extractSubtitleTracks(tracks)
                extractAudioTracks(tracks)
            }
        })
    }

    fun setPlaylist(videos: List<VideoItem>, startIndex: Int, startPositionMs: Long = 0L) {
        playlist = videos
        currentIndex = startIndex.coerceIn(0, (videos.size - 1).coerceAtLeast(0))
        if (videos.isNotEmpty() && currentIndex in videos.indices) {
            playVideo(videos[currentIndex], startPositionMs)
        }
    }

    fun playVideo(video: VideoItem, startPositionMs: Long = 0L) {
        fallbackAttemptedForCurrentItem = false
        pendingVlcSeekMs = null
        activeVlcSeekTargetMs = null
        lastSeekTimestampMs = 0L
        lastSeekTargetMs = 0L
        if (_isVlcFallback.value) {
            stopVlcFallback()
        }
        _currentVideo.value = video
        _durationMs.value = video.durationMs.coerceAtLeast(0L)
        _currentPositionMs.value = startPositionMs.coerceAtLeast(0L)
        val mediaItem = MediaItem.fromUri(video.uri)
        // Set the requested start position as part of the media item. This avoids
        // issuing a seek against an unprepared/unknown timeline (which can resolve to 0).
        exoPlayer.setMediaItem(mediaItem, startPositionMs.coerceAtLeast(0L))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    fun play() {
        if (_isVlcFallback.value) vlcPlayer.play() else exoPlayer.play()
    }

    fun pause() {
        if (_isVlcFallback.value) vlcPlayer.pause() else exoPlayer.pause()
    }

    fun togglePlayPause() {
        if (_isVlcFallback.value) {
            if (vlcPlayer.isPlaying) pause() else play()
        } else if (exoPlayer.isPlaying) pause() else play()
    }

    /** Called by the VLC surface hosted by PlayerScreen. */
    fun attachVlcViews(layout: VLCVideoLayout) {
        if (attachedVlcLayout !== layout || !vlcViewsAttached) {
            if (attachedVlcLayout != null && attachedVlcLayout !== layout) {
                try { vlcPlayer.detachViews() } catch (_: Exception) {}
            }
            vlcPlayer.attachViews(layout, null, false, false)
            attachedVlcLayout = layout
            vlcViewsAttached = true
        }
        if (pendingVlcStart) startPendingVlcMedia()
    }

    fun detachVlcViews() {
        if (vlcViewsAttached || attachedVlcLayout != null) {
            try { vlcPlayer.detachViews() } catch (_: Exception) {}
            attachedVlcLayout = null
            vlcViewsAttached = false
        }
    }

    private fun closeVlcPfd() {
        try {
            vlcPfd?.close()
        } catch (_: Exception) {
        } finally {
            vlcPfd = null
        }
    }

    private fun startVlcFallback(positionMs: Long) {
        val video = _currentVideo.value ?: return
        val safePos = positionMs.coerceAtLeast(0L)
        _currentPositionMs.value = safePos
        if (_durationMs.value <= 0L && video.durationMs > 0L) {
            _durationMs.value = video.durationMs
        }
        pendingVlcSeekMs = if (safePos > 0L) safePos else null
        _isVlcFallback.value = true
        _isPlaying.value = false
        exoPlayer.pause()
        pendingVlcStart = true
        vlcPlaybackStarted = false
        if (vlcViewsAttached) startPendingVlcMedia()
    }

    private fun startPendingVlcMedia() {
        val video = _currentVideo.value ?: return
        pendingVlcStart = false
        vlcPlaybackStarted = false
        try {
            closeVlcPfd()
            // Open a seekable FileDescriptor for content:// URIs so LibVLC can use
            // direct POSIX lseek64 random access on MKV/MP4 containers.
            val media = try {
                val pfd = context.contentResolver.openFileDescriptor(video.uri, "r")
                if (pfd != null) {
                    vlcPfd = pfd
                    Media(libVlc, pfd.fileDescriptor)
                } else if (video.path.isNotBlank() && File(video.path).canRead()) {
                    Media(libVlc, video.path)
                } else {
                    Media(libVlc, video.uri)
                }
            } catch (_: Exception) {
                if (video.path.isNotBlank() && File(video.path).canRead()) {
                    Media(libVlc, video.path)
                } else {
                    Media(libVlc, video.uri)
                }
            }

            vlcPlayer.media = media
            media.release()
            vlcPlayer.setEventListener { event ->
                when (event.type) {
                    MediaPlayer.Event.Playing -> {
                        val wasStarted = vlcPlaybackStarted
                        vlcPlaybackStarted = true
                        _isPlaying.value = true
                        val reportedLen = vlcPlayer.length
                        if (reportedLen > 0L) {
                            _durationMs.value = reportedLen
                        }
                        // Only trigger the initial startup seek once when VLC first enters Playing.
                        val startupSeek = pendingVlcSeekMs
                        if (!wasStarted && startupSeek != null && startupSeek > 0L) {
                            pendingVlcSeekMs = null
                            performVlcSeek(startupSeek, _durationMs.value, isStartupSeek = true)
                        }
                    }
                    MediaPlayer.Event.Paused -> _isPlaying.value = false
                    MediaPlayer.Event.Stopped, MediaPlayer.Event.EndReached -> {
                        _isPlaying.value = false
                        vlcPlaybackStarted = false
                    }
                    MediaPlayer.Event.TimeChanged -> {
                        val actual = vlcPlayer.time.coerceAtLeast(0L)
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastSeekTimestampMs >= SEEK_GUARD_WINDOW_MS) {
                            _currentPositionMs.value = actual
                            activeVlcSeekTargetMs = null
                        }
                        val reportedLen = vlcPlayer.length
                        if (reportedLen > 0L) {
                            _durationMs.value = reportedLen
                        } else if (_durationMs.value <= 0L) {
                            _durationMs.value = _currentVideo.value?.durationMs?.coerceAtLeast(0L) ?: 0L
                        }
                    }
                    MediaPlayer.Event.EncounteredError -> {
                        _isPlaying.value = false
                    }
                }
            }
            vlcPlayer.play()
        } catch (_: Exception) {
            _isPlaying.value = false
        }
    }

    private fun performVlcSeek(
        targetMs: Long,
        knownDurationMs: Long,
        isStartupSeek: Boolean = false,
        startupAttempt: Int = 0
    ) {
        if (!_isVlcFallback.value || !vlcPlaybackStarted) return
        val generation = ++vlcSeekGeneration
        val priorTime = try { vlcPlayer.time.coerceAtLeast(0L) } catch (_: Exception) { 0L }
        val isForwardSeek = !isStartupSeek && targetMs > priorTime + 1500L
        activeVlcSeekTargetMs = targetMs

        try {
            val vlcLen = vlcPlayer.length.takeIf { it > 0L } ?: knownDurationMs
            vlcPlayer.setTime(targetMs)
            if (vlcLen > 0L && !vlcPlayer.isSeekable) {
                vlcPlayer.setPosition((targetMs.toFloat() / vlcLen.toFloat()).coerceIn(0f, 1f))
            }
        } catch (_: Exception) {
        }

        mainHandler.postDelayed({
            if (generation != vlcSeekGeneration || !_isVlcFallback.value || !vlcPlaybackStarted) return@postDelayed
            val actual = try { vlcPlayer.time.coerceAtLeast(0L) } catch (_: Exception) { 0L }
            val vlcLen = vlcPlayer.length.takeIf { it > 0L } ?: knownDurationMs
            if (vlcLen > 0L) {
                _durationMs.value = vlcLen
            }

            if (isStartupSeek && targetMs > 2000L && actual < 500L && startupAttempt < VLC_STARTUP_MAX_RETRIES) {
                // VLC is still indexing the container after initial open; retry startup seek.
                performVlcSeek(targetMs, vlcLen, isStartupSeek = true, startupAttempt = startupAttempt + 1)
                return@postDelayed
            }

            if (isForwardSeek && actual <= priorTime + 500L) {
                // On long-GOP MKVs, VLC's keyframe seek can snap back to the current keyframe
                // if the next keyframe is further than the skip delta. Step forward once to
                // cross into the next GOP so forward skips always advance.
                val steppedTarget = if (vlcLen > 0L) {
                    (targetMs + 10_000L).coerceAtMost(vlcLen)
                } else {
                    targetMs + 10_000L
                }
                lastSeekTargetMs = steppedTarget
                lastSeekTimestampMs = SystemClock.elapsedRealtime()
                _currentPositionMs.value = steppedTarget
                try {
                    vlcPlayer.setTime(steppedTarget)
                } catch (_: Exception) {
                }
            }
            activeVlcSeekTargetMs = null
        }, VLC_VERIFY_DELAY_MS)
    }

    private fun stopVlcFallback() {
        vlcSeekGeneration++
        mainHandler.removeCallbacksAndMessages(null)
        try { vlcPlayer.stop() } catch (_: Exception) { }
        closeVlcPfd()
        vlcPlaybackStarted = false
        pendingVlcSeekMs = null
        activeVlcSeekTargetMs = null
        _isVlcFallback.value = false
        _isPlaying.value = false
    }

    /**
     * Skips forward or backward by [deltaMs] milliseconds relative to the current
     * (or in-flight target) playback position.
     */
    fun skipBy(deltaMs: Long) {
        val now = SystemClock.elapsedRealtime()
        val basePosition = if (now - lastSeekTimestampMs < SEEK_GUARD_WINDOW_MS) {
            lastSeekTargetMs
        } else {
            _currentPositionMs.value.coerceAtLeast(0L)
        }
        seekTo((basePosition + deltaMs).coerceAtLeast(0L))
    }

    fun seekTo(positionMs: Long) {
        val requestedPosition = positionMs.coerceAtLeast(0L)
        val rawDuration = if (_isVlcFallback.value) {
            vlcPlayer.length
        } else {
            val exoDur = exoPlayer.duration
            if (exoDur != C.TIME_UNSET && exoDur > 0L) exoDur else 0L
        }
        val knownDuration = when {
            rawDuration > 0L -> rawDuration
            _durationMs.value > 0L -> _durationMs.value
            else -> _currentVideo.value?.durationMs?.coerceAtLeast(0L) ?: 0L
        }
        if (knownDuration > 0L && _durationMs.value <= 0L) {
            _durationMs.value = knownDuration
        }

        val targetPosition = if (knownDuration > 0L) {
            requestedPosition.coerceAtMost(knownDuration)
        } else {
            requestedPosition
        }

        _currentPositionMs.value = targetPosition
        lastSeekTargetMs = targetPosition
        lastSeekTimestampMs = SystemClock.elapsedRealtime()

        if (_isVlcFallback.value) {
            if (vlcPlaybackStarted) {
                pendingVlcSeekMs = null
                performVlcSeek(targetPosition, knownDuration, isStartupSeek = false)
            } else {
                pendingVlcSeekMs = targetPosition
            }
            return
        }

        val currentExoPos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val delta = targetPosition - currentExoPos

        // Use directional sync-frame tolerances so large MKV seeks remain fast without
        // ever snapping backward to the current keyframe on a forward skip (or forward
        // to the current keyframe on a backward skip).
        val seekParams = when {
            delta > 0L -> {
                val maxBackSnapMs = (delta / 2).coerceAtLeast(0L)
                SeekParameters(
                    /* toleranceBeforeUs = */ maxBackSnapMs * 1000L,
                    /* toleranceAfterUs = */ Long.MAX_VALUE
                )
            }
            delta < 0L -> {
                val maxForwardSnapMs = ((-delta) / 2).coerceAtLeast(0L)
                SeekParameters(
                    /* toleranceBeforeUs = */ Long.MAX_VALUE,
                    /* toleranceAfterUs = */ maxForwardSnapMs * 1000L
                )
            }
            else -> SeekParameters.DEFAULT
        }

        exoPlayer.setSeekParameters(seekParams)
        exoPlayer.seekTo(targetPosition)
    }

    fun playNext(): Boolean {
        if (playlist.size > 1) {
            currentIndex = (currentIndex + 1) % playlist.size
            playVideo(playlist[currentIndex])
            return true
        }
        // When only a single video is loaded, skip forward 10 seconds so the button is responsive.
        skipBy(10_000L)
        return false
    }

    fun playPrevious(): Boolean {
        if (playlist.size > 1) {
            currentIndex = if (currentIndex > 0) currentIndex - 1 else playlist.size - 1
            playVideo(playlist[currentIndex])
            return true
        } else {
            // When only a single video is loaded, skip backward 10 seconds.
            skipBy(-10_000L)
            return false
        }
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        _playbackSpeed.value = clamped
        if (_isVlcFallback.value) vlcPlayer.setRate(clamped) else exoPlayer.playbackParameters = PlaybackParameters(clamped)
    }

    fun setResizeMode(mode: ResizeMode) {
        _resizeMode.value = mode
    }

    fun cycleResizeMode() {
        val modes = ResizeMode.values()
        val nextIndex = (modes.indexOf(_resizeMode.value) + 1) % modes.size
        _resizeMode.value = modes[nextIndex]
    }

    fun loadExternalSubtitle(uri: Uri, mimeType: String = MimeTypes.APPLICATION_SUBRIP) {
        val current = _currentVideo.value ?: return
        val currentPos = _currentPositionMs.value.coerceAtLeast(0L)

        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mimeType)
            .setLanguage("custom")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(current.uri)
            .setSubtitleConfigurations(listOf(subtitleConfig))
            .build()

        exoPlayer.setMediaItem(mediaItem, currentPos)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    private fun extractSubtitleTracks(tracks: Tracks) {
        val subs = mutableListOf<SubtitleTrack>()
        val textGroups = tracks.groups.withIndex()
            .filter { it.value.type == C.TRACK_TYPE_TEXT }
        val hasSelectedSubtitle = textGroups.any { indexedGroup ->
            (0 until indexedGroup.value.length).any { indexedGroup.value.isTrackSelected(it) }
        }

        // "Off" is selected only when no text track is currently active.
        subs.add(SubtitleTrack("none", "Off (None)", isSelected = !hasSelectedSubtitle))

        textGroups.forEach { indexedGroup ->
            val groupIndex = indexedGroup.index
            val group = indexedGroup.value
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val label = format.label ?: format.language ?: "Track ${subs.size}"
                subs.add(
                    SubtitleTrack(
                        id = format.id ?: "$groupIndex-$i",
                        name = label,
                        language = format.language,
                        isSelected = group.isTrackSelected(i),
                        groupIndex = groupIndex,
                        trackIndex = i
                    )
                )
            }
        }
        _availableSubtitles.value = subs
    }

    private fun extractAudioTracks(tracks: Tracks) {
        val audioList = mutableListOf<AudioTrack>()
        for ((groupIndex, group) in tracks.groups.withIndex()) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val lang = format.language
                    val langName = if (!lang.isNullOrBlank()) {
                        try {
                            val loc = Locale(lang)
                            loc.displayLanguage.ifBlank { lang }
                        } catch (e: Exception) {
                            lang
                        }
                    } else null

                    val label = format.label ?: langName ?: "Audio Track ${audioList.size + 1}"
                    val isSelected = group.isTrackSelected(i)
                    audioList.add(
                        AudioTrack(
                            id = format.id ?: "$groupIndex-$i",
                            name = label,
                            language = lang,
                            channels = format.channelCount,
                            sampleRate = format.sampleRate,
                            isSelected = isSelected,
                            groupIndex = groupIndex,
                            trackIndex = i
                        )
                    )
                }
            }
        }
        _availableAudioTracks.value = audioList
    }

    fun selectSubtitleTrack(track: SubtitleTrack) {
        val parameters = trackSelector.buildUponParameters()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)

        if (track.id == "none") {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            parameters.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            val selectedGroup = exoPlayer.currentTracks.groups
                .getOrNull(track.groupIndex)
                ?.takeIf { it.type == C.TRACK_TYPE_TEXT }

            if (selectedGroup != null && track.trackIndex in 0 until selectedGroup.length) {
                parameters.addOverride(
                    TrackSelectionOverride(
                        selectedGroup.mediaTrackGroup,
                        track.trackIndex
                    )
                )
            } else if (track.language != null) {
                parameters.setPreferredTextLanguage(track.language)
            }
        }
        trackSelector.setParameters(parameters)
    }

    fun selectAudioTrack(track: AudioTrack) {
        val parameters = trackSelector.buildUponParameters()
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)

        val selectedGroup = exoPlayer.currentTracks.groups
            .getOrNull(track.groupIndex)
            ?.takeIf { it.type == C.TRACK_TYPE_AUDIO }

        if (selectedGroup != null && track.trackIndex in 0 until selectedGroup.length) {
            parameters.addOverride(
                TrackSelectionOverride(
                    selectedGroup.mediaTrackGroup,
                    track.trackIndex
                )
            )
        } else if (track.language != null) {
            parameters.setPreferredAudioLanguage(track.language)
        }
        trackSelector.setParameters(parameters)
    }

    fun updatePosition() {
        val now = SystemClock.elapsedRealtime()
        val inSeekGuard = now - lastSeekTimestampMs < SEEK_GUARD_WINDOW_MS

        if (_isVlcFallback.value) {
            val actual = try { vlcPlayer.time.coerceAtLeast(0L) } catch (_: Exception) { 0L }
            if (!inSeekGuard) {
                _currentPositionMs.value = actual
            }
            val reportedLen = try { vlcPlayer.length } catch (_: Exception) { 0L }
            if (reportedLen > 0L) {
                _durationMs.value = reportedLen
            } else if (_durationMs.value <= 0L) {
                _durationMs.value = _currentVideo.value?.durationMs?.coerceAtLeast(0L) ?: 0L
            }
            _bufferedPositionMs.value = _currentPositionMs.value
        } else {
            if (!inSeekGuard) {
                _currentPositionMs.value = exoPlayer.currentPosition.coerceAtLeast(0L)
            }
            _bufferedPositionMs.value = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            val exoDur = exoPlayer.duration
            if (exoDur != C.TIME_UNSET && exoDur > 0L) {
                _durationMs.value = exoDur
            } else if (_durationMs.value <= 0L) {
                _durationMs.value = _currentVideo.value?.durationMs?.coerceAtLeast(0L) ?: 0L
            }
        }
    }

    fun release() {
        vlcSeekGeneration++
        mainHandler.removeCallbacksAndMessages(null)
        try { vlcPlayer.stop() } catch (_: Exception) { }
        closeVlcPfd()
        if (vlcViewsAttached || attachedVlcLayout != null) detachVlcViews()
        try { vlcPlayer.release() } catch (_: Exception) { }
        try { libVlc.release() } catch (_: Exception) { }
        exoPlayer.release()
    }
}
