# BT Video Player — Clean Package Update

This source archive is a cleaned project update based on the uploaded source.

## Applied
- Updated Kotlin package, Android namespace, and applicationId to `com.btplayer.video`.
- Moved source and test files into matching package directories.
- Disabled Android system Picture-in-Picture and removed the automatic Home-button PiP transition. The app is intended to use its in-app floating mini-player instead.
- Removed the visible system PiP toolbar action.
- Enabled ABI-specific APK outputs (ARMv7, ARM64, x86, x86_64) instead of a single universal APK.
- Kept Media3 and LibVLC playback engines, AdMob/UMP, and the existing Compose UI so playback compatibility and current design are not deliberately removed.
- Removed the debug signing key from the release build configuration. A production release must be signed with the owner's existing upload key.

## Important
- This is a source project ZIP, not an APK.
- Build verification could not be completed in this environment because the Gradle wrapper distribution was not cached and network access to `services.gradle.org` was unavailable.
- The existing LibVLC dependency is still included because the current source uses it as a fallback engine. Removing it would materially reduce APK size but would also remove the VLC fallback and may reduce codec compatibility. For Google Play, prefer an Android App Bundle (AAB), which delivers only device-matching native libraries.
- Before publishing, configure the real AdMob App ID and sign with the existing Play upload key. Do not use a debug key for Play updates.
- Device testing is still required for seek/skip, in-app mini-player surface handoff, gestures, and playback lifecycle.


## Build configuration fix (12 Nov 2026)
Removed `defaultConfig.ndk.abiFilters` because ABI selection is already configured under `android.splits.abi`. Keeping both causes the Gradle error: conflicting configuration between ndk abiFilters and splits abi filters.

The Kotlin `kotlinOptions` deprecation warning is separate and is not the cause of this failure.
