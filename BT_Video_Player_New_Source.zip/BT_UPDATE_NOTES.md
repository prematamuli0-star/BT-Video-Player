BT Video Player update — source-only, NOT BUILD-VERIFIED

Changes:
- Moved player touch gesture handlers from the outer player root to a video-layer overlay underneath visible controls, reducing accidental gesture activation from toolbar and seek controls.
- Replaced fixed Home mini-player bar with draggable floating mini-player on top of folder/video list.
- Media3 floating window attaches a PlayerView and has expand, play/pause, and close controls.
- Close calls PlayerController.closeCurrentVideo(), stopping playback and clearing active video.
- Existing landscape -> portrait -> folder Back flow retained.

Limitations / required validation:
- APK was NOT compiled or device-tested here. Do not treat this as a confirmed fix.
- VLC fallback currently shows an expand-to-player placeholder rather than rendering VLC video in the floating window; requires dedicated VLC surface handoff implementation.
- Verify gestures, tap targets, seek, navigation, surface handoff, and lifecycle on physical Android devices.
- Some player gestures still use full video layer rather than exact visible-video bounds; letterbox regions should be validated.
