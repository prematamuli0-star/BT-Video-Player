Build instructions

Run from the project root:
  ./gradlew assembleDebug

Expected single universal debug APK:
  app/build/outputs/apk/debug/app-debug.apk

For release:
  ./gradlew assembleRelease

Release APK path:
  app/build/outputs/apk/release/app-release.apk

Configure your own release signing key before distributing a release build. Debug APK is for testing only.

ABI splits are disabled so Gradle should output one APK instead of four ABI-specific APKs. The APK contains all native ABI variants provided by included dependencies and will therefore be larger.
