BT Video Player update

Changes in this package:
1. Removed the portrait-player back-navigation stage. Pressing Back from the player exits the player screen rather than switching to a portrait player.
2. Player screen requests SENSOR_LANDSCAPE while active and restores the prior requested orientation when leaving.
3. Removed the in-player rotate control that allowed switching to portrait.
4. Disabled ABI APK splits. The normal APK output is intended to be a single universal APK containing the native ABIs supplied by the app's dependencies (armeabi-v7a, arm64-v8a, x86, x86_64).
5. No ABI filters are configured in ndk or splits.

Important:
- This is a source ZIP, not a built APK.
- Build could not be run in this environment because Gradle 8.7 could not be downloaded (network DNS unavailable: services.gradle.org).
- The universal APK will be larger than an architecture-specific APK because it packages multiple native ABIs.
- Device compatibility is limited to Android API 24+ and the CPU ABIs actually supplied by the dependencies. It cannot guarantee every Android device ever made.


=====================================================================
Update: floating window, player alignment, seekability
=====================================================================
Package name (com.btplayer.video), AdMob IDs, permissions and signing configuration are unchanged.

ISSUE 1 - Floating pop-up player (new file FloatingVideoPlayer.kt, wired in HomeScreen.kt)
- Replaced the small 220dp floating card with a wide 16:9 floating video window.
- Video is shown inside the window (Media3 PlayerView, or a LibVLC SurfaceView when the LibVLC
  fallback is active; the old version only said "Tap to expand VLC video").
- Expand-to-fullscreen button, close button and a centred play/pause button.
- Title, elapsed/total time and a thin progress line. Controls fade out 3 s after playback starts
  and return with a tap.
- Draggable, but always kept fully inside the screen; re-clamped on rotation/size change.
- Lists keep extra bottom space while the window is shown, so the last items stay reachable.
- Playback continues while browsing folders and videos.

ISSUE 2 - Player screen alignment (PlayerScreen.kt, PlayerDialogs.kt)
- Previous / Play-Pause / Next are truly centred (the old SpaceBetween row pushed them to the right).
- Top and bottom bars respect the camera cut-out and system bars on all sides (landscape and portrait).
- Narrow windows get slightly smaller buttons and tighter spacing; titles end with "..." instead of overflowing.
- Speed / audio / subtitle / aspect dialogs scroll, so nothing is cut off in landscape.

ISSUE 3 - "Media is not seekable" (PlayerController.kt)
- Root cause: when Media3 finished preparing a video but reported it as not seekable (typical for MKV
  without a cue index, FLV and some AVI/TS files) the seek was rejected before it reached any engine,
  so the LibVLC fallback was never used. Now the app switches to LibVLC automatically (once per video,
  after two consecutive confirmations, keeping the current position) and the seek bar works there.
- The message now tells the truth: "Video is still loading..." while preparing, and
  "This video file doesn't support seeking" only when neither player can seek the file.
- Unit tests added in PlayerControllerTest.kt.

NOT BUILT OR RUN: this environment has no Android SDK, Gradle or internet. Please build and test
on a real device (see the delivery notes).


=====================================================================
Update: inconsistent seeking (some videos seek, some do not)
=====================================================================
Causes found:
1. Some files have no seek index or no duration (live-recorded MKV/WebM, fragmented MP4 without sidx,
   FLV). Media3 cannot seek them. (Handled last update by switching to LibVLC.)
2. The app treated "duration unknown" as "cannot seek", so even a seekable engine got skip buttons and
   the seek bar disabled. Now: skip/double-tap work whenever the engine can seek; only the seek bar
   needs a known length (EngineTimelineSnapshot.seekCapability, SeekController).
3. LibVLC reports "seekable" a moment after it starts playing (longer for some containers). The app
   treated the missing flag as final. Now there is a 5 s grace period, a seek made during it is
   deferred and run when LibVLC reports seekable (VlcPlaybackEngine).
4. content:// videos are now opened for LibVLC through a file descriptor (fallback: old way).
5. Media3 skips a track it has no decoder for (picture or sound missing) without raising an error, so
   the fallback never ran. Now detected in Media3PlaybackEngine.onTracksChanged -> LibVLC.

Changed files: SeekModels.kt, SeekController.kt, PlayerController.kt, VlcPlaybackEngine.kt,
Media3PlaybackEngine.kt, SeekControllerTest.kt (2 new tests).
NOT BUILT OR RUN here. Test with the BT_Seek_Test_Videos pack on a real phone.
