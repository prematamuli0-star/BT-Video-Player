BT Video Player update

Changes in this package:
1. Removed the portrait-player back-navigation stage. Pressing Back from the player exits the player screen rather than switching to a portrait player.
2. Player screen requests SENSOR_LANDSCAPE while active and restores the prior requested orientation when leaving.
3. Removed the in-player rotate control that allowed switching to portrait.
4. Disabled ABI APK splits. The normal APK output is intended to be a single universal APK containing the native ABIs supplied by the app's dependencies (armeabi-v7a, arm64-v8a, x86, x86_64).
5. No ABI filters are configured in ndk or splits.

Important:
- This is a source ZIP, not a built APK.
- Build could not be run in this environment because Gradle 8.7 could not be downloaded (network DNS unavailable: services.gradle.org).
- The universal APK will be larger than an architecture-specific APK because it packages multiple native ABIs.
- Device compatibility is limited to Android API 24+ and the CPU ABIs actually supplied by the dependencies. It cannot guarantee every Android device ever made.
