package com.btplayer.video.ui.screens.home

import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import com.btplayer.video.domain.model.EngineType
import com.btplayer.video.domain.model.VideoItem
import com.btplayer.video.player.controller.PlayerController
import com.btplayer.video.ui.icons.BTPlayerIcons
import com.btplayer.video.ui.theme.CyanAccent
import com.btplayer.video.ui.theme.DarkCardBorder
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Gap kept between the floating window and every edge of the area it floats in. */
internal val FloatingPlayerMargin = 8.dp

/** Distance between the window's default position and the bottom edge of the area. */
internal val FloatingPlayerBottomGap = 12.dp

private const val FLOATING_ASPECT_RATIO = 16f / 9f
private val FloatingPlayerMaxWidth = 460.dp
private val FloatingPlayerMinWidth = 160.dp

/**
 * Width of the floating window for a given area. It is as wide as the area allows (wide, horizontal
 * 16:9 video window), but never wider than [FloatingPlayerMaxWidth] and never taller than about
 * half of the area, so that on a landscape phone it stays small enough to browse around it.
 */
internal fun floatingPlayerWidth(containerWidth: Dp, containerHeight: Dp): Dp {
    val byWidth = containerWidth - FloatingPlayerMargin * 2
    val byHeight = containerHeight * 0.5f * FLOATING_ASPECT_RATIO
    return minOf(byWidth, byHeight, FloatingPlayerMaxWidth).coerceAtLeast(FloatingPlayerMinWidth)
}

/**
 * Extra space the home lists keep free at the bottom while the floating window is visible, so the
 * last folders and videos can always be scrolled above it.
 */
internal fun floatingPlayerReservedHeight(screenWidth: Dp, screenHeight: Dp): Dp {
    val width = floatingPlayerWidth(screenWidth, screenHeight * 0.8f)
    return width * (1f / FLOATING_ASPECT_RATIO) + FloatingPlayerBottomGap + 12.dp
}

/**
 * Wide, horizontal floating video window shown above the folder / video lists while a video is
 * playing. Features:
 * - the video is shown inside a 16:9 window (Media3 `PlayerView`, or a LibVLC `SurfaceView`
 *   when the LibVLC fallback is the active engine);
 * - expand-to-full-screen and close buttons in the top-right corner, a centred play/pause button,
 *   the video title, elapsed / total time and a thin progress line;
 * - controls fade out three seconds after playback starts and come back with a tap;
 * - the window can be dragged anywhere, but is always kept fully inside the screen area;
 * - it keeps playing while the person browses folders and videos behind it.
 */
@Composable
internal fun FloatingVideoPlayer(
    video: VideoItem,
    playerController: PlayerController,
    isPlaying: Boolean,
    onExpand: () -> Unit,
    onClose: () -> Unit
) {
    val engine by playerController.activeEngineType.collectAsState()
    val positionMs by playerController.displayedPositionMs.collectAsState()
    val durationMs by playerController.effectiveDurationMs.collectAsState()

    var controlsVisible by remember { mutableStateOf(true) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var windowSize by remember { mutableStateOf(IntSize.Zero) }

    // Controls hide 3 s after playback is running; while paused they stay visible.
    LaunchedEffect(controlsVisible, isPlaying) {
        if (controlsVisible && isPlaying) {
            delay(3_000L)
            controlsVisible = false
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val containerWidth = maxWidth
        val containerHeight = maxHeight
        val containerWidthPx = with(density) { containerWidth.toPx() }
        val containerHeightPx = with(density) { containerHeight.toPx() }
        val marginPx = with(density) { FloatingPlayerMargin.toPx() }
        val bottomGapPx = with(density) { FloatingPlayerBottomGap.toPx() }
        val windowWidth = floatingPlayerWidth(containerWidth, containerHeight)

        // The window sits at bottom-centre by default; dragX / dragY are offsets from there.
        // These limits keep all four edges of the window inside the area (minus a small margin).
        fun clampX(value: Float): Float {
            val range = ((containerWidthPx - windowSize.width) / 2f - marginPx).coerceAtLeast(0f)
            return value.coerceIn(-range, range)
        }

        fun clampY(value: Float): Float {
            val defaultTop = containerHeightPx - windowSize.height - bottomGapPx
            val minOffset = (marginPx - defaultTop).coerceAtMost(0f)
            val maxOffset = (containerHeightPx - marginPx - windowSize.height - defaultTop).coerceAtLeast(0f)
            return value.coerceIn(minOffset, maxOffset)
        }

        // Re-apply the limits after rotation, split-screen or any other size change.
        LaunchedEffect(containerWidthPx, containerHeightPx, windowSize) {
            dragX = clampX(dragX)
            dragY = clampY(dragY)
        }

        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val windowShape = RoundedCornerShape(12.dp)

            Box(
                modifier = Modifier
                    .padding(bottom = FloatingPlayerBottomGap)
                    .offset { IntOffset(dragX.roundToInt(), dragY.roundToInt()) }
                    .width(windowWidth)
                    .aspectRatio(FLOATING_ASPECT_RATIO)
                    .shadow(8.dp, windowShape)
                    .clip(windowShape)
                    .background(Color.Black)
                    .border(1.dp, DarkCardBorder, windowShape)
                    .onSizeChanged { windowSize = it }
            ) {
                // --- Video surface ---
                if (engine == EngineType.MEDIA3) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                useController = false
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                player = playerController.media3ExoPlayer
                            }
                        },
                        update = { view ->
                            if (view.player !== playerController.media3ExoPlayer) {
                                view.player = playerController.media3ExoPlayer
                            }
                        },
                        onRelease = { view -> view.player = null },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // LibVLC fallback is active: give it its own surface inside the window.
                    DisposableEffect(Unit) {
                        onDispose { playerController.onSurfaceDestroyed(EngineType.VLC) }
                    }
                    AndroidView(
                        factory = { ctx ->
                            FrameLayout(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                val surfaceView = SurfaceView(ctx)
                                surfaceView.layoutParams = FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    Gravity.CENTER
                                )
                                surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
                                    override fun surfaceCreated(holder: SurfaceHolder) {
                                        playerController.onVlcSurfaceCreated(
                                            surfaceView,
                                            surfaceView.width,
                                            surfaceView.height
                                        )
                                    }

                                    override fun surfaceChanged(
                                        holder: SurfaceHolder,
                                        format: Int,
                                        width: Int,
                                        height: Int
                                    ) {
                                        playerController.onSurfaceSizeChanged(width, height)
                                    }

                                    override fun surfaceDestroyed(holder: SurfaceHolder) {
                                        playerController.onSurfaceDestroyed(EngineType.VLC)
                                    }
                                })
                                addView(surfaceView)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // --- Touch layer: tap shows / hides controls, drag moves the window ---
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(controlsVisible) {
                            detectTapGestures(onTap = { controlsVisible = !controlsVisible })
                        }
                        .pointerInput(containerWidthPx, containerHeightPx) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                dragX = clampX(dragX + dragAmount.x)
                                dragY = clampY(dragY + dragAmount.y)
                            }
                        }
                )

                // --- Controls (fade out while playing) ---
                AnimatedVisibility(
                    visible = controlsVisible,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Top bar: title + expand + close
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(listOf(Color(0xB3000000), Color.Transparent))
                                )
                                .padding(start = 10.dp, end = 2.dp, top = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = video.displayName,
                                modifier = Modifier.weight(1f),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            IconButton(onClick = onExpand, modifier = Modifier.size(40.dp)) {
                                Icon(
                                    imageVector = BTPlayerIcons.Fullscreen,
                                    contentDescription = "Expand to full screen",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            IconButton(onClick = onClose, modifier = Modifier.size(40.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close player",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        // Centre: play / pause
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(Color(0x99000000))
                                .clickable { playerController.togglePlayPause() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) BTPlayerIcons.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = CyanAccent,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        // Bottom: elapsed / total time
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(
                                    Brush.verticalGradient(listOf(Color.Transparent, Color(0xB3000000)))
                                )
                                .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = VideoItem.formatTimestampMs(positionMs),
                                color = Color.White,
                                fontSize = 10.sp
                            )
                            Text(
                                text = if (durationMs > 0L) VideoItem.formatTimestampMs(durationMs) else "--:--",
                                color = Color(0xCCFFFFFF),
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                // --- Thin progress line, always visible along the bottom edge ---
                val progress = if (durationMs > 0L) {
                    (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                } else {
                    0f
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(Color(0x55FFFFFF))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .background(CyanAccent)
                    )
                }
            }
        }
    }
}
